var RSServer=require('./../rs-server');
var http = require('http');
var httpProxy = require('http-proxy');
var _token='eyJhbGciOiJSUzI1NiIsImtpZCI6ImxlZ2FjeS10b2tlbi1rZXkiLCJ0eXAiOiJKV1QifQ.eyJqdGkiOiIxZDVhMjQyYzI5ZmY0MWM2ODZlYWMxOWUyZDU5NzkzMiIsInN1YiI6ImVjLWNsaWVudCIsInNjb3BlIjpbImVudGVycHJpc2UtY29ubmVjdC56b25lcy5mYzVlMjNkNS0yMWIyLTRkN2UtOTg4MC0zZWMyMGVmNTMwYWYudXNlciIsInVhYS5yZXNvdXJjZSIsImVudGVycHJpc2UtY29ubmVjdC56b25lcy42YTQ3Mzc2ZS04MzVhLTRmNTAtYjFkOC1lNzI0ZjI4YmY0MDIudXNlciIsImVudGVycHJpc2UtY29ubmVjdC56b25lcy44MTYyYmJlZC1kZGI5LTQ1NTAtODc3OS03ODMzYjA3ZjhmYjkudXNlciIsIm9wZW5pZCIsInVhYS5ub25lIiwiZW50ZXJwcmlzZS1jb25uZWN0LnpvbmVzLmM0MjQwYjg5LTczNzItNDljNS1iNGE2LTgwMDEyODZlNGJkNS51c2VyIiwiZW50ZXJwcmlzZS1jb25uZWN0LnpvbmVzLjIzNDhmNjE4LWI3MTgtNDc0Yy1iNWU0LThlZDg4NGI2ZjAwYS51c2VyIiwiZW50ZXJwcmlzZS1jb25uZWN0LnpvbmVzLjQ2MjBiNjBiLTAxYjQtNDk5NC1iNzEzLTkyODMxMzIxNGUzMy51c2VyIiwiZW50ZXJwcmlzZS1jb25uZWN0LnpvbmVzLjJmMDYwZTNhLThjNjQtNDUwZS05NWYyLTZjMDI3MzAwNjUzYy51c2VyIl0sImNsaWVudF9pZCI6ImVjLWNsaWVudCIsImNpZCI6ImVjLWNsaWVudCIsImF6cCI6ImVjLWNsaWVudCIsImdyYW50X3R5cGUiOiJjbGllbnRfY3JlZGVudGlhbHMiLCJyZXZfc2lnIjoiZDFjMTUxNyIsImlhdCI6MTQ3OTg1ODgyNiwiZXhwIjoxNDc5OTAyMDI2LCJpc3MiOiJodHRwczovLzQzNGEzZGViLWM3NjMtNDc0ZC1iZWU4LTFkNjQ0MGI2ZjQwZS5wcmVkaXgtdWFhLnJ1bi5hd3MtdXN3MDItcHIuaWNlLnByZWRpeC5pby9vYXV0aC90b2tlbiIsInppZCI6IjQzNGEzZGViLWM3NjMtNDc0ZC1iZWU4LTFkNjQ0MGI2ZjQwZSIsImF1ZCI6WyJ1YWEiLCJlbnRlcnByaXNlLWNvbm5lY3Quem9uZXMuYzQyNDBiODktNzM3Mi00OWM1LWI0YTYtODAwMTI4NmU0YmQ1IiwiZWMtY2xpZW50Iiwib3BlbmlkIiwiZW50ZXJwcmlzZS1jb25uZWN0LnpvbmVzLjgxNjJiYmVkLWRkYjktNDU1MC04Nzc5LTc4MzNiMDdmOGZiOSIsImVudGVycHJpc2UtY29ubmVjdC56b25lcy5mYzVlMjNkNS0yMWIyLTRkN2UtOTg4MC0zZWMyMGVmNTMwYWYiLCJlbnRlcnByaXNlLWNvbm5lY3Quem9uZXMuMjM0OGY2MTgtYjcxOC00NzRjLWI1ZTQtOGVkODg0YjZmMDBhIiwiZW50ZXJwcmlzZS1jb25uZWN0LnpvbmVzLjZhNDczNzZlLTgzNWEtNGY1MC1iMWQ4LWU3MjRmMjhiZjQwMiIsImVudGVycHJpc2UtY29ubmVjdC56b25lcy40NjIwYjYwYi0wMWI0LTQ5OTQtYjcxMy05MjgzMTMyMTRlMzMiLCJlbnRlcnByaXNlLWNvbm5lY3Quem9uZXMuMmYwNjBlM2EtOGM2NC00NTBlLTk1ZjItNmMwMjczMDA2NTNjIl19.PoQyeiKaAtdM33qqeHtLU42NqUFVHIOOw7wtyqNi3A0OyIfV-SOaIgCtkHUzkVMzWBEfO2LgExFyghEZfF_EywtMWu4UI2JnCm4AVDkvovHnVRdN3n7UFD1Fme3-sg57GcRHjF54CfUHPSfYeOaLcNvKM7tgqpE3fT4k7oPrkvWRfJ2u216ceTMoxnBHk2pv98QT3TJrx-Xi69WVvSMUvpLk0h99GC-l1Ie5kTPWTV0dAaOMAaQCjD-LeP324SlEhq9G8MSw_x7RISfuJ3UR6iwJug_BjmpL6PNj3jex-_DQ95vJj3iYRO91klY1xOoCxMXj6yNG7jL0yDoEkpdXoQ';

//cf api
var cfapi=new RSServer({
    gatewayHost: 'wss://2348f618-b718-474c-b5e4-8ed884b6f00a.run.aws-usw02-pr.ice.predix.io',
    gatewayPort: 443,
    //resourceHost: '10.131.54.5', //no protocol prefix. this's always tcp
    resourceHost: 'localhost', //no protocol prefix. this's always tcp
    resourcePort: process.env.PORT||0,
    id: '191001', //Reachback service credential
    //secret: '1434344', //Presented if requested by gateway. This would be your the secret for the Basic auth
    oauthToken: _token
});


//cf login zoneid: cflogin-test
var cflogin=new RSServer({
    gatewayHost: 'wss://6a47376e-835a-4f50-b1d8-e724f28bf402.run.aws-usw02-pr.ice.predix.io',
    gatewayPort: 443,
    //gatewayHost: 'ws://localhost',
    //gatewayPort: 8989,
    //resourceHost: '10.131.54.5', //no protocol prefix. this's always tcp
    resourceHost: 'login.system.asv-pr.ice.predix.io', //no protocol prefix. this's always tcp
    resourcePort: 443,
    id: '191001', //Reachback service credential
    //secret: '1434344', //Presented if requested by gateway. This would be your the secret for the Basic auth
    oauthToken: _token
});

//cf token zoneid: cftoken-test
var cftoken=new RSServer({
    gatewayHost: 'wss://2f060e3a-8c64-450e-95f2-6c027300653c.run.aws-usw02-pr.ice.predix.io',
    gatewayPort: 443,
    //gatewayHost: 'ws://localhost',
    //gatewayPort: 8989,
    //resourceHost: '10.131.54.5', //no protocol prefix. this's always tcp
    resourceHost: 'uaa.system.asv-pr.ice.predix.io', //no protocol prefix. this's always tcp
    resourcePort: 443,
    id: '191001', //Reachback service credential
    //secret: '1434344', //Presented if requested by gateway. This would be your the secret for the Basic auth
    oauthToken: _token
});

//cf logger zoneid: cflogger-test
var cflogger=new RSServer({
    gatewayHost: 'wss://fc5e23d5-21b2-4d7e-9880-3ec20ef530af.run.aws-usw02-pr.ice.predix.io',
    gatewayPort: 443,
    //gatewayHost: 'ws://localhost',
    //gatewayPort: 8989,
    //resourceHost: '10.131.54.5', //no protocol prefix. this's always tcp
    resourceHost: 'loggregator.system.asv-pr.ice.predix.io', //no protocol prefix. this's always tcp
    resourcePort: 443,
    id: '191001', //Reachback service credential
    //secret: '1434344', //Presented if requested by gateway. This would be your the secret for the Basic auth
    oauthToken: _token
});


//cf doppler zoneid: cfdoppler-test
var cfdoppler=new RSServer({
    gatewayHost: 'wss://8162bbed-ddb9-4550-8779-7833b07f8fb9.run.aws-usw02-pr.ice.predix.io',
    gatewayPort: 443,
    //gatewayHost: 'ws://localhost',
    //gatewayPort: 8989,
    //resourceHost: '10.131.54.5', //no protocol prefix. this's always tcp
    resourceHost: 'doppler.system.asv-pr.ice.predix.io', //no protocol prefix. this's always tcp
    resourcePort: 443,
    id: '191001', //Reachback service credential
    //secret: '1434344', //Presented if requested by gateway. This would be your the secret for the Basic auth
    oauthToken: _token
});

//command: DEBUG=rs:server node server

//project cf cli


var proxy = httpProxy.createProxyServer({});
//proxy.web(req, res, { target: 'http://mytarget.com:8080' });

//mock call to bypass the cf health check.

http.createServer((req, res)=>{
    if (req.url.indexOf("/v2/info")){
	res.writeHead(200);
	return res.end(JSON.stringify({
	    name:"",
	    build:"",
	    support:"http://support.cloudfoundry.com",
	    version:0,
	    description:"Cloud Foundry GE Open Sandbox",
	    "authorization_endpoint":"http://localhost:7991",
	    "token_endpoint":"http://localhost:7992",
	    "min_cli_version":null,
	    "min_recommended_cli_version":null,
	    "api_version":"2.62.0",
	    "app_ssh_endpoint":"ssh.system.asv-pr.ice.predix.io:2222",
	    "app_ssh_host_key_fingerprint":"a6:d1:08:0b:b0:cb:9b:5f:c4:ba:44:2a:97:26:19:8a",
	    "app_ssh_oauth_client":"ssh-proxy",
	    "logging_endpoint":"ws://localhost:7993",
	    "doppler_logging_endpoint":"ws://localhost:7994"}));
    }
    
    proxy.web(req, res, { target: 'https://api.system.asv-pr.ice.predix.io' });
    
}).listen(process.env.PORT||0, _=> {
    console.log(`${new Date()} CF healthcheck mockup call.`);
});
