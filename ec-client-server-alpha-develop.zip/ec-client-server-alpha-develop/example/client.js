var RSClient=require('./../rs-client');

//postgreSQL
var phs=new RSClient({
    //proxy service. remove _ to activate
    _proxy:{
	host:'proxy-src.research.ge.com',
	port:8080
    },
    localPort:7990,
    gatewayHost:'ws://localhost',
    gatewayPort:8989,
    //gatewayHost: 'wss://4148b8aa-ddd8-4d30-bf08-f27d652a7caa.run.asv-pr.ice.predix.io',
    //gatewayHost:'wss://rsgateway.run.asv-pr.ice.predix.io',//predix select
    //gatewayPort: 443,
    targetServerId:'191001',//empty/id/ip
    id: '191000',
    //secret: '1234', //Presented if requested by gateway. This would be your the secret for the Basic auth
    oauthToken: 'eyJhbGciOiJSUzI1NiIsImtpZCI6ImxlZ2FjeS10b2tlbi1rZXkiLCJ0eXAiOiJKV1QifQ.eyJqdGkiOiI1MGU1NjQ0ZjU5MGQ0ZTUzODA4NThhODg2NzA1MTdhNyIsInN1YiI6ImNoaWEiLCJzY29wZSI6WyJ1YWEucmVzb3VyY2UiLCJvcGVuaWQiLCJ1YWEubm9uZSIsImVudGVycHJpc2UtY29ubmVjdC56b25lcy40MTQ4YjhhYS1kZGQ4LTRkMzAtYmYwOC1mMjdkNjUyYTdjYWEudXNlciJdLCJjbGllbnRfaWQiOiJjaGlhIiwiY2lkIjoiY2hpYSIsImF6cCI6ImNoaWEiLCJncmFudF90eXBlIjoiY2xpZW50X2NyZWRlbnRpYWxzIiwicmV2X3NpZyI6ImE5NjIzNDYyIiwiaWF0IjoxNDc5MzM4NzYwLCJleHAiOjE0NzkzODE5NjAsImlzcyI6Imh0dHBzOi8vMjA1NjQ2MzEtYTY5Yy00Y2M1LTgzYmQtNDU5YWEzMDdhMzA3LnByZWRpeC11YWEucnVuLmF3cy11c3cwMi1wci5pY2UucHJlZGl4LmlvL29hdXRoL3Rva2VuIiwiemlkIjoiMjA1NjQ2MzEtYTY5Yy00Y2M1LTgzYmQtNDU5YWEzMDdhMzA3IiwiYXVkIjpbImVudGVycHJpc2UtY29ubmVjdC56b25lcy40MTQ4YjhhYS1kZGQ4LTRkMzAtYmYwOC1mMjdkNjUyYTdjYWEiLCJjaGlhIiwidWFhIiwib3BlbmlkIl19.RByyuSytNxjHDbrpPs69E5fJGzYJhdW-y2LBBPmQG6NzGrJupZAsDC7cjaXaC5P8UPKMCgYfl8FFAcWSAsPjNbEHB1wkKnJQXbtbtNt9kaaH1nq7qV6RkZZFOPciYZS3n07oqnyyOSDxZVhj_N31-OByyVJb3d1-zlvhtK7GqaPW8qrcne9MNomS855wjhhQAm2gWPPz_y-d8ioc_MJg_xowLeesJOSuWvFgtmsQlCJ9tTm2OQ9NsgXrAxIq_rkYc5-eFYcxrGOnEU94jpj8IZMJTSjch-jkroHbJHFxDqnNdWz238aD_koKkyh28HyrrHAEgq5XFhu3JXF9ehK52A'
});
