var RSClient=require('./../rs-client');
var _token='eyJhbGciOiJSUzI1NiIsImtpZCI6ImxlZ2FjeS10b2tlbi1rZXkiLCJ0eXAiOiJKV1QifQ.eyJqdGkiOiI1MGU1NjQ0ZjU5MGQ0ZTUzODA4NThhODg2NzA1MTdhNyIsInN1YiI6ImNoaWEiLCJzY29wZSI6WyJ1YWEucmVzb3VyY2UiLCJvcGVuaWQiLCJ1YWEubm9uZSIsImVudGVycHJpc2UtY29ubmVjdC56b25lcy40MTQ4YjhhYS1kZGQ4LTRkMzAtYmYwOC1mMjdkNjUyYTdjYWEudXNlciJdLCJjbGllbnRfaWQiOiJjaGlhIiwiY2lkIjoiY2hpYSIsImF6cCI6ImNoaWEiLCJncmFudF90eXBlIjoiY2xpZW50X2NyZWRlbnRpYWxzIiwicmV2X3NpZyI6ImE5NjIzNDYyIiwiaWF0IjoxNDc5MzM4NzYwLCJleHAiOjE0NzkzODE5NjAsImlzcyI6Imh0dHBzOi8vMjA1NjQ2MzEtYTY5Yy00Y2M1LTgzYmQtNDU5YWEzMDdhMzA3LnByZWRpeC11YWEucnVuLmF3cy11c3cwMi1wci5pY2UucHJlZGl4LmlvL29hdXRoL3Rva2VuIiwiemlkIjoiMjA1NjQ2MzEtYTY5Yy00Y2M1LTgzYmQtNDU5YWEzMDdhMzA3IiwiYXVkIjpbImVudGVycHJpc2UtY29ubmVjdC56b25lcy40MTQ4YjhhYS1kZGQ4LTRkMzAtYmYwOC1mMjdkNjUyYTdjYWEiLCJjaGlhIiwidWFhIiwib3BlbmlkIl19.RByyuSytNxjHDbrpPs69E5fJGzYJhdW-y2LBBPmQG6NzGrJupZAsDC7cjaXaC5P8UPKMCgYfl8FFAcWSAsPjNbEHB1wkKnJQXbtbtNt9kaaH1nq7qV6RkZZFOPciYZS3n07oqnyyOSDxZVhj_N31-OByyVJb3d1-zlvhtK7GqaPW8qrcne9MNomS855wjhhQAm2gWPPz_y-d8ioc_MJg_xowLeesJOSuWvFgtmsQlCJ9tTm2OQ9NsgXrAxIq_rkYc5-eFYcxrGOnEU94jpj8IZMJTSjch-jkroHbJHFxDqnNdWz238aD_koKkyh28HyrrHAEgq5XFhu3JXF9ehK52A';

//cf api
var cfapi=new RSClient({
    //proxy service. remove _ to activate
    _proxy:{
	host:'proxy-src.research.ge.com',
	port:8080
    },
    localPort:7990,
    gatewayHost: 'wss://gateway-inst.run.asv-pr.ice.predix.io',
    gatewayPort: 443,
    targetServerId:'191001',//empty/id/ip
    id: '191000',
    oauthToken: _token
});

//cf login
var cflogin=new RSClient({
    //proxy service. remove _ to activate
    _proxy:{
	host:'proxy-src.research.ge.com',
	port:8080
    },
    localPort:7991,
    gatewayHost: 'wss://gateway-inst.run.asv-pr.ice.predix.io',
    gatewayPort: 443,
    targetServerId:'191003',//empty/id/ip
    id: '191002',
    oauthToken: _token
});



//cf token
var cftoken=new RSClient({
    //proxy service. remove _ to activate
    _proxy:{
	host:'proxy-src.research.ge.com',
	port:8080
    },
    localPort:7992,
    gatewayHost: 'wss://gateway-inst.run.asv-pr.ice.predix.io',
    gatewayPort: 443,
    targetServerId:'191005',//empty/id/ip
    id: '191004',
    oauthToken: _token
});

//cf logger
var cflogger=new RSClient({
    //proxy service. remove _ to activate
    _proxy:{
	host:'proxy-src.research.ge.com',
	port:8080
    },
    localPort:7993,
    gatewayHost: 'wss://gateway-inst.run.asv-pr.ice.predix.io',
    gatewayPort: 443,
    targetServerId:'191007',//empty/id/ip
    id: '191006',
    oauthToken: _token
});


//cf doppler
var cfdoppler=new RSClient({
    //proxy service. remove _ to activate
    _proxy:{
	host:'proxy-src.research.ge.com',
	port:8080
    },
    localPort:7994,
    gatewayHost: 'wss://gateway-inst.run.asv-pr.ice.predix.io',
    gatewayPort: 443,
    targetServerId:'191009',//empty/id/ip
    id: '191008',
    oauthToken: _token
});

//cf login -a localhost:7990

