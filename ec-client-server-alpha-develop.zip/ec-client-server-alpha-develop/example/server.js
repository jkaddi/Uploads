var RSServer=require('./../rs-server');
var http = require('http');
var phs=new RSServer({
    //proxy service. remove _ to activate
    _proxy:{
	host:'proxy-src.research.ge.com',
	port:8080
    },
    gatewayHost: 'wss://4148b8aa-ddd8-4d30-bf08-f27d652a7caa.run.asv-pr.ice.predix.io',
    gatewayPort: 443,
    //gatewayHost: 'ws://localhost',
    //gatewayPort: 8989,
    resourceHost: '10.131.54.5', //no protocol prefix. this's always tcp
    resourcePort: 5432,
    id: '191001', //Reachback service credential
    //secret: '1434344', //Presented if requested by gateway. This would be your the secret for the Basic auth
    oauthToken: 'eyJhbGciOiJSUzI1NiIsImtpZCI6ImxlZ2FjeS10b2tlbi1rZXkiLCJ0eXAiOiJKV1QifQ.eyJqdGkiOiJhODNiNThjMDZiNDA0NWNjODI3YjhkNzZhNmFkNGVkOCIsInN1YiI6ImNoaWEiLCJzY29wZSI6WyJ1YWEucmVzb3VyY2UiLCJvcGVuaWQiLCJ1YWEubm9uZSIsImVudGVycHJpc2UtY29ubmVjdC56b25lcy40MTQ4YjhhYS1kZGQ4LTRkMzAtYmYwOC1mMjdkNjUyYTdjYWEudXNlciJdLCJjbGllbnRfaWQiOiJjaGlhIiwiY2lkIjoiY2hpYSIsImF6cCI6ImNoaWEiLCJncmFudF90eXBlIjoiY2xpZW50X2NyZWRlbnRpYWxzIiwicmV2X3NpZyI6ImE5NjIzNDYyIiwiaWF0IjoxNDc5MzM3ODE4LCJleHAiOjE0NzkzODEwMTgsImlzcyI6Imh0dHBzOi8vMjA1NjQ2MzEtYTY5Yy00Y2M1LTgzYmQtNDU5YWEzMDdhMzA3LnByZWRpeC11YWEucnVuLmF3cy11c3cwMi1wci5pY2UucHJlZGl4LmlvL29hdXRoL3Rva2VuIiwiemlkIjoiMjA1NjQ2MzEtYTY5Yy00Y2M1LTgzYmQtNDU5YWEzMDdhMzA3IiwiYXVkIjpbImVudGVycHJpc2UtY29ubmVjdC56b25lcy40MTQ4YjhhYS1kZGQ4LTRkMzAtYmYwOC1mMjdkNjUyYTdjYWEiLCJjaGlhIiwidWFhIiwib3BlbmlkIl19.SnGs6u1h5lvmBMzBL4ZHJmOzKaBFTgwgpHMVTdhb80C2jawTXO71fXAjECvhx4aW3RupOX1qzK4ZTo3iS4QlgvNA5pwkATJPk0PwDErCl4Nzu0Km7hA4QnN9yZgFYlO_YNMSQPFrV8LAuAAskHs1szNzl886RVmgILI91GRqWkGNJeH0PKFzg6mppAJYn64HKcQoRlBfhCeq1jUshbQxruyCGERudu_ceh4kZ_-rDlrsxjYCyKXUnL2kBHUVXnBS3h87hDGBK_dor4H3E9RM8YRgX0V44Ttc_CE_kRQFDU8Rmi8cUgkUKs1s016fLRHmZESFs2EiDtluaoF0xvB4Tg'
    });



//mock call to bypass the cf health check.

http.createServer((req, res)=>{
    res.writeHead(200);
    res.end();
}).listen(process.env.PORT||0, _=> {
    console.log(`${new Date()} CF healthcheck mockup call.`);
});

//command: DEBUG=rs:server node server
