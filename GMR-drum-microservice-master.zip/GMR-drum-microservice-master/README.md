# Seed APM Micro Service.

Seed APM Micro Service.

### Prerequisites

1.  Install Java 1.8.
2.  Install maven 3.x
3.  Set the following environment variables
<pre>
export MAVEN_HOME=maven_install_dir
export JAVA_HOME=jdk_install_dir
export PATH=$MAVEN_HOME/bin:$JAVA_HOME/bin:$PATH
</pre>

### Building the package
<pre>
  git clone git@github.build.ge.com:PD-CORE/pd-apm-micro-service-seed.git
  cd pd-apm-micro-service-seed
  mvn clean install -s menlo_settings.xml
</pre>

### Running APM Micro Service Seed Locally
<pre>
  mvn spring-boot:run -s menlo_settings.xml
</pre>

### Smoke Test
To verify that the service is running locally, make a request to one of the endpoints.

1.  Acquire an authorization token
<pre>
 For RC env : https://apm-gettoken-stuf-sso-rc.run.asv-pr.ice.predix.io/token/#/
</pre>
  The token will be the very long string value of the returned access_token attribute.  Concatenate this value with the string 'Bearer' when constructing the Authorization header.

2.  Make a request to one of the Process Optimization endpoints.
<pre>
  curl -X GET -H "Authorization: Bearer eyJhbGciOiJSUzI1NiJ9.a_really_long_string \
    -H "Tenant: ebb7f6cd-85bd-4d5c-bed8.get it from the APM setup page" \
    "http://localhost:8080/v1/pd/hello"
</pre>

2.  ACS Policies are not created so the following is the expected output.
<pre>
  {
    "timestamp": 1477281103209,
    "status": 403,
    "error": "Forbidden",
    "message": "Access is denied",
    "path": "/v1/pd/hello"
  }
</pre>
