export JAVA_HOME=${JAVA_HOME_ORACLEJDK8}
export PATH=${JAVA_HOME}/bin:${PATH}
mvn -T 1C clean clover2:instrument clover2:clover install -s menlo_settings.xml

