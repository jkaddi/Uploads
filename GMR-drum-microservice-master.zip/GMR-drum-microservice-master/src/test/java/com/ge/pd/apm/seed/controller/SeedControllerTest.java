package com.ge.pd.apm.seed.controller;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class SeedControllerTest {
    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @InjectMocks
    private SeedController controller;

//    @Mock
//    private ISeedService seedService;


    @Test
    public void test() throws Exception{
        
        
       // when(seedService.getGreeting()).thenReturn("I am power digital seed microservice. Welcome!");
       
//        String testString = controller.greeting();
//        
//        assertEquals("I am power digital seed microservice. Welcome!", testString);
    }
}
