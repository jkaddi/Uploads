package com.ge.pd.apm.seed;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

/**
 * Put additional configuration here.
 * @author 212586794
 */
@Component
@Configuration
@Getter
@Setter
public class ApplicationConfigurator implements InitializingBean {

    @Value("${proxyHost:}")
    private String proxyHost;

    @Value("${proxyPort:}")
    private String proxyPort;


    @Override
    public void afterPropertiesSet() throws Exception {
        if (!"".equals(proxyHost) && !"".equals(proxyPort)) {
            System.setProperty("https.proxyHost", proxyHost);
            System.setProperty("https.proxyPort", proxyPort);
        }
    }
}
