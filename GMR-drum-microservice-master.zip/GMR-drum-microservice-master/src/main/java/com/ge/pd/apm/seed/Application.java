package com.ge.pd.apm.seed;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.cloudfoundry.VcapApplicationListener;
import org.springframework.boot.context.web.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ImportResource;

/**
 * Main class for Spring-Boot app.
 */
@ComponentScan({"com.ge.stuf", "com.ge.pd.common", "com.ge.pd.apm.seed","com.ge.om"})
@ImportResource("classpath:com/ge/stuf/security/default-security-config.xml")
@EnableAutoConfiguration
public class Application extends SpringBootServletInitializer {

    /**
     * Main entry point for spring boot app.
     * @param args program arguments.
     */
    public static void main(final String[] args) {
        new SpringApplicationBuilder(Application.class).listeners(new VcapApplicationListener()).run(args);
    }
}
