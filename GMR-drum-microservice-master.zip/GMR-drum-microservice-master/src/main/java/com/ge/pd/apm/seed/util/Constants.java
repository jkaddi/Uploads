package com.ge.pd.apm.seed.util;

/**
 * Constants class.
 * @author 212573790
 */
public final class Constants {

    /**
     * Private constructor.
     */
    private Constants() {
        throw new AssertionError("Suppress default constructor for noninstantiability");
    }

    /**
     * Version of service.
     */
    public static final String VERSION = "/v1";

    /**
     * Base path for MicroService: version.
     */
    public static final String BASE_PATH = VERSION;

}
