package com.ge.pd.apm.seed.controller;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import lombok.extern.slf4j.Slf4j;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ge.om.MatlabWrapper.RunAnOsaModuleMatlab;

/**
 * Seed Controller for MicroService Seed App.
 */
@RestController
@Slf4j
@RequestMapping(com.ge.pd.apm.seed.util.Constants.BASE_PATH)
public class SeedController {

    /**
     * Service.
     */
//    @Autowired
//    private ISeedService seedService;

    /**
     * Service to return PD greetings.
     * @return String
     * @throws Exception throws errors
     */
    @RequestMapping(value = "/pd/hello", method = RequestMethod.GET, produces = MediaType.TEXT_PLAIN_VALUE)
    public String greeting() throws Exception {
        log.info("Controller Greetings: " + "");
        return "";
    }
    
//    @POST
// 	@Path("/output")
// 	@Consumes(MediaType.APPLICATION_XML)
// 	@Produces(MediaType.APPLICATION_XML)
    
    @RequestMapping(value="/pd/output", method= RequestMethod.GET)
	public String getAnalyticOutput(String xml)
	{
		System.out.println("^^^^^^^^^^^^^^^^^^^^^ "+ xml);
		RunAnOsaModuleMatlab matlabModule = new RunAnOsaModuleMatlab();
		String outXml = matlabModule.run(xml);
		return outXml;
	}
}
