/**
 *
 * The information contained in this document is General Electric Company (GE)
 * proprietary information and is disclosed in confidence. It is the property
 * of GE and shall not be used, disclosed to others or reproduced without the
 * express written consent of GE. If consent is given for reproduction in whole
 * or in part, this notice and the notice set forth on each page of this document
 * shall appear in any such reproduction in whole or in part. The information
 * contained in this document may also be controlled by the U.S. export control
 * laws.  Unauthorized export or re-export is prohibited.
 *
 * This module is intended for:  (Choose one of the following options)
 *      Military use only
 *  X   Commercial use only
 *      Both military and commercial use
 */
package com.ge.om.MatlabWrapper;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Date;

import javax.naming.ConfigurationException;
import javax.xml.bind.JAXBException;

import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecutor;
import org.apache.commons.exec.ExecuteWatchdog;
import org.apache.commons.exec.PumpStreamHandler;

import com.ge.energy.ssg.framework.util.wrapper.WrapperInterface;
import com.ge.om.MatlabWrapper.util.MatlabWrapperConstants;
import com.ge.om.MatlabWrapper.util.MatlabWrapperUtil;
import com.ge.om.cafosacbm.ModuleConfigXMLRoot;
import com.ge.om.cafxml.CAFModuleConfigUtil;
import com.ge.om.cafxml.CAFXmlUtil;

/**
 * This class provides and entry point for running a module using a well-defined
 * osa-cbm xml configuration specifying the input and parameter values for this
 * run. The intent is to expose the run(String) method to the calling mechanism
 * (example the run(String) method will be the web-service entry point).
 * 
 * @author 501881106
 */

public class RunAnOsaModuleMatlab implements WrapperInterface {

	private CAFXmlUtil xmlUtil = null;

	private MatlabWrapperUtil matlabUtil = null;

	private ModuleConfigXMLRoot xmlRoot = null;

	/**
	 * extract ModuleConfigXMLRoot from xml file
	 * 
	 * @throws ConfigurationException
	 * 
	 * @archAPI.setup
	 */
	public void setup(Object xmlOnStdIn) throws Exception {
		xmlRoot = getXmlUtil().parseXmlString((String) xmlOnStdIn);
		setXmlRoot(xmlRoot);
	}

	@Override
	public String run(String xmlFromC) {
		String outputXML = null;
		try {
			System.out.println("^^^^^^^^^^^^^^^^^^^^^ %%%%%%%%%%%%%%%%%%%%% "+ outputXML);
			setup(xmlFromC);
			MatlabWrapper wrapper = new MatlabWrapper();
			wrapper.processRequest(xmlRoot);
			
			outputXML = getXmlUtil().getXmlString(wrapper.getXmlRoot());
			
			
		} catch (Exception e) {
			MatlabWrapperUtil.logError(getClass(), e.getMessage());
			MatlabWrapperUtil matlabUtil = new MatlabWrapperUtil();
			try {
				matlabUtil.addRuleFailedInfo(xmlRoot, e.getMessage());
				outputXML = getXmlUtil().getXmlString(xmlRoot);
			} catch (Exception ex) {
				MatlabWrapperUtil.logError(getClass(), ex.getMessage());
			}

		}
		return outputXML;
	}

	private String invokeExternalProcess(String xmlFromC) {
		ByteArrayOutputStream outStream = null;
		ByteArrayOutputStream errorStream = null;
		ByteArrayInputStream inputStream = null;
		DefaultExecutor executor = null;
		ExecuteWatchdog watchdog = null;
		String outputXML = null;
		MatlabWrapperUtil.logInfo(getClass(),
				"Invoking the Matlab External Process");
		try {
			// Building Streams
			outStream = new ByteArrayOutputStream();
			errorStream = new ByteArrayOutputStream();
			inputStream = new ByteArrayInputStream(xmlFromC.getBytes());
			PumpStreamHandler streamHandler = new PumpStreamHandler(outStream,
					errorStream, inputStream);
			String workingDir = System.getProperty("user.dir");
			MatlabWrapperUtil.logDebug(getClass(), "workingDir: " + workingDir);
			String jarFilePath = workingDir.replace("bin",
					"server\\rem\\lib\\MATLABInternal.jar");
			MatlabWrapperUtil.logDebug(getClass(), "jarFilePath: "
					+ jarFilePath);
			String logPath = jarFilePath.replace("lib\\MATLABInternal.jar",
					"log");
			MatlabWrapperUtil.logDebug(getClass(), "MatlabProcess Log path: "
					+ logPath);
	
			String line = "java -Dconf.dir=" + logPath + " -jar " + jarFilePath;

			CommandLine cmdLine = CommandLine.parse(line);
			Long matlabtimeOut;
			try {
				matlabtimeOut = Long
						.parseLong(MatlabWrapperUtil
								.getProperty(MatlabWrapperConstants.MATLAB_PROCESS_TIMEOUT));
			} catch (NumberFormatException e) {
				matlabtimeOut = MatlabWrapperConstants.DEFAULT_MATLAB_PROCESS_TIMEOUT;
			}
			MatlabWrapperUtil.logDebug(getClass(), "Matlab Process Tiemout: "
					+ matlabtimeOut);
			executor = new DefaultExecutor();
			watchdog = new ExecuteWatchdog(matlabtimeOut * 1000);
			executor.setWatchdog(watchdog);
			executor.setStreamHandler(streamHandler);
			int exitcode = executor.execute(cmdLine);
			MatlabWrapperUtil.logInfo(getClass(), "Exit code: " + exitcode);
			if (exitcode == 0) {
				if (outStream != null) {
					String output = outStream.toString();
					if(output!=null)
					outputXML = output.substring(
								 output.indexOf("MatlabOutput") + 13, output.lastIndexOf("ModuleConfigXMLRoot>")+20);					if(outputXML!=null && outputXML.equalsIgnoreCase("null"))
					if(outputXML!=null && outputXML.equalsIgnoreCase("null"))
					outputXML=null;			
				 }
				MatlabWrapperUtil.logError(getClass(), "Error Information: "
						+ errorStream.toString());
				MatlabWrapperUtil.logInfo(getClass(),
						"Output from InternalJar: " + outputXML);
			} else {
				MatlabWrapperUtil.logInfo(getClass(), "Error Information: "
						+ errorStream.toString());
				try {
					addAppInfoDataEvent(false);
					addErrorInfoDataEvent(errorStream.toString(),
							"Error in the Internal Jar");
				} catch (Exception e1) {
					MatlabWrapperUtil.logInfo(getClass(),
							"Error : " + e1.getMessage());
				}
				outputXML = getXmlUtil().getXmlString(xmlRoot);
			}
		} catch (Exception e) {
			MatlabWrapperUtil.logError(
					getClass(),
					"Problem running the MATLABInternalJar file: "
							+ e.getMessage());
			MatlabWrapperUtil.logError(getClass(), "Error Information: "
					+ errorStream.toString());
			try {
				addAppInfoDataEvent(false);
				addErrorInfoDataEvent(e.getMessage(),
						"Failed to launch the Matlab Process :");
			} catch (Exception e1) {
				MatlabWrapperUtil.logError(getClass(),
						"Error in addAppInfoDataEvent and addErrorInfoDataEvent  : "
								+ e1.getMessage());
			}
			try {
				outputXML = getXmlUtil().getXmlString(xmlRoot);
			} catch (JAXBException e1) {
				MatlabWrapperUtil.logError(getClass(), "Error JAXBException: "
						+ e1.getMessage());
			} catch (Exception e1) {
				MatlabWrapperUtil.logError(getClass(),
						"Error getting OutPut Xml : " + e1.getMessage());
			}

		} finally {
			try {
				outStream.flush();
				errorStream.flush();
				outStream.close();
				errorStream.close();
				inputStream.close();
				if (executor != null && watchdog != null) {
					executor.getWatchdog().destroyProcess();
					executor.getWatchdog().stop();
					executor = null;
					watchdog = null;
				}
			} catch (Exception e) {
				MatlabWrapperUtil.logError(getClass(),
						"Error in closing streams: " + e.getMessage());
			}
		}
		return outputXML;
	}

	/**
	 * 
	 * @param analyticSucceeded
	 * @throws Exception
	 */
	private void addAppInfoDataEvent(boolean analyticSucceeded)
			throws Exception {
		getMatlabUtil().addAppInfoDataEvent(xmlRoot, analyticSucceeded,
				new Date(), new Date());
	}

	private void addErrorInfoDataEvent(String ruleFailureMessage,
			String ruleFailurePrefix) throws Exception {
		CAFModuleConfigUtil moduleConfigUtil = new CAFModuleConfigUtil(xmlRoot);
		String errorInfoMessage;
		if (ruleFailurePrefix != null) {
			errorInfoMessage = ruleFailurePrefix + ruleFailureMessage;
		} else {
			errorInfoMessage = ruleFailureMessage;
		}
		moduleConfigUtil.addErrorInfoDataEvent(
				MatlabWrapperConstants.ERROR_CONTEXT_RULE_EXECUTION, 1,
				"AWP300", errorInfoMessage);
	}

	/**
	 * 
	 * @return
	 */
	public MatlabWrapperUtil getMatlabUtil() {
		if (matlabUtil == null) {
			matlabUtil = new MatlabWrapperUtil();
		}
		return matlabUtil;
	}

	public CAFXmlUtil getXmlUtil() {
		if (xmlUtil == null) {
			xmlUtil = new CAFXmlUtil();
		}
		return xmlUtil;
	}

	public void setXmlUtil(CAFXmlUtil xmlUtil) {
		this.xmlUtil = xmlUtil;
	}

	public ModuleConfigXMLRoot getXmlRoot() {
		return xmlRoot;
	}

	public void setXmlRoot(ModuleConfigXMLRoot xmlRoot) {
		this.xmlRoot = xmlRoot;
	}
}
