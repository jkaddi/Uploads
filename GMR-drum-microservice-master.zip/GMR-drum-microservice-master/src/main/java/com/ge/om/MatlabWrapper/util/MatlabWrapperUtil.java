/**
 * 
 */
package com.ge.om.MatlabWrapper.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.URI;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TimeZone;

import org.apache.log4j.Logger;

import com.ge.om.cafosacbm.Algorithm;
import com.ge.om.cafosacbm.AlgorithmInputValue;
import com.ge.om.cafosacbm.ModuleConfigXMLRoot;
import com.ge.om.cafxml.CAFModuleConfigUtil;

/**
 * @author 204048703
 *
 */
public class MatlabWrapperUtil {
	
	/**
	 * Properties object.
	 */
	private static Properties properties = new Properties();
	
//	private List<String> invalidConfig = new ArrayList<String>();
	

//	/**
//	 * @param xmlRoot - ModuleConfigRoot
//	 * @return retVal - String
//	 */
//	public String getModuleName(ModuleConfigXMLRoot xmlRoot) throws Exception{
//		String retStr = null;
//		CAFModuleConfigUtil xmlConfUtil = new CAFModuleConfigUtil(xmlRoot);
//		Algorithm configAlgoritham = xmlConfUtil.getConfigAlgorithm();
//		List<AlgorithmInputValue> inputValueLst = configAlgoritham.getInputValues();
//		 for(AlgorithmInputValue inputVal : inputValueLst){
//			 String moduleClassName = inputVal.getName();
//			if(MatlabWrapperConstants.MODULE_CLASS_NAME.equalsIgnoreCase(moduleClassName)){
//				 retStr = inputVal.getUserTag();;
//			 }
//		 }
//		return retStr;
//	}
	
	/**
	 * @param invalidConfig
	 */
	public MatlabWrapperUtil() {
		super();
//		this.invalidConfig.add(MatlabWrapperConstants.MODULE_CLASS_NAME.toUpperCase());
//		this.invalidConfig.add(MatlabWrapperConstants.RULE_PATH.toUpperCase());
	}
	
	static {
		try {
			ClassLoader clLoader = Thread.currentThread().getContextClassLoader();
			InputStream istream = clLoader.getResourceAsStream("matlabwrapper.properties");
			properties.load(istream);
				
		} catch (FileNotFoundException e) {
			Logger.getLogger(MatlabWrapperUtil.class).error(e.getMessage());
		} catch (IOException e) {
			Logger.getLogger(MatlabWrapperUtil.class).error(e.getMessage());
		} catch (Exception e) {
			Logger.getLogger(MatlabWrapperUtil.class).error(e.getMessage());
		}
	}
	
	public static String getProperty(String property) {
		return properties.getProperty(property);
	}
	
	/**
	 * 
	 * @param xmlRoot
	 * @return
	 * @throws Exception
	 */
	public Map<String, String> getInputValueMap(ModuleConfigXMLRoot xmlRoot) throws Exception{
		Map<String, String> inputValueMap = null;
		
		CAFModuleConfigUtil xmlConfUtil = new CAFModuleConfigUtil(xmlRoot);
		Algorithm configAlgoritham = xmlConfUtil.getConfigAlgorithm();
		List<AlgorithmInputValue> inputValueLst = configAlgoritham.getInputValues();
			
		if(inputValueLst != null && !inputValueLst.isEmpty()){
			inputValueMap = new HashMap<String, String>();

			for(AlgorithmInputValue inputValue: inputValueLst){
				if(inputValue.isConstant()){
					inputValueMap.put(inputValue.getName(), inputValue.getUserTag());
				}
			}
		}
		return inputValueMap;
	}
	
	public static void logInfo(Class <?> clazz, String message){
		Logger.getLogger(clazz).info(message);
	}
	
	public static void logError(Class<?> clazz, String message){
		Logger.getLogger(clazz).error(message);
	}

	public static void logDebug(Class<?> clazz, String message){
		Logger.getLogger(clazz).debug(message);
	}

	/**
	 * 
	 * @param xmlRoot
	 * @param ruleFailureMessage - the error message from the exception thrown by the analytic.
	 * @param ruleFailurePrefix - an optional caption to be prepended on the error message for the addErrorInfoDataEvent
	 * @return the AWP return code
	 * @throws Exception
	 */
	public String addErrorInfoDataEvent(ModuleConfigXMLRoot xmlRoot, String ruleFailureMessage, String ruleFailurePrefix) throws Exception{
		Map<String, Object> rulePathInfo = extractRulePathInfo(xmlRoot);
		String moduleClassName = (String)rulePathInfo.get(MatlabWrapperConstants.MODULE_CLASS_NAME);
		String awpReturnCode = MatlabAwpReturnCodes.getAwpReturnCode(moduleClassName, ruleFailureMessage);

		CAFModuleConfigUtil moduleConfigUtil = new CAFModuleConfigUtil(xmlRoot);
		
		String errorInfoMessage;
		if (ruleFailurePrefix != null) {
			errorInfoMessage = ruleFailurePrefix + ruleFailureMessage;
		} else {
			errorInfoMessage = ruleFailureMessage;
		}
		
		moduleConfigUtil.addErrorInfoDataEvent(
				MatlabWrapperConstants.ERROR_CONTEXT_RULE_EXECUTION, 1,
				awpReturnCode, errorInfoMessage);
		
		return awpReturnCode;
	}

	
	public String addErrorInfoDataEvent(ModuleConfigXMLRoot xmlRoot,
			String ruleFailureMessage) throws Exception{
		return addErrorInfoDataEvent(xmlRoot, ruleFailureMessage, null);
	}

	public void addAppInfoDataEvent(ModuleConfigXMLRoot xmlRoot,
			boolean analyticSucceeded, Date startTime, Date endTime) throws Exception{
		CAFModuleConfigUtil moduleConfigUtil = new CAFModuleConfigUtil(xmlRoot);
		moduleConfigUtil.addAppInfoDataEvent(analyticSucceeded, startTime,
				endTime);
		
	}
	
	public void addRuleFailedInfo(ModuleConfigXMLRoot xmlRoot, String ruleFailureMessage) throws Exception{
		//MatlabWrapperUtil.logInfo(getClass(), "In addRuleFailedInfo: " + ruleFailureMessage);
		addErrorInfoDataEvent(xmlRoot, ruleFailureMessage);
		addAppInfoDataEvent(xmlRoot, false, new Date(), new Date());
	}
	
	public String getTestCFData() throws Exception{
		String cfFile = "UnitNumber,DateTime,TagName,X,Y,F\n"+
				"297380,15:00.0,F1HR,0,NULL,0.968047\n"+
				"297380,15:00.0,F1HR,20,NULL,0.975879\n"+
				"297380,15:00.0,F1HR,40,NULL,0.985679\n"+
				"297380,15:00.0,F1HR,59,NULL,0.997098\n"+
				"297380,15:00.0,F1HR,63.15,NULL,1\n"+
				"297380,15:00.0,F1HR,70,NULL,1.00518\n"+
				"297380,15:00.0,F1HR,75,NULL,1.00932\n"+
				"297380,15:00.0,F1HR,80,NULL,1.01379\n"+
				"297380,15:00.0,F1HR,90,NULL,1.02377\n"+
				"297380,15:00.0,F1HR,100,NULL,1.03584\n"+
				"297380,15:00.0,F1P,0,NULL,1.21097\n"+
				"297380,15:00.0,F1P,20,NULL,1.14413\n"+
				"297380,15:00.0,F1P,40,NULL,1.07743\n"+
				"297380,15:00.0,F1P,59,NULL,1.0144\n"+
				"297380,15:00.0,F1P,63.15,NULL,0.999997\n"+
				"297380,15:00.0,F1P,70,NULL,0.976179\n"+
				"297380,15:00.0,F1P,75,NULL,0.958735\n"+
				"297380,15:00.0,F1P,80,NULL,0.941228\n"+
				"297380,15:00.0,F1P,90,NULL,0.905521\n"+
				"297380,15:00.0,F1P,100,NULL,0.867488\n"+
				"297380,15:00.0,F2HR,0,NULL,-47.6653\n"+
				"297380,15:00.0,F2HR,20,NULL,-32.3529\n"+
				"297380,15:00.0,F2HR,40,NULL,-17.1691\n"+
				"297380,15:00.0,F2HR,59,NULL,-2.70326\n"+
				"297380,15:00.0,F2HR,63.15,NULL,0.0004786\n"+
				"297380,15:00.0,F2HR,70,NULL,4.50221\n"+
				"297380,15:00.0,F2HR,75,NULL,7.82162\n"+
				"297380,15:00.0,F2HR,80,NULL,11.17\n"+
				"297380,15:00.0,F2HR,90,NULL,17.991\n"+
				"297380,15:00.0,F2HR,100,NULL,23.1954\n"+
				"297380,15:00.0,F2P,0,NULL,1.15341\n"+
				"297380,15:00.0,F2P,20,NULL,1.10459\n"+
				"297380,15:00.0,F2P,40,NULL,1.05628\n"+
				"297380,15:00.0,F2P,59,NULL,1.0102\n"+
				"297380,15:00.0,F2P,63.15,NULL,0.999998\n"+
				"297380,15:00.0,F2P,70,NULL,0.983007\n"+
				"297380,15:00.0,F2P,75,NULL,0.970468\n"+
				"297380,15:00.0,F2P,80,NULL,0.957796\n"+
				"297380,15:00.0,F2P,90,NULL,0.931294\n"+
				"297380,15:00.0,F2P,100,NULL,0.904183\n"+
				"297380,15:00.0,F3HR,0,0,1.00004\n"+
				"297380,15:00.0,F3HR,0,20,1.00003\n"+
				"297380,15:00.0,F3HR,0,40,1.00002\n"+
				"297380,15:00.0,F3HR,0,50,1.00002\n"+
				"297380,15:00.0,F3HR,0,60,1.00001\n"+
				"297380,15:00.0,F3HR,0,70,1.00001\n"+
				"297380,15:00.0,F3HR,0,80,1\n"+
				"297380,15:00.0,F3HR,0,100,0.999992\n"+
				"297380,15:00.0,F3HR,40,0,1.00012\n"+
				"297380,15:00.0,F3HR,40,20,1.00009\n"+
				"297380,15:00.0,F3HR,40,40,1.00006\n"+
				"297380,15:00.0,F3HR,40,50,1.00005\n"+
				"297380,15:00.0,F3HR,40,60,1.00003\n"+
				"297380,15:00.0,F3HR,40,70,1.00002\n"+
				"297380,15:00.0,F3HR,40,80,1.00001\n"+
				"297380,15:00.0,F3HR,40,100,0.999976\n"+
				"297380,15:00.0,F3HR,63.15,0,1.00064\n"+
				"297380,15:00.0,F3HR,63.15,20,1.00049\n"+
				"297380,15:00.0,F3HR,63.15,40,1.00034\n"+
				"297380,15:00.0,F3HR,63.15,50,1.00026\n"+
				"297380,15:00.0,F3HR,63.15,60,1.00019\n"+
				"297380,15:00.0,F3HR,63.15,70,1.00011\n"+
				"297380,15:00.0,F3HR,63.15,80,1.00003\n"+
				"297380,15:00.0,F3HR,63.15,100,0.99987\n"+
				"297380,15:00.0,F3HR,80,0,1.0014\n"+
				"297380,15:00.0,F3HR,80,20,1.00108\n"+
				"297380,15:00.0,F3HR,80,40,1.00075\n"+
				"297380,15:00.0,F3HR,80,50,1.00058\n"+
				"297380,15:00.0,F3HR,80,60,1.00041\n"+
				"297380,15:00.0,F3HR,80,70,1.00024\n"+
				"297380,15:00.0,F3HR,80,80,1.00006\n"+
				"297380,15:00.0,F3HR,80,100,0.999712\n"+
				"297380,15:00.0,F3HR,90,0,1.00243\n"+
				"297380,15:00.0,F3HR,90,20,1.00193\n"+
				"297380,15:00.0,F3HR,90,40,1.00142\n"+
				"297380,15:00.0,F3HR,90,50,1.00116\n"+
				"297380,15:00.0,F3HR,90,60,1.0009\n"+
				"297380,15:00.0,F3HR,90,70,1.00052\n"+
				"297380,15:00.0,F3HR,90,80,1.00014\n"+
				"297380,15:00.0,F3HR,90,100,0.999362\n"+
				"297380,15:00.0,F3HR,100,0,1.00455\n"+
				"297380,15:00.0,F3HR,100,20,1.0035\n"+
				"297380,15:00.0,F3HR,100,40,1.00243\n"+
				"297380,15:00.0,F3HR,100,50,1.00188\n"+
				"297380,15:00.0,F3HR,100,60,1.00133\n"+
				"297380,15:00.0,F3HR,100,70,1.00077\n"+
				"297380,15:00.0,F3HR,100,80,1.00021\n"+
				"297380,15:00.0,F3HR,100,100,0.999059\n"+
				"297380,15:00.0,F3P,0,NULL,1.17228\n"+
				"297380,15:00.0,F3P,20,NULL,1.11653\n"+
				"297380,15:00.0,F3P,40,NULL,1.062\n"+
				"297380,15:00.0,F3P,59,NULL,1.01146\n"+
				"297380,15:00.0,F3P,63.15,NULL,0.999998\n"+
				"297380,15:00.0,F3P,70,NULL,0.981237\n"+
				"297380,15:00.0,F3P,75,NULL,0.967668\n"+
				"297380,15:00.0,F3P,80,NULL,0.954209\n"+
				"297380,15:00.0,F3P,90,NULL,0.927042\n"+
				"297380,15:00.0,F3P,100,NULL,0.89858\n"+
				"297380,15:00.0,F4HR,0,0,1.00038\n"+
				"297380,15:00.0,F4HR,0,20,1.00029\n"+
				"297380,15:00.0,F4HR,0,40,1.0002\n"+
				"297380,15:00.0,F4HR,0,50,1.00015\n"+
				"297380,15:00.0,F4HR,0,60,1.00011\n"+
				"297380,15:00.0,F4HR,0,70,1.00006\n"+
				"297380,15:00.0,F4HR,0,80,1.00002\n"+
				"297380,15:00.0,F4HR,0,100,0.999925\n"+
				"297380,15:00.0,F4HR,40,0,1.00248\n"+
				"297380,15:00.0,F4HR,40,20,1.00189\n"+
				"297380,15:00.0,F4HR,40,40,1.00129\n"+
				"297380,15:00.0,F4HR,40,50,1.001\n"+
				"297380,15:00.0,F4HR,40,60,1.0007\n"+
				"297380,15:00.0,F4HR,40,70,1.0004\n"+
				"297380,15:00.0,F4HR,40,80,1.00011\n"+
				"297380,15:00.0,F4HR,40,100,0.999514\n"+
				"297380,15:00.0,F4HR,63.15,0,1.00586\n"+
				"297380,15:00.0,F4HR,63.15,20,1.00446\n"+
				"297380,15:00.0,F4HR,63.15,40,1.00306\n"+
				"297380,15:00.0,F4HR,63.15,50,1.00236\n"+
				"297380,15:00.0,F4HR,63.15,60,1.00166\n"+
				"297380,15:00.0,F4HR,63.15,70,1.00095\n"+
				"297380,15:00.0,F4HR,63.15,80,1.00025\n"+
				"297380,15:00.0,F4HR,63.15,100,0.998853\n"+
				"297380,15:00.0,F4HR,80,0,1.0104\n"+
				"297380,15:00.0,F4HR,80,20,1.00791\n"+
				"297380,15:00.0,F4HR,80,40,1.00543\n"+
				"297380,15:00.0,F4HR,80,50,1.00418\n"+
				"297380,15:00.0,F4HR,80,60,1.00294\n"+
				"297380,15:00.0,F4HR,80,70,1.0017\n"+
				"297380,15:00.0,F4HR,80,80,1.00045\n"+
				"297380,15:00.0,F4HR,80,100,0.997963\n"+
				"297380,15:00.0,F4HR,90,0,1.01432\n"+
				"297380,15:00.0,F4HR,90,20,1.0109\n"+
				"297380,15:00.0,F4HR,90,40,1.00747\n"+
				"297380,15:00.0,F4HR,90,50,1.00576\n"+
				"297380,15:00.0,F4HR,90,60,1.00405\n"+
				"297380,15:00.0,F4HR,90,70,1.00234\n"+
				"297380,15:00.0,F4HR,90,80,1.00062\n"+
				"297380,15:00.0,F4HR,90,100,0.997193\n"+
				"297380,15:00.0,F4HR,100,0,1.01948\n"+
				"297380,15:00.0,F4HR,100,20,1.01483\n"+
				"297380,15:00.0,F4HR,100,40,1.01017\n"+
				"297380,15:00.0,F4HR,100,50,1.00784\n"+
				"297380,15:00.0,F4HR,100,60,1.00551\n"+
				"297380,15:00.0,F4HR,100,70,1.00318\n"+
				"297380,15:00.0,F4HR,100,80,1.00085\n"+
				"297380,15:00.0,F4HR,100,100,0.996178\n"+
				"297380,15:00.0,F4P,0,0,0.999774\n"+
				"297380,15:00.0,F4P,0,20,0.999828\n"+
				"297380,15:00.0,F4P,0,40,0.999882\n"+
				"297380,15:00.0,F4P,0,50,0.999909\n"+
				"297380,15:00.0,F4P,0,60,0.999936\n"+
				"297380,15:00.0,F4P,0,70,0.999963\n"+
				"297380,15:00.0,F4P,0,80,0.99999\n"+
				"297380,15:00.0,F4P,0,100,1.00004\n"+
				"297380,15:00.0,F4P,40,0,0.998602\n"+
				"297380,15:00.0,F4P,40,20,0.998936\n"+
				"297380,15:00.0,F4P,40,40,0.99927\n"+
				"297380,15:00.0,F4P,40,50,0.999437\n"+
				"297380,15:00.0,F4P,40,60,0.999605\n"+
				"297380,15:00.0,F4P,40,70,0.999772\n"+
				"297380,15:00.0,F4P,40,80,0.999939\n"+
				"297380,15:00.0,F4P,40,100,1.00027\n"+
				"297380,15:00.0,F4P,63.15,0,0.996639\n"+
				"297380,15:00.0,F4P,63.15,20,0.99744\n"+
				"297380,15:00.0,F4P,63.15,40,0.998242\n"+
				"297380,15:00.0,F4P,63.15,50,0.998644\n"+
				"297380,15:00.0,F4P,63.15,60,0.999047\n"+
				"297380,15:00.0,F4P,63.15,70,0.99945\n"+
				"297380,15:00.0,F4P,63.15,80,0.999854\n"+
				"297380,15:00.0,F4P,63.15,100,1.00066\n"+
				"297380,15:00.0,F4P,80,0,0.993865\n"+
				"297380,15:00.0,F4P,80,20,0.995321\n"+
				"297380,15:00.0,F4P,80,40,0.996784\n"+
				"297380,15:00.0,F4P,80,50,0.997519\n"+
				"297380,15:00.0,F4P,80,60,0.998255\n"+
				"297380,15:00.0,F4P,80,70,0.998992\n"+
				"297380,15:00.0,F4P,80,80,0.999732\n"+
				"297380,15:00.0,F4P,80,100,1.00122\n"+
				"297380,15:00.0,F4P,90,0,0.99134\n"+
				"297380,15:00.0,F4P,90,20,0.993385\n"+
				"297380,15:00.0,F4P,90,40,0.995441\n"+
				"297380,15:00.0,F4P,90,50,0.996475\n"+
				"297380,15:00.0,F4P,90,60,0.997512\n"+
				"297380,15:00.0,F4P,90,70,0.998562\n"+
				"297380,15:00.0,F4P,90,80,0.999617\n"+
				"297380,15:00.0,F4P,90,100,1.00174\n"+
				"297380,15:00.0,F4P,100,0,0.987868\n"+
				"297380,15:00.0,F4P,100,20,0.99073\n"+
				"297380,15:00.0,F4P,100,40,0.993617\n"+
				"297380,15:00.0,F4P,100,50,0.995068\n"+
				"297380,15:00.0,F4P,100,60,0.996527\n"+
				"297380,15:00.0,F4P,100,70,0.997993\n"+
				"297380,15:00.0,F4P,100,80,0.999465\n"+
				"297380,15:00.0,F4P,100,100,1.00243\n"+
				"297380,15:00.0,F7HR,0,0,0.999812\n"+
				"297380,15:00.0,F7HR,0,20,0.999857\n"+
				"297380,15:00.0,F7HR,0,40,0.999902\n"+
				"297380,15:00.0,F7HR,0,50,0.999924\n"+
				"297380,15:00.0,F7HR,0,60,0.999947\n"+
				"297380,15:00.0,F7HR,0,70,0.999969\n"+
				"297380,15:00.0,F7HR,0,80,0.999992\n"+
				"297380,15:00.0,F7HR,0,100,1.00004\n"+
				"297380,15:00.0,F7HR,40,0,0.99872\n"+
				"297380,15:00.0,F7HR,40,20,0.999026\n"+
				"297380,15:00.0,F7HR,40,40,0.999332\n"+
				"297380,15:00.0,F7HR,40,50,0.999485\n"+
				"297380,15:00.0,F7HR,40,60,0.999638\n"+
				"297380,15:00.0,F7HR,40,70,0.999791\n"+
				"297380,15:00.0,F7HR,40,80,0.999945\n"+
				"297380,15:00.0,F7HR,40,100,1.00025\n"+
				"297380,15:00.0,F7HR,63.15,0,0.997279\n"+
				"297380,15:00.0,F7HR,63.15,20,0.99793\n"+
				"297380,15:00.0,F7HR,63.15,40,0.998581\n"+
				"297380,15:00.0,F7HR,63.15,50,0.998906\n"+
				"297380,15:00.0,F7HR,63.15,60,0.999232\n"+
				"297380,15:00.0,F7HR,63.15,70,0.999557\n"+
				"297380,15:00.0,F7HR,63.15,80,0.999882\n"+
				"297380,15:00.0,F7HR,63.15,100,1.00053\n"+
				"297380,15:00.0,F7HR,80,0,0.995255\n"+
				"297380,15:00.0,F7HR,80,20,0.996392\n"+
				"297380,15:00.0,F7HR,80,40,0.997527\n"+
				"297380,15:00.0,F7HR,80,50,0.998095\n"+
				"297380,15:00.0,F7HR,80,60,0.998661\n"+
				"297380,15:00.0,F7HR,80,70,0.99923\n"+
				"297380,15:00.0,F7HR,80,80,0.999795\n"+
				"297380,15:00.0,F7HR,80,100,1.00093\n"+
				"297380,15:00.0,F7HR,90,0,0.993748\n"+
				"297380,15:00.0,F7HR,90,20,0.995306\n\n"+
				"297380,15:00.0,F7HR,90,40,0.996858\n"+
				"297380,15:00.0,F7HR,90,50,0.997634\n"+
				"297380,15:00.0,F7HR,90,60,0.99841\n"+
				"297380,15:00.0,F7HR,90,70,0.999086\n"+
				"297380,15:00.0,F7HR,90,80,0.999757\n"+
				"297380,15:00.0,F7HR,90,100,1.0011\n"+
				"297380,15:00.0,F7HR,100,0,0.992367\n"+
				"297380,15:00.0,F7HR,100,20,0.994202\n"+
				"297380,15:00.0,F7HR,100,40,0.99603\n"+
				"297380,15:00.0,F7HR,100,50,0.996941\n"+
				"297380,15:00.0,F7HR,100,60,0.997853\n"+
				"297380,15:00.0,F7HR,100,70,0.998762\n"+
				"297380,15:00.0,F7HR,100,80,0.999671\n"+
				"297380,15:00.0,F7HR,100,100,1.00148\n"+
				"297380,15:00.0,F7P,0,0,-0.100269\n"+
				"297380,15:00.0,F7P,0,20,-0.076289\n"+
				"297380,15:00.0,F7P,0,40,-0.0523088\n"+
				"297380,15:00.0,F7P,0,50,-0.0403186\n"+
				"297380,15:00.0,F7P,0,60,-0.0283284\n"+
				"297380,15:00.0,F7P,0,70,-0.016338\n"+
				"297380,15:00.0,F7P,0,80,-0.0043476\n"+
				"297380,15:00.0,F7P,0,100,0.0196334\n"+
				"297380,15:00.0,F7P,40,0,-0.596855\n"+
				"297380,15:00.0,F7P,40,20,-0.454139\n"+
				"297380,15:00.0,F7P,40,40,-0.311404\n"+
				"297380,15:00.0,F7P,40,50,-0.240031\n"+
				"297380,15:00.0,F7P,40,60,-0.168652\n"+
				"297380,15:00.0,F7P,40,70,-0.0972698\n"+
				"297380,15:00.0,F7P,40,80,-0.0258827\n"+
				"297380,15:00.0,F7P,40,100,0.116905\n"+
				"297380,15:00.0,F7P,63.15,0,-1.1286\n"+
				"297380,15:00.0,F7P,63.15,20,-0.858572\n"+
				"297380,15:00.0,F7P,63.15,40,-0.589377\n"+
				"297380,15:00.0,F7P,63.15,50,-0.454306\n"+
				"297380,15:00.0,F7P,63.15,60,-0.319219\n"+
				"297380,15:00.0,F7P,63.15,70,-0.184114\n"+
				"297380,15:00.0,F7P,63.15,80,-0.0489923\n"+
				"297380,15:00.0,F7P,63.15,100,0.222363\n"+
				"297380,15:00.0,F7P,80,0,-1.9295\n"+
				"297380,15:00.0,F7P,80,20,-1.46842\n"+
				"297380,15:00.0,F7P,80,40,-1.00713\n"+
				"297380,15:00.0,F7P,80,50,-0.776411\n"+
				"297380,15:00.0,F7P,80,60,-0.545637\n"+
				"297380,15:00.0,F7P,80,70,-0.313499\n"+
				"297380,15:00.0,F7P,80,80,-0.0837501\n"+
				"297380,15:00.0,F7P,80,100,0.378357\n"+
				"297380,15:00.0,F7P,90,0,-2.39103\n"+
				"297380,15:00.0,F7P,90,20,-1.77146\n"+
				"297380,15:00.0,F7P,90,40,-1.15486\n"+
				"297380,15:00.0,F7P,90,50,-0.845512\n"+
				"297380,15:00.0,F7P,90,60,-0.535885\n"+
				"297380,15:00.0,F7P,90,70,-0.307547\n"+
				"297380,15:00.0,F7P,90,80,-0.0818463\n"+
				"297380,15:00.0,F7P,90,100,0.369804\n"+
				"297380,15:00.0,F7P,100,0,-2.48954\n"+
				"297380,15:00.0,F7P,100,20,-1.89416\n"+
				"297380,15:00.0,F7P,100,40,-1.29915\n"+
				"297380,15:00.0,F7P,100,50,-1.00255\n"+
				"297380,15:00.0,F7P,100,60,-0.704586\n"+
				"297380,15:00.0,F7P,100,70,-0.406466\n"+
				"297380,15:00.0,F7P,100,80,-0.108181\n"+
				"297380,15:00.0,F7P,100,100,0.487547\n"+
				"297380,15:00.0,F8PA,59,0,0.986137\n"+
				"297380,15:00.0,F8PA,59,20,0.988543\n"+
				"297380,15:00.0,F8PA,59,30,0.989727\n"+
				"297380,15:00.0,F8PA,59,60,0.993199\n"+
				"297380,15:00.0,F8PA,59,80,0.995442\n"+
				"297380,15:00.0,F8PA,59,100,0.997642\n"+
				"297380,15:00.0,F8PA,63.5556,0,0.987629\n"+
				"297380,15:00.0,F8PA,63.5556,20,0.990423\n"+
				"297380,15:00.0,F8PA,63.5556,30,0.991798\n"+
				"297380,15:00.0,F8PA,63.5556,60,0.99581\n"+
				"297380,15:00.0,F8PA,63.5556,80,0.998406\n"+
				"297380,15:00.0,F8PA,63.5556,100,1.00094\n"+
				"297380,15:00.0,F8PA,68.1111,0,0.989117\n"+
				"297380,15:00.0,F8PA,68.1111,20,0.992358\n"+
				"297380,15:00.0,F8PA,68.1111,30,0.993948\n"+
				"297380,15:00.0,F8PA,68.1111,60,0.998578\n"+
				"297380,15:00.0,F8PA,68.1111,80,1.00156\n"+
				"297380,15:00.0,F8PA,68.1111,100,1.00446\n"+
				"297380,15:00.0,F8PA,72.6667,0,0.990601\n"+
				"297380,15:00.0,F8PA,72.6667,20,0.994351\n"+
				"297380,15:00.0,F8PA,72.6667,30,0.996181\n"+
				"297380,15:00.0,F8PA,72.6667,60,1.00151\n"+
				"297380,15:00.0,F8PA,72.6667,80,1.00492\n"+
				"297380,15:00.0,F8PA,72.6667,100,1.00825\n"+
				"297380,15:00.0,F8PA,77.2222,0,0.992086\n"+
				"297380,15:00.0,F8PA,77.2222,20,0.996407\n"+
				"297380,15:00.0,F8PA,77.2222,30,0.998523\n"+
				"297380,15:00.0,F8PA,77.2222,60,1.00462\n"+
				"297380,15:00.0,F8PA,77.2222,80,1.00853\n"+
				"297380,15:00.0,F8PA,77.2222,100,1.01233\n"+
				"297380,15:00.0,F8PA,81.7778,0,0.993572\n"+
				"297380,15:00.0,F8PA,81.7778,20,0.998551\n"+
				"297380,15:00.0,F8PA,81.7778,30,1.00097\n"+
				"297380,15:00.0,F8PA,81.7778,60,1.00794\n"+
				"297380,15:00.0,F8PA,81.7778,80,1.0124\n"+
				"297380,15:00.0,F8PA,81.7778,100,1.0167\n"+
				"297380,15:00.0,F8PA,86.3333,0,0.995057\n"+
				"297380,15:00.0,F8PA,86.3333,20,1.00077\n"+
				"297380,15:00.0,F8PA,86.3333,30,1.00354\n"+
				"297380,15:00.0,F8PA,86.3333,60,1.01149\n"+
				"297380,15:00.0,F8PA,86.3333,80,1.01653\n"+
				"297380,15:00.0,F8PA,86.3333,100,1.02138\n"+
				"297380,15:00.0,F8PA,90.89,0,0.996542\n"+
				"297380,15:00.0,F8PA,90.89,20,1.00309\n"+
				"297380,15:00.0,F8PA,90.89,30,1.00624\n"+
				"297380,15:00.0,F8PA,90.89,60,1.01527\n"+
				"297380,15:00.0,F8PA,90.89,80,1.02093\n"+
				"297380,15:00.0,F8PA,90.89,100,1.02651\n"+
				"297380,15:00.0,F8PA,95.4444,0,0.998041\n"+
				"297380,15:00.0,F8PA,95.4444,20,1.0055\n"+
				"297380,15:00.0,F8PA,95.4444,30,1.00909\n"+
				"297380,15:00.0,F8PA,95.4444,60,1.01927\n"+
				"297380,15:00.0,F8PA,95.4444,80,1.02575\n"+
				"297380,15:00.0,F8PA,95.4444,100,1.03214\n"+
				"297380,15:00.0,F8PA,100,0,0.999536\n"+
				"297380,15:00.0,F8PA,100,20,1.00804\n"+
				"297380,15:00.0,F8PA,100,30,1.0121\n"+
				"297380,15:00.0,F8PA,100,60,1.02358\n"+
				"297380,15:00.0,F8PA,100,80,1.03102\n"+
				"297380,15:00.0,F8PA,100,100,1.03825\n"+
				"297380,15:00.0,F8REF,59,0,1.07372\n"+
				"297380,15:00.0,F8REF,59,20,1.06006\n"+
				"297380,15:00.0,F8REF,59,30,1.05358\n"+
				"297380,15:00.0,F8REF,59,60,1.03558\n"+
				"297380,15:00.0,F8REF,59,80,1.02464\n"+
				"297380,15:00.0,F8REF,59,100,1.01433\n"+
				"297380,15:00.0,F8REF,63.5556,0,1.06455\n"+
				"297380,15:00.0,F8REF,63.5556,20,1.04922\n"+
				"297380,15:00.0,F8REF,63.5556,30,1.04201\n"+
				"297380,15:00.0,F8REF,63.5556,60,1.0222\n"+
				"297380,15:00.0,F8REF,63.5556,80,1.01001\n"+
				"297380,15:00.0,F8REF,63.5556,100,0.998499\n"+
				"297380,15:00.0,F8REF,68.1111,0,1.05566\n"+
				"297380,15:00.0,F8REF,68.1111,20,1.03849\n"+
				"297380,15:00.0,F8REF,68.1111,30,1.03051\n"+
				"297380,15:00.0,F8REF,68.1111,60,1.00847\n"+
				"297380,15:00.0,F8REF,68.1111,80,0.995007\n"+
				"297380,15:00.0,F8REF,68.1111,100,0.982643\n"+
				"297380,15:00.0,F8REF,72.6667,0,1.04701\n"+
				"297380,15:00.0,F8REF,72.6667,20,1.02787\n"+
				"297380,15:00.0,F8REF,72.6667,30,1.01906\n"+
				"297380,15:00.0,F8REF,72.6667,60,0.99446\n"+
				"297380,15:00.0,F8REF,72.6667,80,0.979962\n"+
				"297380,15:00.0,F8REF,72.6667,100,0.966739\n"+
				"297380,15:00.0,F8REF,77.2222,0,1.03862\n"+
				"297380,15:00.0,F8REF,77.2222,20,1.01731\n"+
				"297380,15:00.0,F8REF,77.2222,30,1.00726\n"+
				"297380,15:00.0,F8REF,77.2222,60,0.980416\n"+
				"297380,15:00.0,F8REF,77.2222,80,0.964862\n"+
				"297380,15:00.0,F8REF,77.2222,100,0.950784\n"+
				"297380,15:00.0,F8REF,81.7778,0,1.03043\n"+
				"297380,15:00.0,F8REF,81.7778,20,1.00642\n"+
				"297380,15:00.0,F8REF,81.7778,30,0.995351\n"+
				"297380,15:00.0,F8REF,81.7778,60,0.966319\n"+
				"297380,15:00.0,F8REF,81.7778,80,0.949702\n"+
				"297380,15:00.0,F8REF,81.7778,100,0.934725\n"+
				"297380,15:00.0,F8REF,86.3333,0,1.02246\n"+
				"297380,15:00.0,F8REF,86.3333,20,0.9955\n"+
				"297380,15:00.0,F8REF,86.3333,30,0.983429\n"+
				"297380,15:00.0,F8REF,86.3333,60,0.952155\n"+
				"297380,15:00.0,F8REF,86.3333,80,0.934426\n"+
				"297380,15:00.0,F8REF,86.3333,100,0.918531\n"+
				"297380,15:00.0,F8REF,90.89,0,1.01468\n"+
				"297380,15:00.0,F8REF,90.89,20,0.984605\n"+
				"297380,15:00.0,F8REF,90.89,30,0.971484\n"+
				"297380,15:00.0,F8REF,90.89,60,0.937898\n"+
				"297380,15:00.0,F8REF,90.89,80,0.919013\n"+
				"297380,15:00.0,F8REF,90.89,100,0.901652\n"+
				"297380,15:00.0,F8REF,95.4444,0,1.00675\n"+
				"297380,15:00.0,F8REF,95.4444,20,0.97371\n"+
				"297380,15:00.0,F8REF,95.4444,30,0.959499\n"+
				"297380,15:00.0,F8REF,95.4444,60,0.92348\n"+
				"297380,15:00.0,F8REF,95.4444,80,0.903021\n"+
				"297380,15:00.0,F8REF,95.4444,100,0.884251\n"+
				"297380,15:00.0,F8REF,100,0,0.999032\n"+
				"297380,15:00.0,F8REF,100,20,0.962803\n"+
				"297380,15:00.0,F8REF,100,30,0.947461\n"+
				"297380,15:00.0,F8REF,100,60,0.908877\n"+
				"297380,15:00.0,F8REF,100,80,0.886433\n"+
				"297380,15:00.0,F8REF,100,100,0.866802\n";	
	return cfFile;
	}
	
	public String getFileLocation(String fileName) throws Exception {
		ClassLoader cl = Thread.currentThread().getContextClassLoader();
		URL url = cl.getResource(fileName);
		URI uri = null;
		String file = null;
		if (url != null) {
			uri = new URI(url.getFile());
			file = uri.getPath();
		}
		return file;
	}

	/**
	 * 
	 * @param xmlRoot
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object>  extractRulePathInfo(ModuleConfigXMLRoot xmlRoot) throws Exception {
		HashMap< String, Object> retMap = new HashMap<String, Object>();
		String modClassName = "";
		String rulePath = "";
		int debugMode = MatlabWrapperConstants.RULE_DEBUG_MODE_DEFAULT;
		
		CAFModuleConfigUtil xmlConfUtil = new CAFModuleConfigUtil(xmlRoot);
		Algorithm configAlgoritham = xmlConfUtil.getConfigAlgorithm();
		List<AlgorithmInputValue> inputValueLst = configAlgoritham.getInputValues();
		 for(AlgorithmInputValue inputVal : inputValueLst){
			 String inputValueName = inputVal.getName();
			if(MatlabWrapperConstants.MODULE_CLASS_NAME.equalsIgnoreCase(inputValueName)){
				 modClassName = inputVal.getUserTag();;
			 } else if(MatlabWrapperConstants.RULE_PATH.equalsIgnoreCase(inputValueName)){
				 rulePath = inputVal.getUserTag();
			 } else if(MatlabWrapperConstants.RULE_DEBUG_MODE.equalsIgnoreCase(inputValueName)){
				 debugMode = Integer.valueOf(inputVal.getUserTag()); 
			 }
		 }
		retMap.put(MatlabWrapperConstants.MODULE_CLASS_NAME, modClassName);
		retMap.put(MatlabWrapperConstants.RULE_PATH, rulePath);
		retMap.put(MatlabWrapperConstants.RULE_DEBUG_MODE, debugMode);
		
		return retMap;
				
	}

	/**
	 * 
	 * @param key
	 * @return
	 */
//	public boolean isValidConfig(String key) {
//		boolean retVal = true;
//		retVal = invalidConfig.contains(key.toUpperCase());
//		return !retVal;
//	}

	public double getMatlabDateNum(long timeStamp) {
		 //1343966700000
		double retVal =0;  
		double matlabDateNum =  timeStamp/86400.0 + 719529.0;
	    java.text.DecimalFormat decimalFormat = new java.text.DecimalFormat("000000.00000");
		decimalFormat.setRoundingMode(java.math.RoundingMode.UP);
		String sMatlabTimeStamp = decimalFormat.format(matlabDateNum);
		retVal = Double.parseDouble(sMatlabTimeStamp);
	    return retVal;
	}
	
	public double getUnixDate(double matlabDateNum) {
		 double retVal =0;
		 
		 java.text.DecimalFormat decimalFormat = new java.text.DecimalFormat("000000.00000");
		 decimalFormat.setRoundingMode(java.math.RoundingMode.UP);
		 String sMatlabTimeStamp = decimalFormat.format(matlabDateNum);
		 matlabDateNum = Double.parseDouble(sMatlabTimeStamp);
		 //System.out.println((long)((matlabDateNum - 719529.0) * 86400000.0));
		 retVal = getGMTTimeInMilliSeconds( (long)((matlabDateNum - 719529.0) * 86400000.0) ); 
		 
		 return retVal;
	}
	
	public long getGMTTimeInMilliSeconds(long localTime) {
		
		long timeInMilliSec = 0;
		
		Calendar cal_GMT = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
		Calendar cal_local = new GregorianCalendar();
		
		cal_GMT.setTimeInMillis(localTime);
		
		cal_local.set(Calendar.YEAR, cal_GMT.get(Calendar.YEAR));
		cal_local.set(Calendar.MONTH, cal_GMT.get(Calendar.MONTH));
		cal_local.set(Calendar.DAY_OF_MONTH, cal_GMT.get(Calendar.DAY_OF_MONTH));
		cal_local.set(Calendar.HOUR_OF_DAY, cal_GMT.get(Calendar.HOUR_OF_DAY));
		cal_local.set(Calendar.MINUTE, cal_GMT.get(Calendar.MINUTE));
		cal_local.set(Calendar.SECOND, cal_GMT.get(Calendar.SECOND));
		cal_local.set(Calendar.MILLISECOND, cal_GMT.get(Calendar.MILLISECOND));
		
		timeInMilliSec = cal_local.getTimeInMillis();
		
		return timeInMilliSec;
	
	}
	
	/**
	 * get site ID from XML
	 * @param xmlRoot
	 * @return
	 * @throws Exception
	 */
	public String getSiteId(ModuleConfigXMLRoot xmlRoot) throws Exception {
	    CAFModuleConfigUtil moduleConfigUtil = new CAFModuleConfigUtil(xmlRoot);
	    
	    String siteId = null;
	    Algorithm alg = moduleConfigUtil.getGlobalAlgorithm();
	    siteId = alg.getInputData().get(0).getInputRef().getSite().getSiteId();
	    
		return siteId;
	}
	
	/**
	 * get the Host Name.
	 * @return
	 */
	public String getHostName() {
		String hostname = null;
		
		try {
			InetAddress addr = InetAddress.getLocalHost();
			hostname = addr.getHostName();
		} catch (UnknownHostException e) {
			hostname = getIPAddress("UNKNOWN");
		}
		
		return hostname;
	}
	
	/**
	 * Gets the ip address.
	 * 
	 * @param id
	 *            String
	 * @param id
	 * @return String the IP address
	 * @roseuid 4AD0264E003E
	 */
	private String getIPAddress(String id) {
		String ip = null;

		try {
			InetAddress addr = InetAddress.getLocalHost();
			ip = addr.getHostAddress();
		} catch (UnknownHostException e) {
			ip = id;
		}

		return ip;
	}
}
