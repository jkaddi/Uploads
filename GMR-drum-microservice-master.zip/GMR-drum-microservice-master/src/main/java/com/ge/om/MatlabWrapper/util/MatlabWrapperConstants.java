/**
 * 
 */
package com.ge.om.MatlabWrapper.util;

/**
 * @author 204048703
 *
 */
public class MatlabWrapperConstants {
	public final static  String MODULE_CLASS_NAME = "ModuleClassName";
	public final static  String RULE_PATH = "RULE_PATH";
	public final static String RULE_DEBUG_MODE = "RULE_DEBUG_MODE";
	
	//Matlab methods
	public final static String CHECK_COMPATIBLE_CONFIGURATION = "BAE_proxy_check_compatible_configuration";
	public final static String CHECK_INPUTS = "BAE_proxy_check_inputs";
	
	public final static String READ_STATE_INFO = "ReadStateInfo";
	public final static String CORRECTION_FACTOR = "CorrectionFactor";
	public final static String SEMISTATIC_STATE_DATA = "ReadSSSD";
	public final static String LEVEL2DATA = "ReadL2Data";
	
	public final static String INSERT_SEMISTATIC_STATE_DATA = "InsertSSSD";

	public static final String SUCESS = "RS";

	public static final String FAILUR = "RF";

	public static final String ERROR_CONTEXT_RULE_EXECUTION = "RULE_EXECUTION";
	
	public static final String NULL_VAL = "NULL";
	
	public static final long TIMESERIES_ARGID = 1;
	public static final long OBJECT_ARGID = 2;
	public static final int RULE_DEBUG_MODE_DEFAULT = 0;
	
	public static final String EMPTY_STATE = "AAIAAAAAAAAAAA==";
	
	public static final long DEFAULT_ALARMTYPE = 2; //Alert
	public static final long DEFAULT_MATLAB_PROCESS_TIMEOUT = 3600;

	public static final String ALARM_NAME = "Name";
	public static final String ALARM_SEVERITY = "Severity";
	public static final String ALARM_SG = "SG";
	public static final String ALARM_DATETIME = "DateTime";
	public static final String ALARM_ASSETID = "AssetID";
	public static final String MATLAB_PROCESS_TIMEOUT = "matlab.process.timeout";
	public final static String PROXY_ANALYSE = "OM_proxy_analyse";
	public final static String NUMBER_OUTPUT_ARGS_METHOD = "number_output_args";
	//static configuration tags
//	public static final int STATIC_CONFIGURATION_TAG_CNT = 2;
//	public static final String STATIC_CONFIGURATION_TAG_1 = "TsNo";
//	public static final String STATIC_CONFIGURATION_TAG_2 = "EquipmentId";
}
