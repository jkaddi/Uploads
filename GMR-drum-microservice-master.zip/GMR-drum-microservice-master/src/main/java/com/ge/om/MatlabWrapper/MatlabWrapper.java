/**
 * 
 * The information contained in this document is General Electric Company (GE 
 * proprietary information and is disclosed in confidence. It is the property 
 * of GE and shall not be used, disclosed to others or reproduced without the 
 * express written consent of GE. If consent is given for reproduction in whole 
 * or in part, this notice and the notice set forth on each page of this document 
 * shall appear in any such reproduction in whole or in part. The information 
 * contained in this document may also be controlled by the U.S. export control 
 * laws.  Unauthorized export or re-export is prohibited.
 * 
 * This module is intended for:  (Choose one of the following options)
 *      Military use only
 *  X   Commercial use only
 *      Both military and commercial use
 */
package com.ge.om.MatlabWrapper;

import java.io.File;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLClassLoader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.ge.energy.ssg.framework.util.blob.BlobUtil;
import com.ge.energy.ssg.framework.util.blob.TagValue;
import com.ge.om.MatlabWrapper.util.CustomURLClassLoader;
import com.ge.om.MatlabWrapper.util.MatlabWrapperConstants;
import com.ge.om.MatlabWrapper.util.MatlabWrapperUtil;
import com.ge.om.cafosacbm.Algorithm;
import com.ge.om.cafosacbm.AlgorithmInputData;
import com.ge.om.cafosacbm.DMBLOBData;
import com.ge.om.cafosacbm.DataEvent;
import com.ge.om.cafosacbm.DataEventSet;
import com.ge.om.cafosacbm.ModuleConfigXMLRoot;
import com.ge.om.cafosacbm.NumAlert;
import com.ge.om.cafosacbm.OsacbmTime;
import com.ge.om.cafosacbm.OsacbmTimeType;
import com.ge.om.cafosacbm.SITECATEGORY;
import com.ge.om.cafosacbm.Site;
import com.ge.om.cafxml.CAFModuleConfigUtil;
import com.ge.om.cafxml.CAFXmlUtil;
import com.mathworks.toolbox.javabuilder.MWArray;
import com.mathworks.toolbox.javabuilder.MWCellArray;
import com.mathworks.toolbox.javabuilder.MWCharArray;
import com.mathworks.toolbox.javabuilder.MWNumericArray;
import com.mathworks.toolbox.javabuilder.MWStructArray;

/**
 * @author A27A4JT
 * 
 */
@Component
public class MatlabWrapper {

	// This flag becomes true if the wrapper encounters an error while running
	// rule.
	private boolean ruleFailure = false;

	// Stores the error message to be returned in getOsaReturnDataEventSet
	private String ruleFailureMessage = "";

	// Variable storing result from rule execution
	private Object[] analyticsResult;

	private Date startTime, endTime;
	private ModuleConfigXMLRoot xmlRoot;
	
	private CAFXmlUtil xmlUtil;
	
	public ModuleConfigXMLRoot getXmlRoot() {
		return xmlRoot;
	}

	private BlobUtil blobUtil = null;
	private CAFModuleConfigUtil moduleConfigUtil = null;
	private MatlabWrapperUtil matlabUtil = null;
	private int debugMode;

	// Used for sizing the data cell array
	private int highItemCount = 0; // used to determine the size of the
									// CellArray holds the highest number of
									// points
	private int tagCount = 1; // The number of tags passed in the CellArray,
								// minimum is DateTime

	// Used for sizing the correction factor cell array (same as above).
	private int cfHighItemCount = 0;
	private int cfTagCount = 0;

	private long idState = -1;
	private long idCorrFactor = -1;
	private long idSSSD = -1;
	private long idLevel2Data = -1;

	private boolean cfIsSet = false; // flag for CorrectFactor
	private boolean stIsSet = false; // flag for State
	private boolean sssdIsSet = false; // flag for Semi-static State Data
	private boolean isLevel2DataSet = false;

	private MWCellArray stateA = new MWCellArray(new int[] { 1, 1 });
	private MWCellArray innerMetadata = null; // Metadata
	private MWCellArray innerCFMetadata = null; // Metadata for CF
	private MWCellArray outerMetadata = null; // Metadata
	private MWNumericArray innerQualityData = null;
	private MWNumericArray innerCFQualityData = null;
	private MWCellArray outerQualityData = null; // Quality
	private MWNumericArray innerData1 = null;
	private MWNumericArray innerCf = null;
	private MWCellArray outerData1 = null;
	private MWCellArray title = null; // title
	private MWCellArray sssdA = null;
	private MWCellArray l2inputData = null;

	private Map<String, List<TagValue<?>>> tagValueMap = new HashMap<String, List<TagValue<?>>>(); // Data
																									// TagValue
	private Map<String, List<TagValue<Double>>> cfTagValueMap = new HashMap<String, List<TagValue<Double>>>(); // CorrectionFactor

	// map
	private String awpReturnCode = null;
	private String ruleFailurePrefix = null;

	protected void createOutputXml() throws Exception {
		MWCharArray stateArray = null;
		MWCellArray metadata = null;
		MWCellArray resultsArray = null;
		MWNumericArray results = null;
		MWNumericArray qualityArray = null;
		MWCellArray alarmArray = null;
		List<Alarm> alarmList = null;
		MWCellArray sssdArrayMap = null;
		try {
			String str;
			boolean ruleSuccess = true;
			Map<String, List<TagValue<?>>> returnTvMap = null;
			MatlabWrapperUtil.logInfo(getClass(), "ruleSuccess=" + ruleSuccess);
			if (ruleFailure) {
				ruleSuccess = false;
				addErrorInfoDataEvent(ruleFailureMessage, ruleFailurePrefix);
			} else {
				
				if(idLevel2Data != -1 && isLevel2DataSet)
				{
					metadata = (MWCellArray) analyticsResult[0];
					String[][] finalOPDate = new String[metadata.getDimensions().length][2];
					
					for(int i = 1; i < metadata.getDimensions().length; i++)
					{
						int[] sssdInfoInd = new int[] { i, 1 };
						int[] sssdBlobInd = new int[] { i, 2 };

						String s1 = metadata.getCell(sssdInfoInd).toString();
						String s2 = metadata.getCell(sssdBlobInd).toString();
						
						finalOPDate[i-1][0]= s1;
						finalOPDate[i-1][1]= s2;
					}
					
					
					byte[] blobData = getBlobUtil().convertObjectToByteArray(finalOPDate);
					long index = getModuleConfigUtil().addBlobDataEvent(
							CAFModuleConfigUtil.ARGID_OM_OBJECT, blobData);
					getModuleConfigUtil().setAlgorithmOutputIds(
							MatlabWrapperConstants.OBJECT_ARGID,
							index);
					
					//addAppInfoDataEvent(ruleSuccess);
				}
				else{
					
				// Add the state

				if (analyticsResult[4] != null) {
					stateArray = (MWCharArray) analyticsResult[4];
					long indexIdForState = addStateInfo(stateArray.toString());
					getModuleConfigUtil().setAlgorithmOutputIds(
							MatlabWrapperConstants.OBJECT_ARGID,
							indexIdForState);
				}

				// Add the data points
				metadata = (MWCellArray) analyticsResult[0];
				resultsArray = (MWCellArray) analyticsResult[1];
				qualityArray = (MWNumericArray) analyticsResult[2];

				// Get the date/time
				if (metadata.isEmpty()) {
					ruleSuccess = false;
					String errMsg = "Unable to find read metadata, returning an empty event set";
					addErrorInfoDataEvent(errMsg, ruleFailurePrefix);
				} else {
					double[] timestamps = null;
					// Find the date/time and set up the timestamps and
					// xAxisStart
					for (int counter = 1; counter <= (metadata
							.numberOfElements() / 2); counter++) {
						str = metadata.getCell(counter).toString();
						if (str.equals("DateTime")) {
							results = (MWNumericArray) resultsArray
									.getCell(counter);
							timestamps = results.getDoubleData();
							for (int i = 0; i < timestamps.length; i++) {
								double matlabDateNum = timestamps[i];
								timestamps[i] = getMatlabUtil().getUnixDate(
										matlabDateNum);
							}
						}
					}
					// We can't build a data set without time...
					if (timestamps == null) {
						ruleSuccess = false;
						String errMsg = "Unable to find DateTime in result set, returning without data arrays";
						addErrorInfoDataEvent(errMsg, ruleFailurePrefix);
					} else {
						returnTvMap = getTagValueMap(metadata, resultsArray,
								qualityArray, timestamps);
					}

				}

				MatlabWrapperUtil.logInfo(this.getClass(),
						"analyticsResult size : " + analyticsResult.length);
				if (analyticsResult.length >= 10) {
					MatlabWrapperUtil.logDebug(this.getClass(),
							"analyticsResult : " + analyticsResult[9]);
					alarmArray = (MWCellArray) analyticsResult[9];

					MatlabWrapperUtil.logInfo(
							this.getClass(),
							"Number of alarms received : "
									+ alarmArray.numberOfElements());

					alarmList = extractAlarmDetails(alarmArray);

					// Semi-static State Data
					if(analyticsResult.length >= 11 &&  (analyticsResult[10] != null))
					{
						sssdArrayMap = (MWCellArray) analyticsResult[10];
						
						ArrayList<String> sssdInfo = new ArrayList<String>();
						ArrayList<String> sssdBlob = new ArrayList<String>();
						
						for (int i = 1; i <= sssdArrayMap.getDimensions()[0]; i++) 
						{
							int[] sssdInfoInd = new int[] { i, 1 };
							int[] sssdBlobInd = new int[] { i, 2 };

							sssdInfo.add(sssdArrayMap.getCell(sssdInfoInd).toString());
							sssdBlob.add(sssdArrayMap.getCell(sssdBlobInd).toString());
						}
						MatlabWrapperUtil.logDebug(this.getClass(),"OP SSSD Blobs : "+sssdInfo);
						long indexIdForSSSD = addSSSDInfo(sssdBlob,sssdInfo);
						getModuleConfigUtil().setAlgorithmOutputIds(
								MatlabWrapperConstants.OBJECT_ARGID,
								indexIdForSSSD, 
								MatlabWrapperConstants.INSERT_SEMISTATIC_STATE_DATA);
					} else {
						MatlabWrapperUtil
								.logDebug(
										this.getClass(),
										"analytic "
												+ "output does not contain semi-static state data");
					}
				} else {
					MatlabWrapperUtil.logDebug(this.getClass(),
							"analytic output does not contain alarm or "
									+ "semi-static state data");
				}
			}
			}
			addAppInfoDataEvent(ruleSuccess);
			if (ruleSuccess) {
				long indexIdForTimeSeries = addDataInXML(returnTvMap);
				getModuleConfigUtil().setAlgorithmOutputIds(
						MatlabWrapperConstants.TIMESERIES_ARGID,
						indexIdForTimeSeries);
			}
			if (alarmList != null && alarmList.size() > 0) {
				for (Alarm alarm : alarmList) {
					MatlabWrapperUtil.logDebug(this.getClass(),
							"alarm details : " + alarm);
					addAlarmData(alarm);
				}
			}
			
		} finally {
			// dispose Matlab MWArray native memory
			if (stateArray != null) {
				MWArray.disposeArray(stateArray);
				stateArray = null;
			}

			if (metadata != null) {
				MWArray.disposeArray(metadata);
				metadata = null;
			}

			if (resultsArray != null) {
				MWArray.disposeArray(resultsArray);
				resultsArray = null;
			}

			if (results != null) {
				MWArray.disposeArray(results);
				results = null;
			}

			if (qualityArray != null) {
				MWArray.disposeArray(qualityArray);
				qualityArray = null;
			}
			if (alarmArray != null) {
				MWArray.disposeArray(alarmArray);
				alarmArray = null;
			}

			if (analyticsResult != null) {

				for (Object obj : analyticsResult) {
					try {
						if (obj != null) {
							MWArray.disposeArray(obj);
						}
					} catch (Exception e) {
						// in case index or object is invalid, keep going.
					}
				}

				MWArray.disposeArray(analyticsResult);
				analyticsResult = null;
			}
		}
	}

	/**
	 * parse the alarmArray to get the Alarm info
	 * 
	 * @param alarmArray
	 * @return List of Alarm objects
	 */
	private List<Alarm> extractAlarmDetails(MWCellArray alarmArray) {
		MWStructArray alarmStruct = null;
		List<Alarm> alarmList;
		alarmList = new ArrayList<Alarm>();
		try {
			for (int counter = 1; alarmArray != null
					&& counter <= (alarmArray.numberOfElements()); counter++) {
				Alarm alarmObj = new Alarm();
				NumAlert numAlert = new NumAlert();
				alarmStruct = (MWStructArray) alarmArray.getCell(counter);
				String[] fieldNames = alarmStruct.fieldNames();
				for (int i = 0; i < fieldNames.length; i++) {
					String fieldName = fieldNames[i];
					String fieldValue = alarmStruct.getField(fieldName, 1)
							.toString();
					if (fieldName != null
							&& fieldName
									.equalsIgnoreCase(MatlabWrapperConstants.ALARM_NAME)) {
						numAlert.setAlertName(fieldValue);
					} else if (fieldName != null
							&& fieldName
									.equalsIgnoreCase(MatlabWrapperConstants.ALARM_SEVERITY)) {
						Long type;
						try {
							type = Long.parseLong(MatlabWrapperUtil
									.getProperty(fieldValue.toUpperCase()));
						} catch (NumberFormatException e) {
							type = MatlabWrapperConstants.DEFAULT_ALARMTYPE;
						}
						numAlert.setAlertTypeId(type);
					} else if (fieldName != null
							&& fieldName
									.equalsIgnoreCase(MatlabWrapperConstants.ALARM_SG)) {
						alarmObj.setScanGroup(fieldValue);
					} else if (fieldName != null
							&& fieldName
									.equalsIgnoreCase(MatlabWrapperConstants.ALARM_DATETIME)) {
						Date dt = formatDateTime(fieldValue);
						String date = CAFModuleConfigUtil.getIsoDateFormat()
								.format(dt);
						OsacbmTime osacbmTime = new OsacbmTime();
						osacbmTime.setTime(date);
						osacbmTime
								.setTimeType(OsacbmTimeType.OSACBM_TIME_MIMOSA);
						numAlert.setLastTrigger(osacbmTime);
					} else if (fieldName != null
							&& fieldName
									.equalsIgnoreCase(MatlabWrapperConstants.ALARM_ASSETID)) {
						Site site = new Site();
						site.setCategory(SITECATEGORY.SITE_ZERO);
						site.setSiteId(fieldValue);
						numAlert.setAlertTypeSite(site);
					}
				}
				numAlert.setOsmName(getMatlabUtil().getHostName());
				alarmObj.setNumAlert(numAlert);
				alarmList.add(alarmObj);
			}
		} finally {
			if (alarmStruct != null) {
				MWArray.disposeArray(alarmStruct);
				alarmStruct = null;
			}
		}
		return alarmList;
	}

	public Date formatDateTime(String timestamp) {
		SimpleDateFormat sourceForamt = new SimpleDateFormat(
				"MM/dd/yyyy HH:mm:ss");

		Date sourceDate = new Date();
		try {
			sourceDate = sourceForamt.parse(timestamp);
		} catch (ParseException e) {
			MatlabWrapperUtil.logError(this.getClass(),
					"Error while parsing alarm Date  : " + timestamp);
		}

		return sourceDate;
	}

	private long addDataInXML(Map<String, List<TagValue<?>>> returnTvMap)
			throws Exception {
		long index = 0;
		if (returnTvMap != null) {
			byte[] blobData = getBlobUtil().convertTagValueMapToByteArray(
					returnTvMap, false);
			index = getModuleConfigUtil().addBlobDataEvent(
					CAFModuleConfigUtil.ARGID_OM_TAGVALUE_MAP, blobData);
		}
		return index;
	}

	private long addStateInfo(String stateStr) throws Exception {
		byte[] blobData = getBlobUtil().convertObjectToByteArray(stateStr);
		long index = getModuleConfigUtil().addBlobDataEvent(
				CAFModuleConfigUtil.ARGID_OM_OBJECT, blobData);
		return index;
	}

	private long addAlarmData(Alarm alarm) throws Exception {
		byte[] blobData = getBlobUtil().convertObjectToByteArray(
				alarm.getScanGroup());
		long index = getModuleConfigUtil().addAlarmDataEvent(
				alarm.getNumAlert(), blobData);
		return index;
	}

	private long addSSSDInfo(ArrayList<String> sssdData, ArrayList<String> sssdAnnot)
			throws Exception {
		
		Algorithm globalAlg = getModuleConfigUtil().getGlobalAlgorithm();
		List<AlgorithmInputData> lstInputData  =globalAlg.getInputData();
		AlgorithmInputData algInput = lstInputData.get(0);
		Site site = null;
	
		if (algInput.getInputRef() != null && algInput.getInputRef().getSite() != null) 
		{
			site = algInput.getInputRef().getSite();
		}

		
		long index = -1;
		for(int i = 0; i<sssdAnnot.size() ;i++)
		{
			byte[] blobData = getBlobUtil().convertObjectToByteArray(sssdData.get(i));
			index = getModuleConfigUtil().addMultipleBlobDataEvent(
					CAFModuleConfigUtil.ARGID_OM_OBJECT, blobData, sssdAnnot.get(i),site,index);
		}
		return index;
	}

	/**
	 * create new instance of BlobUtil if it's null and return it.
	 * 
	 * @return blobUtil
	 */
	public BlobUtil getBlobUtil() {
		if (blobUtil == null) {
			blobUtil = new BlobUtil();
		}
		return blobUtil;
	}

	private Map<String, List<TagValue<?>>> getTagValueMap(MWCellArray metadata,
			MWCellArray resultsArray, MWNumericArray qualityArray,
			double[] timestamps) {
		double[] values = null;
		int[] qualityValues = null;
		MWNumericArray results = null;
		String str;
		Site site;

		Map<String, List<TagValue<?>>> returnTvMap = new HashMap<String, List<TagValue<?>>>();
		int qualityIndex = 0;
		qualityValues = qualityArray.getIntData();
		for (int counter = 1; counter <= (metadata.numberOfElements() / 2); counter++) {
			str = metadata.getCell(counter).toString();
			if (!str.equals("DateTime")) {
				List<TagValue<?>> tvlist = new ArrayList<TagValue<?>>();

				results = (MWNumericArray) resultsArray.getCell(counter);
				values = results.getDoubleData();

				site = new Site();
				site.setSystemUserTag(str);

				for (int i = 0; i < timestamps.length; i++) {
					TagValue<Double> tv = new TagValue<Double>();

					// Build data TagValue
					tv.setDefaultValue(values[i]);
					char flag = (char) qualityValues[qualityIndex++];
					tv.setFlag(Character.toString(flag));
					tv.setTimeStamp((long) timestamps[i]);
					tv.setName(str);

					tvlist.add(tv);
				}

				returnTvMap.put(str, tvlist);
			}
			if (results != null) {
				MWArray.disposeArray(results);
			}
		}
		return returnTvMap;
	}

	/**
	 * 
	 * @param xmlRoot
	 * @return
	 */
	public void processRequest(ModuleConfigXMLRoot xmlRoot) throws Exception {
		this.xmlRoot = xmlRoot;
		// execute rule
		callMatlab();
		prepareOutputXML();
		setModuleConfigUtil(null);
		createOutputXml();
	}

	/**
	 * Remove input tags and data from XML file
	 * 
	 * @throws Exception
	 */
	private void prepareOutputXML() throws Exception {
		// remove input data blob from returning message(xml)
		List<DataEventSet> dataEventSets = xmlRoot.getDataEventSets();
		if (dataEventSets != null && dataEventSets.size() > 0) {
			List<DataEvent> dataEvents = dataEventSets.get(0).getDataEvents();
			dataEvents.clear();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ge.wrapper.matLab.util.osa.EntryPointSynchronous#get
	 * (java.lang.Object)
	 */
	// @Override
	protected void callMatlab() throws Exception {
		MWNumericArray num_output_elementsArray = null;

		// Set Start Time
		Object[] numOutputParams = null;

		startTime = new Date();
		Map<String, Object> rulePathInfo = null;
		String moduleName = null;
		String ruleJarPath = null;
		CustomURLClassLoader loader = null;

		Class<?> matlabModuleClass = null;
		Object matlabModule = null;

		MWCellArray config = null;
		try {
			rulePathInfo = getMatlabUtil().extractRulePathInfo(xmlRoot);
			if (rulePathInfo != null && rulePathInfo.size() > 0) {
				moduleName = (String) rulePathInfo
						.get(MatlabWrapperConstants.MODULE_CLASS_NAME);
				ruleJarPath = (String) rulePathInfo
						.get(MatlabWrapperConstants.RULE_PATH);
				debugMode = (Integer) rulePathInfo
						.get(MatlabWrapperConstants.RULE_DEBUG_MODE);

			}

			if (moduleName == null || moduleName.isEmpty()) {
				throw new Exception("module name is not found");
			} //TODO
			/*else if (ruleJarPath == null || ruleJarPath.isEmpty()) {
				throw new Exception("Rule path not found");
			}*/

			MatlabWrapperUtil.logInfo(getClass(), "Rule path=" + ruleJarPath);
			MatlabWrapperUtil.logInfo(getClass(), "Module Name=" + moduleName);
			MatlabWrapperUtil.logInfo(getClass(), "Rule debug mode="
					+ debugMode);
			
//TODO			loader = getClassLoader(ruleJarPath);
			Object[] matlabOutputObjArray = null;

			// Build the configuration from the input
			config = buildConfiguration();

			// Look up the inputs and build the analysis input array
			Object[] analysisInput = buildAnalysisInput(config);
			//TODO		matlabModuleClass = loader.loadClass(moduleName);
			//TODO	matlabModule = matlabModuleClass.newInstance();

			Class classToLoad = Class.forName("LBO.Class1");
			
			Method methodAnalyse = classToLoad.getDeclaredMethod(
					MatlabWrapperConstants.PROXY_ANALYSE, new Class[] {
							int.class, Object[].class });
			
			Object classObject = classToLoad.newInstance();
					
			
			matlabOutputObjArray = (Object[]) methodAnalyse.invoke(
					classObject,
					10,
					analysisInput);
			 
			
			//TODO
			/*Object[] obj = new Object[1];
			obj[0] = MatlabWrapperConstants.PROXY_ANALYSE;
			Method methodOutParams = matlabModuleClass.getDeclaredMethod(
					MatlabWrapperConstants.NUMBER_OUTPUT_ARGS_METHOD,
					new Class[] { int.class, Object[].class });
			numOutputParams = (Object[]) methodOutParams.invoke(matlabModule,
					1, obj);
			if (numOutputParams != null && numOutputParams.length > 0) {
				num_output_elementsArray = (MWNumericArray) numOutputParams[0];
				Method methodAnalyse = matlabModuleClass.getDeclaredMethod(
						MatlabWrapperConstants.PROXY_ANALYSE, new Class[] {
								int.class, Object[].class });

				matlabOutputObjArray = (Object[]) methodAnalyse.invoke(
						matlabModule, num_output_elementsArray.getInt(),
						analysisInput);
			}*/

			analyticsResult = matlabOutputObjArray;
			// analyticsResult = launchMatlabProcess(analysisInput,
			// moduleName,ruleJarPath);
		} catch (Exception e) {
			e.printStackTrace();
			String message = e.toString();
			ruleFailure = true;
			Throwable throwable = e.getCause();
			if (throwable != null) {
				message = throwable.getMessage();
			}
			ruleFailureMessage = message;
			ruleFailurePrefix = "MatlabAnalytic Error:" + moduleName + "-";
			Logger.getLogger(MatlabWrapper.class).error(
					ruleFailurePrefix + ruleFailureMessage, e);
			endTime = new Date();
		} finally {
			if (loader != null) {
				try {
					// clean up all Matlab array objects
					if (stateA != null) {
						MWArray.disposeArray(stateA);
						stateA = null;
					}
					if (innerMetadata != null) {
						MWArray.disposeArray(innerMetadata);
						innerMetadata = null;
					}
					if (innerCFMetadata != null) {
						MWArray.disposeArray(innerCFMetadata);
						innerCFMetadata = null;
					}
					if (outerMetadata != null) {
						MWArray.disposeArray(outerMetadata);
						outerMetadata = null;
					}
					if (innerQualityData != null) {
						MWArray.disposeArray(innerQualityData);
						innerQualityData = null;
					}
					if (innerCFQualityData != null) {
						MWArray.disposeArray(innerCFQualityData);
						innerCFQualityData = null;
					}
					if (outerQualityData != null) {
						MWArray.disposeArray(outerQualityData);
						outerQualityData = null;
					}
					if (innerData1 != null) {
						MWArray.disposeArray(innerData1);
						innerData1 = null;
					}
					if (innerCf != null) {
						MWArray.disposeArray(innerCf);
						innerCf = null;
					}
					if (outerData1 != null) {
						MWArray.disposeArray(outerData1);
						outerData1 = null;
					}
					if (title != null) {
						MWArray.disposeArray(title);
						title = null;
					}
					if (config != null) {
						// Clean up Anonymous Matlab array objects first. Will
						// these not get cleaned up automatically when parent
						// array is disposed??
						// Conflicting information found. This implies they will
						// not get cleaned up:
						// http://www.mathworks.com/matlabcentral/answers/109403-is-there-a-memory-leak-when-working-with-mwstructarrays-in-matlab-builder-ja-and-or-how-should-i-wor
						// While the javadoc for disposeArray() implies that
						// they will get cleaned up:
						// http://wind.isi.edu/marbles/assets/components/workflow_portal/users/lib/CombinedCNV/MCR/v79/help/toolbox/javabuilder/MWArrayAPI/com/mathworks/toolbox/javabuilder/MWArray.html

						for (int i = 1; i <= config.numberOfElements(); i++) {
							try {
								MWArray mwArray = config.getCell(i);
								if (mwArray != null) {
									MWArray.disposeArray(mwArray);
									config.set(i, null);
								}
							} catch (Exception e) {
								// in case index or object is invalid, keep
								// going.
							}
						}
						// now dispose the parent MWArray
						MWArray.disposeArray(config);
						config = null;
					}
				} catch (Exception e) {
					MatlabWrapperUtil.logError(MatlabWrapper.class,
							"Error Disposing MWArrays: " + e.getMessage());
				}

				if (matlabModuleClass != null) {
					try {
						Method methodDispose = matlabModuleClass
								.getDeclaredMethod("dispose");
						methodDispose.invoke(matlabModule);
					} catch (Exception e) {
						MatlabWrapperUtil.logError(MatlabWrapper.class,
								"Error invoking internal dispose() method in: "
										+ matlabModuleClass.getName());
					}
				}
				if (num_output_elementsArray != null) {
					MWArray.disposeArray(num_output_elementsArray);
					num_output_elementsArray = null;
				}
				loader.close();

				MatlabWrapperUtil.logInfo(getClass(), "Running GC");
				System.gc();
			}
		}
		// Set End Time
		endTime = new Date();
	}

	/**
	 * get classloader for loading jar's dynamically
	 * 
	 * @param ruleJarPath
	 * @return
	 * @throws Exception
	 */
	private CustomURLClassLoader getClassLoader(String ruleJarPath)
			throws Exception {
//		String urlPath = "file:\\" + ruleJarPath;
		String urlPath = "LBO.jar";
		MatlabWrapperUtil.logInfo(getClass(), urlPath);
		URL url = new URL(urlPath);
		URL[] urls = new URL[] { url };
		CustomURLClassLoader myURLClassLoader = new CustomURLClassLoader(urls,
				getClass().getClassLoader());
		return myURLClassLoader;
	}

	/**
	 * @return
	 */
	private MWCellArray buildConfiguration() throws Exception {
		// Build an MWCellArray for the configuration based on the list of
		// selectors
		// The int[] is needed to identify the right spot in the CellArray to
		// populate.
		int[] cdims;
		MWCellArray config;

		// Grab the list of selectors from the input list
		Map<String, String> inputValueMap = getMatlabUtil().getInputValueMap(
				xmlRoot);

		// Minus one because one of the inputValues is always going to be the
		// ModuleClassName.
		// cdims = new int[] { 2, inputValueMap.size() - 1 };
		// int confXSize = inputValueMap.size() - 2
		// + MatlabWrapperConstants.STATIC_CONFIGURATION_TAG_CNT;
		int confXSize = inputValueMap.size();
		// MatlabWrapperUtil.logInfo(getClass(), "confXSize=" + confXSize);
		// confXSize += MatlabWrapperConstants.STATIC_CONFIGURATION_TAG_CNT;
		cdims = new int[] { confXSize, 2 };
		config = new MWCellArray(cdims);
		int counter = 1;

		for (Map.Entry<String, String> a : inputValueMap.entrySet()) {
			String key = a.getKey();
			// MatlabWrapperUtil.logInfo(getClass(), "key=" + key);

			// if
			// (!key.equalsIgnoreCase(MatlabWrapperConstants.MODULE_CLASS_NAME)
			// &&
			// !a.getKey().equalsIgnoreCase(MatlabWrapperConstants.RULE_PATH)) {
			// if (getMatlabUtil().isValidConfig(key)) {
			// MatlabWrapperUtil.logInfo(getClass(), "Match condition for:"
			// + a.getKey());
			// Row

			MatlabWrapperUtil.logInfo(getClass(), "name=" + a.getKey()
					+ " value=" + a.getValue());

			cdims[0] = counter;
			// Name
			cdims[1] = 1;
			config.set(cdims, new MWCharArray(a.getKey()));
			// Value
			cdims[1] = 2;
			config.set(cdims, new MWCharArray(a.getValue()));

			// Next
			counter++;
			// }
		}

		// // get siteId
		// String siteId = getMatlabUtil().getSiteId(xmlRoot);
		// // add STATIC_CONFIGURATION_TAG_1
		// // Row
		// cdims[0] = counter;
		// // Name
		// cdims[1] = 1;
		// config.set(cdims, new MWCharArray(
		// MatlabWrapperConstants.STATIC_CONFIGURATION_TAG_1));
		// // Value
		// cdims[1] = 2;
		// config.set(cdims, new MWCharArray(siteId));
		// counter++;
		// // add STATIC_CONFIGURATION_TAG_2
		// // Row
		// cdims[0] = counter;
		// // Name
		// cdims[1] = 1;
		// config.set(cdims, new MWCharArray(
		// MatlabWrapperConstants.STATIC_CONFIGURATION_TAG_2));
		// // Value
		// cdims[1] = 2;
		// config.set(cdims, new MWCharArray(siteId));

		return config;
	}

	/**
	 * 
	 * @param config
	 * @return
	 * @throws Exception
	 */
	private Object[] buildAnalysisInput(MWCellArray config) throws Exception {
		Algorithm currentAlgorithm = getModuleConfigUtil().getConfigAlgorithm();
		getInputDataId(currentAlgorithm);

		// Loop through all of the tags
		List<DataEventSet> dataEventSetLst = xmlRoot.getDataEventSets();
		DataEventSet dataEventSet = null;
		List<DataEvent> dataEventLst = null;

		if (dataEventSetLst != null && dataEventSetLst.size() > 0) {
			dataEventSet = dataEventSetLst.get(0);
			dataEventLst = dataEventSet.getDataEvents();
			ExtractDataFromDataEvent(dataEventLst);
		}
		Object[] analysisInput;
		if(idLevel2Data != -1 && isLevel2DataSet)
		{
			analysisInput = new Object[2];
			analysisInput[0] = l2inputData;
			analysisInput[1] = debugMode;
			
		}
		else{
		// If no correction factor is found, cfTagCount and cfHighItemCount will
		// be 0
		// Matlab arrays begin with 1 and index of 0 will result in error.
		// Hence re-initializing these indexes to 1.
		if (cfTagCount <= 0)
			cfTagCount = 1;

		if (cfHighItemCount <= 0)
			cfHighItemCount = 1;

		// Metadata
		innerMetadata = new MWCellArray(new int[] { tagCount, 2 }); // Metadata
		innerCFMetadata = new MWCellArray(new int[] { cfTagCount, 2 }); // Metadata
																		// for
																		// CF

		String name = "DateTime";
		String val = "seconds";

		// Add DateTime to the metadata
		innerMetadata.set(new int[] { 1, 1 }, name);
		innerMetadata.set(new int[] { 1, 2 }, val);

		// Initializing CF metadata to blank. Not required but might as well.
		innerCFMetadata.set(new int[] { 1, 1 }, ' ');
		innerCFMetadata.set(new int[] { 1, 2 }, ' ');

		// input data
		double[][] dataArray = new double[highItemCount][tagCount];
		double[][] cfArray = new double[cfHighItemCount][cfTagCount];
		int[][] quality = new int[highItemCount][tagCount];
		int[][] cfQuality = new int[cfHighItemCount][cfTagCount];

		// Now that we have the right sized objects, loop through and populate
		// them
		int tagNameCounter = 1;
		String tagName;
		for (Map.Entry<String, List<TagValue<?>>> a : tagValueMap.entrySet()) {
			tagName = a.getKey();
			addTVMataData(tagNameCounter, tagName);
			addTVDataQuality(dataArray, quality, tagNameCounter, a);
			tagNameCounter++;
		}
		tagNameCounter = 0;
		if (cfIsSet) {
			initializeCFDataArray(cfArray);
			initializeCFQualityArray(cfQuality);
			for (Map.Entry<String, List<TagValue<Double>>> a : cfTagValueMap
					.entrySet()) {
				tagName = a.getKey();
				addCFMataData(tagNameCounter, tagName);
				addCFDataQuality(cfArray, cfQuality, tagNameCounter, a);
				tagNameCounter++;
			}
		}
		// Build the OSA types
		innerData1 = new MWNumericArray(dataArray);
		innerQualityData = new MWNumericArray(quality);

		innerCf = new MWNumericArray(cfArray);
		innerCFQualityData = new MWNumericArray(cfQuality);

		// Put all inputs into an array and return
		//Object[] analysisInput;
		if (sssdIsSet) {
			analysisInput = new Object[8];
			MatlabWrapperUtil.logInfo(getClass(),
					"Semi-static state data found. "
							+ "Assigning SSSD, analysisInput has 8 elements.");
			analysisInput[7] = sssdA;
		} else {
			analysisInput = new Object[7];
			MatlabWrapperUtil.logInfo(getClass(), "No semi-static state data, "
					+ "analysisInput has 7 elements.");
		}

		getAnalysisInputs();
		if (cfIsSet) {
			analysisInput[0] = outerMetadata;
			analysisInput[1] = outerData1;
			analysisInput[2] = outerQualityData;

		} else {
			analysisInput[0] = innerMetadata;
			analysisInput[1] = innerData1;
			analysisInput[2] = innerQualityData;

		}
		analysisInput[3] = title;

		if (stIsSet) {
			MatlabWrapperUtil.logInfo(getClass(),
					"Prior state found. Assigning pre-existing state");
			analysisInput[4] = stateA;
		} else {
			MatlabWrapperUtil.logInfo(getClass(), "Assigning empty state");
			String sState = MatlabWrapperConstants.EMPTY_STATE;
			stateA.set(1, sState);
			analysisInput[4] = stateA;
		}

		analysisInput[5] = config;
		analysisInput[6] = debugMode;
		}
		return analysisInput;
	}

	/**
	 * 
	 */
	public void getAnalysisInputs() {
		if (cfIsSet) {
			outerMetadata = new MWCellArray(new int[] { 1, 2 }); // Metadata
			outerQualityData = new MWCellArray(new int[] { 1, 2 }); // Quality
			outerData1 = new MWCellArray(new int[] { 1, 2 });
			outerMetadata.set(new int[] { 1, 1 }, innerMetadata);
			outerMetadata.set(new int[] { 1, 2 }, innerCFMetadata);
			outerData1.set(new int[] { 1, 1 }, innerData1);
			outerData1.set(new int[] { 1, 2 }, innerCf);
			outerQualityData.set(new int[] { 1, 1 }, innerQualityData);
			outerQualityData.set(new int[] { 1, 2 }, innerCFQualityData);
			title = new MWCellArray(new int[] { 1, 2 });
			title.set(new int[] { 1, 1 }, "Historian");
			title.set(new int[] { 1, 2 }, "CorrectionFactor");
		} else {
			// outerMetadata = innerMetadata;
			// outerData1 = innerData1;
			// outerQualityData = innerQualityData;
			title = new MWCellArray(new int[] { 1, 1 });
			title.set(new int[] { 1, 1 }, "Historian");
		}
	}

	private void initializeCFDataArray(double[][] arr) {
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				arr[i][j] = Double.NaN;
			}
		}
	}

	private void initializeCFQualityArray(int[][] arr) {
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				arr[i][j] = ' ';
			}
		}
	}

	/**
	 * @param cfArray
	 * @param tagNameCounter
	 * @param a
	 */
	public void addCFDataQuality(double[][] cfDataArray, int[][] cfQuality,
			int tagNameCounter, Map.Entry<String, List<TagValue<Double>>> a) {
		int tagRowCounter = 0;
		Iterator<TagValue<Double>> dValuesIterator = a.getValue().iterator();

		while (dValuesIterator.hasNext()) {
			TagValue<Double> value = dValuesIterator.next();
			String valString = value.getDefaultValue().toString();
			// TODO: Again, is this how we should handle blank data?
			cfDataArray[tagRowCounter][tagNameCounter] = valString.isEmpty() ? 0.0
					: new Double(valString);
			char qualityFlag = ' ';
			cfQuality[tagRowCounter][tagNameCounter] = qualityFlag;
			tagRowCounter++;
		}
	}

	/**
	 * @param dataArray
	 * @param quality
	 * @param tagNameCounter
	 * @param a
	 */
	public void addTVDataQuality(double[][] dataArray, int[][] quality,
			int tagNameCounter, Map.Entry<String, List<TagValue<?>>> a) {
		int tagRowCounter = 0;
		Iterator<TagValue<?>> dValuesIterator = a.getValue().iterator();
		while (dValuesIterator.hasNext()) {
			TagValue<?> value = dValuesIterator.next();

			String valString = value.getDefaultValue().toString();
			String qualityString = value.getFlag();

			double dateNum = matlabUtil.getMatlabDateNum(value.getTimeStamp());
			dataArray[tagRowCounter][0] = dateNum;

			// time doesn't have quality, so default it to ' '
			// quality[tagRowCounter][0] = ' ';

			// dataArray[tagRowCounter][tagNameCounter] = valString.isEmpty() ?
			// 0.0
			// : Double.parseDouble(valString);
			dataArray[tagRowCounter][tagNameCounter] = valString.isEmpty() ? Double.NaN
					: Double.parseDouble(valString);

			char qualityFlag = ' ';
			if (valString.isEmpty()) {
				qualityString = "M";
			}
			qualityFlag = getQualityFlag(qualityString);
			quality[tagRowCounter][tagNameCounter - 1] = qualityFlag;

			// next data row
			tagRowCounter++;
		}
	}

	private void addCFMataData(int tagNameCounter, String tagName) {
		innerCFMetadata.set(new int[] { tagNameCounter + 1, 1 }, tagName);

		// The below used to pass Matlab the unit of measure, but Matlab
		// doesn't do anything with it and it's not included in the blob
		// spec, so add an N/A string.
		innerCFMetadata.set(new int[] { tagNameCounter + 1, 2 }, " ");

	}

	/**
	 * @param tagNameCounter
	 * @param tagName
	 */
	public void addTVMataData(int tagNameCounter, String tagName) {
		innerMetadata.set(new int[] { tagNameCounter + 1, 1 }, tagName);

		// The below used to pass Matlab the unit of measure, but Matlab
		// doesn't do anything with it and it's not included in the blob
		// spec, so add an N/A string.
		innerMetadata.set(new int[] { tagNameCounter + 1, 2 }, "N/A");
	}

	/**
	 * Travel through DataEvents and extract TimeSeries, State and Correction
	 * Factor data
	 * 
	 * @param dataEventLst
	 * @throws Exception
	 */
	private void ExtractDataFromDataEvent(List<DataEvent> dataEventLst)
			throws Exception {
		DMBLOBData deBlob = null;
		ArrayList<String> sssdInfoList = new ArrayList<String>();
		ArrayList<String> sssdDataList = new ArrayList<String>();
		
		// loop through DataEvents
		for (DataEvent dataEvent : dataEventLst) {
			deBlob = (DMBLOBData) dataEvent;
			String mimeType = deBlob.getValue().getContentType().getValue();
			byte[] dataBinary = deBlob.getValue().getDataBinary();
			if (mimeType.equals(CAFModuleConfigUtil.MIME_OM_TAGVALUE_MAP)) { // TimeSeries_data
				getBlobUtil().setTimeInseconds(true);
				tagValueMap = getBlobUtil().convertByteArrayToTagValueMap(
						dataBinary);
				if (!tagValueMap.isEmpty()) {
					tagCount += tagValueMap.size();
					Map.Entry<String, List<TagValue<?>>> entry = tagValueMap
							.entrySet().iterator().next();
					if (entry.getValue() != null) {
						highItemCount = entry.getValue().size();
					}
				}
			} else if (mimeType.equals(CAFModuleConfigUtil.MIME_OM_OBJECT)) {
				if (deBlob.getId() == idState) { // State_Info
					String sData = null;
					sData = (String) getBlobUtil().convertByteArrayToObject(
							dataBinary);
					stateA.set(1, sData);
					stIsSet = true;
				} else if (deBlob.getId() == idCorrFactor) { // CorrectionFactor
					String cfData = null;
					cfData = (String) getBlobUtil().convertByteArrayToObject(
							dataBinary);
					cfTagValueMap = parseCFData(cfData);
					cfIsSet = true;
				}else if (deBlob.getId() == idSSSD) { // Semi-Static State Data
				
					String sssdData = null;
					String sssdInfo = null;
					sssdData = (String) getBlobUtil().convertByteArrayToObject(
							dataBinary);
					sssdInfo = (String) deBlob.getMEventBlobType().getName();
					sssdInfoList.add(sssdInfo);
					sssdDataList.add(sssdData);
					
					sssdIsSet = true;
				}
				else if(deBlob.getId() == idLevel2Data)
				{
					isLevel2DataSet = true;
					
					
					String[][] level2data = (String[][])getBlobUtil().convertByteArrayToObject(dataBinary); 
					
					l2inputData = new MWCellArray(new int[] { level2data.length, 2 }); 

					//NEed to parse the string
					
					for(int index=0; index < level2data.length;index++ )
					{
						
						l2inputData.set(new int[] { index+1, 1 }, level2data[index][0]);
						
						l2inputData.set(new int[] { index+1, 2 }, level2data[index][1]);
					}

					
				}
			}
		}
		
		if(sssdIsSet)
		{
			sssdA = new MWCellArray(new int[] {sssdInfoList.size(), 2 });
			for (int i = 0; i < sssdInfoList.size(); i++) 
			{
				sssdA.set(new int[] { i + 1, 1 }, new MWCharArray(sssdInfoList.get(i)));
				sssdA.set(new int[] { i + 1, 2 }, new MWCharArray(sssdDataList.get(i)));
			}
		}
	}

	/**
	 * Both State info and Correction factor have mime type
	 * "application/x-om-object" This method retrieve id for state_info and
	 * correction_factor dataEvents
	 * 
	 * @param currentAlgorithm
	 */
	public void getInputDataId(Algorithm currentAlgorithm) {
		for (AlgorithmInputData inData : currentAlgorithm.getInputData()) {
			String name = inData.getName();
			if (name.equalsIgnoreCase(MatlabWrapperConstants.READ_STATE_INFO)) {
				setIdState(inData.getInputRef().getId());
			} else if (name
					.equalsIgnoreCase(MatlabWrapperConstants.CORRECTION_FACTOR)) {
				setIdCorrFactor(inData.getInputRef().getId());
			} else if (name
					.equalsIgnoreCase(MatlabWrapperConstants.SEMISTATIC_STATE_DATA)) {
				setIdSSSD(inData.getInputRef().getId());
			}
			else if(name.equalsIgnoreCase(MatlabWrapperConstants.LEVEL2DATA)) 
				
			{
				setLevel2ID(inData.getInputRef().getId());
			}
		}
	}

	private void setLevel2ID(long id) 
	{
		idLevel2Data = id;
	}

	/**
	 * Parse CorrectionFactor data and return TagValueMap
	 * 
	 * @param cfData
	 *            - Correction Factor data in String format
	 * @return TavValueMap - Map<String, List<TagValue<Double>>>
	 */
	private Map<String, List<TagValue<Double>>> parseCFData(String cfData) {
		String[] cfDataArr = cfData.split("\n");
		return getCFTagValueMap(cfDataArr);
	}

	/**
	 * 
	 * @param cfData
	 * @return
	 */
	private Map<String, List<TagValue<Double>>> getCFTagValueMap(String[] cfData) {
		Map<String, List<TagValue<Double>>> retMap = new HashMap<String, List<TagValue<Double>>>();
		boolean firstLine = true;
		for (String line : cfData) {
			if (firstLine || line.trim().isEmpty()) {
				firstLine = false;
				continue;
			}

			// @ToDo : Better explanation of Correction Factor Overhaul
			// added a new column 'DtTime' for CorrectionFactor

			int i = 1;
			String[] cfSplit = line.split(",");

			String sDateTime = cfSplit[i++];
			long uTimeStamp = 0L;
			SimpleDateFormat formatter = new SimpleDateFormat(
					"yyyy-MM-dd HH:mm:ss");
			try {
				uTimeStamp = formatter.parse(sDateTime).getTime() / 1000;
			} catch (Exception e) {
				uTimeStamp = 0L;
			}

			Calendar calendar = Calendar.getInstance();
			calendar.setTimeInMillis(uTimeStamp * 1000);
			calendar.add(Calendar.MILLISECOND,
					TimeZone.getDefault().getOffset(calendar.getTimeInMillis()));
			Date currenTimeZone = (Date) calendar.getTime();

			TagValue<Double> dTv = createTagValue(
					"DtTime",
					matlabUtil.getMatlabDateNum(currenTimeZone.getTime() / 1000));
			putInCFMap(retMap, dTv);

			// Correction factor overhaul ends.....

			String tagNamePre = cfSplit[i++];
			String val = cfSplit[i++];
			Double xValue = ((val == null) || (val.trim()
					.equalsIgnoreCase(MatlabWrapperConstants.NULL_VAL))) ? null
					: new Double(val);

			val = null;
			if (i < cfSplit.length)
				val = cfSplit[i++];
			Double yValue = ((val == null) || (val.trim()
					.equalsIgnoreCase(MatlabWrapperConstants.NULL_VAL))) ? null
					: new Double(val);

			val = null;
			if (i < cfSplit.length)
				val = cfSplit[i++];
			Double fValue = ((val == null) || (val.trim()
					.equalsIgnoreCase(MatlabWrapperConstants.NULL_VAL))) ? null
					: new Double(val);

			String xTag = tagNamePre.trim() + "_X";
			String yTag = tagNamePre.trim() + "_Y";
			String fTag = tagNamePre.trim() + "_F";

			// defensive coding around xValue, YValue and FValue.

			if (xValue != null) {
				TagValue<Double> xTv = createTagValue(xTag, xValue);
				putInCFMap(retMap, xTv);
			}
			if (yValue != null) {
				TagValue<Double> yTv = createTagValue(yTag, yValue);
				putInCFMap(retMap, yTv);
			}

			if (fValue != null) {
				TagValue<Double> fTv = createTagValue(fTag, fValue);
				putInCFMap(retMap, fTv);
			}

		}
		return retMap;
	}

	/**
	 * Check if TagValue is not null. Add TagValue in TagValue list. If there is
	 * no list for this Tag name in Map than create one. This method also
	 * updates counter for total number of Tags for correction factor
	 * (cfTagNameCounter). Max number of data points is stored in
	 * cfTagRowCounter variable.
	 * 
	 * @param retMap
	 *            Map<String, List<TagValue<Double>>>
	 * @param tv
	 *            TagValue to be inserted in Map
	 */
	private void putInCFMap(Map<String, List<TagValue<Double>>> retMap,
			TagValue<Double> tv) {
		if (tv != null) {
			String tagName = tv.getName();
			List<TagValue<Double>> tagList = retMap.get(tagName);
			if (tagList == null) {
				cfTagCount++;
				tagList = new ArrayList<TagValue<Double>>();
			}
			tagList.add(tv);
			int tagListSize = tagList.size();
			if (tagListSize > cfHighItemCount) {
				cfHighItemCount = tagListSize;
			}
			retMap.put(tagName, tagList);
		}
	}

	/**
	 * create new TagValue Object for CorrectionFactor value
	 * 
	 * @param xTag
	 * @param xValue
	 * @return TagValue or null if value is null
	 */
	private TagValue<Double> createTagValue(String tag, Double value) {
		TagValue<Double> retTagValue = null;
		if (value != null) {
			retTagValue = new TagValue<Double>();
			retTagValue.setDefaultValue(value);
			retTagValue.setFlag(" ");
			retTagValue.setTimeStamp(0);
			retTagValue.setName(tag);

		}
		return retTagValue;
	}

	/**
	 * convert quality flag to 'M' or ' '
	 * 
	 * @param qualityString
	 * @param qualityFlag
	 * @return
	 */
	public char getQualityFlag(String qualityString) {
		char qualityFlag = ' ';
		// TODO: Test this with an analytic that actually uses this format
		// Quality: If Quality is a 0, convert to an M. If Quality is a 3 or
		// 100, convert to a " "
		if (qualityString.equals("0") || qualityString.equals("M")) {
			qualityFlag = 'M';
		} else if (qualityString.equals("3") || qualityString.equals("100")
				|| qualityString.equals(" ")) {
			qualityFlag = ' ';
		}
		return qualityFlag;
	}

	/**
	 * 
	 * @param analyticSucceeded
	 * @throws Exception
	 */
	private void addAppInfoDataEvent(boolean analyticSucceeded)
			throws Exception {
		getMatlabUtil().addAppInfoDataEvent(xmlRoot, analyticSucceeded,
				startTime, endTime);
	}

	/**
	 * 
	 * @param ruleFailureMessage
	 * @throws Exception
	 */
	private void addErrorInfoDataEvent(String ruleFailureMessage,
			String ruleFailurePrefix) throws Exception {
		awpReturnCode = getMatlabUtil().addErrorInfoDataEvent(xmlRoot,
				ruleFailureMessage, ruleFailurePrefix);
	}

	/**
	 * 
	 * @return
	 */
	public CAFXmlUtil getXmlUtil() {
		if (xmlUtil == null) {
			xmlUtil = new CAFXmlUtil();
		}
		return xmlUtil;
	}

	/**
	 * 
	 * @param xmlUtil
	 */
	public void setXmlUtil(CAFXmlUtil xmlUtil) {
		this.xmlUtil = xmlUtil;
	}

	/**
	 * 
	 * @return
	 */
	public MatlabWrapperUtil getMatlabUtil() {
		if (matlabUtil == null) {
			matlabUtil = new MatlabWrapperUtil();
		}
		return matlabUtil;
	}

	/**
	 * 
	 * @param matlabUtil
	 */
	public void setMatlabUtil(MatlabWrapperUtil matlabUtil) {
		this.matlabUtil = matlabUtil;
	}

	/**
	 * 
	 * @return
	 */
	public CAFModuleConfigUtil getModuleConfigUtil() {
		if (moduleConfigUtil == null) {
			moduleConfigUtil = new CAFModuleConfigUtil(xmlRoot);
		}
		return moduleConfigUtil;
	}

	/**
	 * 
	 * @param moduleConfigUtil
	 */
	public void setModuleConfigUtil(CAFModuleConfigUtil moduleConfigUtil) {
		this.moduleConfigUtil = moduleConfigUtil;
	}

	/**
	 * 
	 * @return
	 */
	public long getIdState() {
		return idState;
	}

	/**
	 * 
	 * @param idState
	 */
	public void setIdState(long idState) {
		this.idState = idState;
	}

	/**
	 * 
	 * @return
	 */
	public long getIdCorrFactor() {
		return idCorrFactor;
	}

	/**
	 * 
	 * @param idCorrFactor
	 */
	public void setIdCorrFactor(long idCorrFactor) {
		this.idCorrFactor = idCorrFactor;
	}

	/**
	 * 
	 * @return
	 */
	public long getIdSSSD() {
		return idSSSD;
	}

	/**
	 * 
	 * @param idSSSD
	 */
	public void setIdSSSD(long idSSSD) {
		this.idSSSD = idSSSD;
	}

	/**
	 * Returns the AWP Return code if the analytic failed to execute, otherwise
	 * null.
	 * 
	 * @return String
	 */
	public String getAwpReturnCode() {
		return awpReturnCode;
	}
	/*
	 public static void main(String args[]) 
	 {
		 
		 try{
		 String sData = null;
			
			sData = "AAIBAAAAAQAAAAAAAAAAAAAA";
			System.out.println("State data=" + sData);
			BlobUtil blobUtil = new BlobUtil();
			byte[] bData = blobUtil.convertObjectToByteArray(sData);
			System.out.println("Byte Array=" + bData);
			
			CAFXmlUtil xmlUtil = new CAFXmlUtil();
			
			
			
			//ModuleConfigXMLRoot xmlRoot = xmlUtil.parseXmlFile(file);
			
			MatlabWrapper wrapper = new MatlabWrapper();
			wrapper.getFile();
			wrapper.processRequest(null);
			//removeBlob(xmlString);
			System.out.println("------------------------------------");
		 }catch(Exception e)
		 {
			 e.printStackTrace();
		 }
	 
	 }*/
	 
	 public void getFile() throws Exception
	 {
		 String file  = null;
		 ClassLoader cl = Thread.currentThread().getContextClassLoader();
			URL url = cl.getResource("lib\\final_input.xml");
			
			URI uri = null;
			if (url != null) {
				uri = new URI(url.getFile());
				file = uri.getPath();
			}
			
		 InputStream input = this.getClass().getResourceAsStream("final_input.xml");
		 System.out.println("fiel "+file);
	 }

}
