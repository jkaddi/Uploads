package com.ge.om.MatlabWrapper.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

/**
 * Determines the AWP Return Code that should be returned by the Matlab Wrapper, 
 * when an executing Matlab Analytic fails with an Exception error. 
 * To look up the proper AWP Return Code to use, make a call to getAwpReturnCode() 
 * passing in the analytic's Module Class Name, and the text of the error message.
 *
 * This class automatically finds and loads the config file entries from MatlabAwpReturnCodes.cfg  
 * That text file defines the mappings from analytic module names/error messages to AWP return codes. 
 * The module names and error messages can also be specified using regular expressions. 
 * 
 * Please see the config file MatlabAwpReturnCodes.cfg for more information on 
 * how to format the config entry mappings. Additional information can be found in the Design Document 
 * available in Rally for user story US10918 here: https://rally1.rallydev.com/#/16576497409ud/detail/userstory/16917684938 
 *  
 * @author Gary Cristofoli
 */
public class MatlabAwpReturnCodes {
	public static final String DEFAULT_AWP_RETURN_CODE = "AWP300"; //GENERAL ERROR (UNKNOWN) 
	public static final String DEFAULT_CONFIG_FILE = "MatlabAwpReturnCodes.cfg"; 

	private static Map<ModuleNameConfigKey, List<ConfigFileEntry>> configMap;
	private static String configFilePath = DEFAULT_CONFIG_FILE;
	private static long awpReturnCodesConfigLastModifiedDate = 0;
	private static int entryCount = 0;

	static {
		//initialize on class load.
		initAwpReturnCodes();
	}

	/**
	 * private Constructor, don't instantiate this static class
	 */
	private MatlabAwpReturnCodes() {
	}

	/**
	 * Returns the AWP Return Code for the specified analytic Module Class Name, and Rule Failure Message.
	 * @param moduleClassName the module class name of the analytic that failed
	 * @param ruleFailureMessage the error message from the exception that was thrown by the analytic
	 * @return the AWP return code that should be returned by the wrapper
	 */
	public static synchronized String getAwpReturnCode(String moduleClassName, String ruleFailureMessage) {
		MatlabWrapperUtil.logDebug(MatlabAwpReturnCodes.class, "Looking up AWP return code for Module='"+moduleClassName + "' and failure msg='"+ruleFailureMessage+"'");
		reloadConfigFileIfModified(); //make sure we have the latest config
		String awpReturnCode = DEFAULT_AWP_RETURN_CODE; //return code if no match found.

		//get all the config entries for this module name
		List<ConfigFileEntry> entries = findMatchingEntries(moduleClassName, configMap);

		//test each entry to see if it matches on this error message
		if (entries != null) {
			for (ConfigFileEntry entry : entries) {
				Matcher matcher = entry.getErrorPattern().matcher(ruleFailureMessage);
				if (matcher.find()) {
					awpReturnCode = entry.getAwpReturnCode();
					MatlabWrapperUtil.logDebug(MatlabAwpReturnCodes.class, "Found matching entry: " + entry);
					break; //found first match, we're done.
				} else {
					MatlabWrapperUtil.logDebug(MatlabAwpReturnCodes.class, "Entry does not match: " + entry);
				}
			}
		} else {
			MatlabWrapperUtil.logDebug(MatlabAwpReturnCodes.class, "No awp config entries found for " + moduleClassName);
		}
		return awpReturnCode;
	}

	/**
	 * checks if the last modified time of the config file has changed since the last access, 
	 * and if so, reloads it.
	 */
	private static void reloadConfigFileIfModified() {
		//if the config file has changed, reload it.
		if (hasConfigFileChanged()) {
			MatlabWrapperUtil.logInfo(MatlabAwpReturnCodes.class, "config file has been modified, reloading.");
			initAwpReturnCodes();
		}
	}

	/**
	 * initialize when this class loads, 
	 * automatically loading the default config file.
	 */
	private static boolean initAwpReturnCodes() {
		return loadAwpReturnCodesConfig(configFilePath);
	}

	/**
	 * For unit testing..  
	 * Loads the specified config file, first checking the file system path, 
	 * then checking as a classpath resource. An external file will override the 
	 * config file entries built into the jar file.
	 * @param configFile path to config file
	 * @return true if loaded successfully, false otherwise.
	 */
	static synchronized boolean loadAwpReturnCodesConfig(String configPath) {
		setConfigFilePath(configPath); 
		MatlabWrapperUtil.logInfo(MatlabAwpReturnCodes.class, "Loading config file: " + configPath);
		boolean isConfigLoaded = false;
		try {
			InputStream configStream = getConfigFileAsStream(configFilePath);
			isConfigLoaded = loadConfig(configStream);
			if (isConfigLoaded) {
				updateLastModifiedDateOfExternalFile();
			}
		} catch (Exception e) {
			MatlabWrapperUtil.logError(MatlabAwpReturnCodes.class, "Error loading config file: " + configPath + "\n" + e.getMessage());
		}
		return isConfigLoaded;
	}

	/**
	 * For unit testing.. 
	 * Loads the return codes config from a stream 
	 * @param configStream
	 * @throws IOException
	 */
	private static synchronized boolean loadConfig(InputStream configStream) {
		boolean isConfigLoaded = false;
		BufferedReader configReader = null;
		try {
			configReader = new BufferedReader(new InputStreamReader(configStream));
			entryCount = 0;
			configMap = loadConfig(configReader);
			isConfigLoaded = true;
		} catch (Exception e) {
			MatlabWrapperUtil.logError(MatlabAwpReturnCodes.class, "Error loading config file: " + configFilePath + "\n" + e.getMessage());
			/**
			 * DESIGN POINT: let's say the config file gets edited and somehow becomes corrupted, should the system 
			 * handle it by continuing to use the previous loaded AWP Return Codes which are still in memory?    
			 * I decided NO because that would make the system non-deterministic, since things would continue to function fine   
			 * only until the next time the system is restarted, possibly months later, at which time the corrupted config file 
			 * would fail to load. It's better to clear AWP Codes when the error is logged, so that the problem is caught sooner.   
			 */
			if (configMap != null) {
				configMap.clear(); //clear out the old entries.
			} else {
				configMap = new LinkedHashMap<ModuleNameConfigKey, List<ConfigFileEntry>>();
			}
			entryCount = 0;
		} finally {
			if (configReader != null) {
				try {
					configReader.close();
				} catch (IOException e) {
					MatlabWrapperUtil.logError(MatlabAwpReturnCodes.class, "Error closing stream: " + e.getMessage());
				}
			}
		}
		return isConfigLoaded;
	}

	/**
	 * Utility method for Tests to supply config file as a stream
	 * @param configStream
	 * @return
	 */
	static synchronized boolean loadAwpReturnCodesConfig(InputStream configStream) {
		//clear out some vars since we're not using a physical file
		configFilePath = null;
		awpReturnCodesConfigLastModifiedDate = 0;
		entryCount = 0;
		return loadConfig(configStream);
	}
	
	/**
	 * read the config file and process each line that is not a comment or blank line, 
	 * @param configReader
	 * @return Map of config file entries.
	 * @throws IOException
	 */
	private static Map<ModuleNameConfigKey, List<ConfigFileEntry>> loadConfig(BufferedReader configReader) throws IOException {
		//keep them in order so that later we process them in same order as specified in config file.
		LinkedHashMap<ModuleNameConfigKey, List<ConfigFileEntry>> newConfigEntries = new LinkedHashMap<ModuleNameConfigKey, List<ConfigFileEntry>>();
		String entryLine;
		while ((entryLine = configReader.readLine()) != null) {
			if (!entryLine.trim().startsWith("#") && !entryLine.trim().equals("")) {
				addEntry(entryLine, newConfigEntries);
			}
		}
		return newConfigEntries;
	}

	/**
	 * compares the last modified time of the config file nto the previous timestamp, 
	 * and returns true if it has changed; false otherwise.
	 * @return
	 */
	private static boolean hasConfigFileChanged() {
		return awpReturnCodesConfigLastModifiedDate != getConfigModifiedDate();
	}

	/**
	 * returns the timestamp of the config file, if it's an external file (i.e. outside the jar file)
	 * If file is not in the file system, return 0.
	 * @return
	 */
	private static long getConfigModifiedDate() {
		//this only applies to files on the file system, which is fine since those in a jar file won't change anyway. 
		File extFile = getExternalFileIfExists();
		if (extFile != null) {
			return extFile.lastModified();
		} else {
			return 0; //same timestamp returned by File.lastModified() when a file does not exist.
		}
	}

	/**
	 * Stores the last modified date of the config file for later reference.
	 */
	private static void updateLastModifiedDateOfExternalFile() {
		awpReturnCodesConfigLastModifiedDate = getConfigModifiedDate();
	}

	/**
	 * Returns an InputStream for the specified file path.
	 * Tries looking in classpath, and as external relative file path. 
	 * @param configPath
	 * @return an InputStream to read the config file, or null if not found.
	 */
	private static InputStream getConfigFileAsStream(String configPath) {
		InputStream configStream = null;
		//first check for external file
		File f = getExternalFileIfExists();
		if (f != null) {
			try {
				configStream = new FileInputStream(f);
			} catch (FileNotFoundException e) {
				MatlabWrapperUtil.logError(MatlabAwpReturnCodes.class, "Could not open file as stream: " + f.getPath());
			}
		} else {
			//second, file may be a classpath resource inside the jar
			configStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(configPath);
		}
		return configStream;
	}

	/**
	 * Returns a File object for the config file, only if it exists externally in the file system
	 * @return File
	 */
	private static File getExternalFileIfExists() {
		File externalFile = null; //defaults to no external file found.
		//first try checking the path directly on the file system 
		if (configFilePath != null) {
			File f = new File(configFilePath);
			//if it's a regular file, return it.
			if (f.exists()) {
				externalFile = f; //found external file on the file system.
			} else {
				URL fileUrl = null;
				try {
					//second try looking for a classpath resource
					fileUrl = Thread.currentThread().getContextClassLoader().getResource(configFilePath);
					if (fileUrl != null && fileUrl.getProtocol().equalsIgnoreCase("file")) {
						//if it's a regular file on the file system, return it 
						//(else, it may only exist in jar file so return null)
						f = new File(fileUrl.toURI());
						if (f.exists()) {
							externalFile = f; //Found external file on the classpath
							MatlabWrapperUtil.logInfo(MatlabAwpReturnCodes.class, "found external awp config file: " + externalFile.getPath());
						} else {
							MatlabWrapperUtil.logError(MatlabAwpReturnCodes.class, "error finding external awp config file: " + f.getPath());
						}
					} 
				} catch (Exception e) {
					MatlabWrapperUtil.logError(MatlabAwpReturnCodes.class, "Error accessing external awp config file: " + fileUrl);
					externalFile = null; //supress any error and return null to indicate external file not found.
				}
			}
		}
		return externalFile;
	}

	/**
	 * parses a line from the config file, and places an appropriate entry into the specified map
	 * @param entryLine a line from the config file
	 * @param entriesMap a List of config file entries to add it to.
	 */
	private static synchronized void addEntry(String entryLine, Map<ModuleNameConfigKey, List<ConfigFileEntry>> entriesMap) {
		try {
			//create an entry and locate the Modules list to add it to
			ConfigFileEntry configEntry = new ConfigFileEntry(entryLine); 
			ModuleNameConfigKey moduleKey = new ModuleNameConfigKey(configEntry.getModuleNameText());
			List<ConfigFileEntry> entriesForModule = entriesMap.get(moduleKey);

			//if a list does not yet exist for this module name, create it
			if (entriesForModule == null) {
				entriesForModule = new ArrayList<ConfigFileEntry>();
				entriesMap.put(moduleKey, entriesForModule); //insert empty list into map
			}
			//add the entry for this module key and update the count
			entriesForModule.add(configEntry);
			MatlabWrapperUtil.logDebug(MatlabAwpReturnCodes.class, "Accepted Config Entry: " + entryLine);
			entryCount++;
		} catch (Exception e) {
			MatlabWrapperUtil.logError(MatlabAwpReturnCodes.class, "Rejected Config Entry due to error: " + entryLine);
		}
	}

	/**
	 * returns a list of entries for the specified module name within the given entry map 
	 * if no entries match the specified module class name, null is returned. 
	 * @param moduleClassName
	 * @return a list of matching ConfigFileEntry, or null if none are found.
	 */
	static private synchronized List<ConfigFileEntry> findMatchingEntries(String moduleClassName,  Map<ModuleNameConfigKey, List<ConfigFileEntry>> configMap) {
		moduleClassName = moduleClassName == null ? "" : moduleClassName; //change any nulls to ""
		List<ConfigFileEntry> listOfMatchingEntries = null;
		
		//iterate the entries and find the first one that matches the module class name
		Set<Entry<ModuleNameConfigKey, List<ConfigFileEntry>>> configMapEntries = configMap.entrySet();
		for (Entry<ModuleNameConfigKey, List<ConfigFileEntry>> entry : configMapEntries) {
			Matcher matcher = entry.getKey().regexPattern.matcher(moduleClassName);
			if (matcher.matches()) {
				listOfMatchingEntries = entry.getValue(); //return the list of config entries for this module
				MatlabWrapperUtil.logDebug(MatlabAwpReturnCodes.class, "found match for module name " + moduleClassName + ", matches pattern: " + entry.getKey());
				break; //found first match for module name, we're done.
			}
		}

		return listOfMatchingEntries;
	}

	/**
	 * returns the total number of valid config file entries that were parsed from the config file.
	 * @return the number of valid entries that were found.
	 */
	static public synchronized int size() {
		reloadConfigFileIfModified();
		return entryCount;
	}

	/**
	 * sets the config file path to the specified string, or sets the default value if null.
	 * @param configFilePath
	 */
	private static void setConfigFilePath(String configFilePath) {
		if (configFilePath == null) {
			configFilePath = DEFAULT_CONFIG_FILE; //use default config file
		}
		MatlabAwpReturnCodes.configFilePath = configFilePath;
		String infoMsg = "config file path set to: " + configFilePath;
		MatlabWrapperUtil.logInfo(MatlabAwpReturnCodes.class, infoMsg);
	}
	
	
	
	
	
	
	
	
	
	
	
	/**
	 * Private class used internally as a key for Module class name expressions 
	 * defined within the config entries.
	 * @author Gary Cristofoli
	 */
	static class ModuleNameConfigKey {
		Pattern regexPattern;

		/**
		 * Constructor accepts the a module class name expression specified by an entry, 
		 * and creates a regex pattern that will be used to match against module class names. 
		 * @param moduleName
		 */
		public ModuleNameConfigKey(String moduleName) {
			String trimmedText = moduleName.trim();
			if (trimmedText.startsWith("/") && trimmedText.endsWith("/")) {
				//module name was specified as a regex, compile the pattern
				String regex = trimmedText.substring(1, trimmedText.length() - 1); //a regex was specified, strip off starting and ending '/' delimeters
				regexPattern = Pattern.compile(regex);
			} else {
				//explicit module name was specified
				regexPattern = Pattern.compile(Pattern.quote(moduleName)); //quote the text in case it contains special regex characters like "."
			}
			MatlabWrapperUtil.logDebug(MatlabAwpReturnCodes.class, "Module name " + moduleName + " converted to pattern: " + regexPattern.pattern());
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj) {
				return true; //same instance!
			}
			//regex pattern of the Module Name text are what makes this key unique
			if (obj instanceof ModuleNameConfigKey) {
				ModuleNameConfigKey other = (ModuleNameConfigKey)obj;
				return this.regexPattern.pattern().equals(other.regexPattern.pattern());
			} else {
				return false;
			}
		}

		@Override
		public int hashCode() {
			return regexPattern.pattern().hashCode();
		}

		@Override
		public String toString() {
			return regexPattern.pattern();
		}
	}
}





/**
 * private POJO used to validate an entry from the config file, 
 * and parses it's properties if it's a valid entry.
 * @author Gary Cristofoli
 */
class ConfigFileEntry {
	private String configLine; //the entire line of the config file entry.
	private String moduleNameText; //the module name/expression defined by this config entry.
	private String errorMsgText; //the error message/expression, if one was specified by the config file entry, null otherwise.
	private Pattern errorPattern; //Pattern created from the regular expression for this config file entry. 
	private String awpReturnCode; //the AWP return code as specified by this config entry.
	
	//Pattern used to validate and parse a valid config line
	private static final Pattern validLinePattern = Pattern.compile("\\s*(\\S*)\\s*=\\s*(\\S*)\\s*\\~(.*)");

	/**
	 * Constructor that takes a single line from the config file, and parses it to set this POJO's member variables.
	 * Valid format is: ModuleClassName~Error Msg Text=AwpReturnCode
	 * ModuleClassName and/or Error msg text can be specified explicitly, or as a regular expressions.
	 * If regex is used, it must begin and end with "/" characters. 
	 * If explicit error text is used, a case-insensitive regex pattern is assigned.
	 *  
	 * @param configLine a single line from the return code config file.
	 * @throws Exception if the specified entry has an invalid format that cannot be parsed.
	 */
	public ConfigFileEntry(String configLine) throws Exception {
		try {
			parseConfigLine(configLine);
			this.configLine = configLine;
		} catch (Exception e) {
			String errMsg = "Error parsing config file entry: " + configLine;
			MatlabWrapperUtil.logError(MatlabAwpReturnCodes.class, errMsg);
			throw new IllegalArgumentException(errMsg, e);
		}
	}

	/**
	 * Validates a config file entry line, then extracts the module class name, the AWP return code, 
	 * the error text that was specified.  
	 * If error message text was specified,  
	 * a regular expression is assigned that will match that error text in a cese-insensitive manner.
	 * @param configLine a line from the config file
	 * @throws Exception
	 */
	private void parseConfigLine(String configLine) throws Exception {
		//get the matcher for this entry, or throw an exception if its not formatted correctly.
		Matcher matcher = validateConfigLine(configLine);

		//extract the module class name, awp return code, and text portions from the entry.
		awpReturnCode = matcher.group(1);
		moduleNameText = matcher.group(2);
		errorMsgText = matcher.group(3);

		MatlabWrapperUtil.logDebug(MatlabAwpReturnCodes.class, "parsed entry: " + awpReturnCode + ", " + moduleNameText + ", " + errorMsgText);
		
		//determine if error text or a regex was specified, and handle appropriately.
		String trimmedText = errorMsgText.trim();
		if (trimmedText.startsWith("/") && trimmedText.endsWith("/")) {
			String regex = trimmedText.substring(1, trimmedText.length() - 1); //a regex was specified, strip off starting and ending '/' delimeters
			errorPattern = Pattern.compile(regex);
		} else {
			//create case-insensitive regex, and quote the text in case it contains special regex characters like "."
			String regex = "(?i)" + Pattern.quote(errorMsgText); 
			errorPattern = Pattern.compile(regex);
		}
		MatlabWrapperUtil.logDebug(MatlabAwpReturnCodes.class, "Pattern for error text is: " + errorPattern.pattern());
	}

	/**
	 * validates a config line for correct format, and returns the matcher object if valid. 
	 * @param configLine a line from the config file
	 * @return a Matcher used to parse the entry into it's seperate parts
	 * @throws IllegalArgumentException if the entry has an incorrect format.
	 */
	private Matcher validateConfigLine(String configLine) throws IllegalArgumentException {
		Matcher matcher = validLinePattern.matcher(configLine);
		//the valid pattern should match the entry, and be able to extract the 3 matching groups from it.
		if (!matcher.matches() || matcher.groupCount() != 3) {
			String errMsg = "Invalid Config file entry will be ignored: " + configLine;
			MatlabWrapperUtil.logError(getClass(), errMsg);
			throw new IllegalArgumentException(errMsg);
		}
		return matcher;
	}

	/**
	 * returns the module name text as specified in the config file entry.
	 * @return
	 */
	public String getModuleNameText() {
		return moduleNameText;
	}

	/**
	 * returns the error message entry as specified in the config file entry.
	 * @return
	 */
	public String getErrorMsgText() {
		return errorMsgText;
	}

	/**
	 * returns the regular expression used to match errors for this config file entry. 
	 * This may be one that was specified explicitly in the entry using "/" delimiters, 
	 * or the one that was assigned if only error text was specified.
	 * @return
	 */
	public String getErrorRegex() {
		return errorPattern.toString();
	}

	/**
	 * returns the AWP return code as specified by this config entry.
	 * @return
	 */
	public String getAwpReturnCode() {
		return awpReturnCode;
	}

	/**
	 * returns the Pattern object for the regex expression.
	 * @return
	 */
	public Pattern getErrorPattern() {
		return errorPattern;
	}

	/**
	 * two ConfigFileEntry are considered equal if their ModuleClassName match, and their regex expressions are the same. 
	 * Note that even config entries specified without a regex, do indeed have a regex expression assigned to them. 
	 * Example: An entry specified only with error text "ABC", has a regex expression assigned as "(?i)ABC", 
	 * which is the regular expression that matches the error text in a case-insensitive manner. 
	 * @param obj
	 * @return
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj == this) {
			return true; //same instance!
		}

		if (obj instanceof ConfigFileEntry) {
			ConfigFileEntry other = (ConfigFileEntry)obj;
			//the module name text and error regex is what makes an entry unique 
			return other.moduleNameText.equals(this.moduleNameText) && other.getErrorRegex().equals(this.errorPattern.toString());
		} else {
			return false;
		}
	}

	@Override
	public int hashCode() {
		return (moduleNameText + errorPattern.toString()).hashCode();
	}

	@Override
	public String toString() {
		return configLine; 
	}	

}
