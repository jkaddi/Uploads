package com.ge.om.MatlabWrapper;

import com.ge.om.cafosacbm.NumAlert;

public class Alarm {
	
	private String scanGroup;
	
	private NumAlert numAlert;
	
	private static final String DoubleUnderscore = "__";
	private static final String DOT = ".";
	
	public NumAlert getNumAlert() {
		return numAlert;
	}

	public void setNumAlert(NumAlert numAlert) {
		this.numAlert = numAlert;
	}

	public String getScanGroup() {
		return scanGroup;
	}

	public void setScanGroup(String scanGroup) {
		if(scanGroup != null)
		{
			scanGroup = scanGroup.replaceAll(DoubleUnderscore, DOT);
		}
		this.scanGroup = scanGroup;
	}

	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("<br />\n\t --------Alert Details--------");
		sb.append("<br />\n\tName :: " + this.getNumAlert().getAlertName());
		sb.append("<br />\n\tType ID :: " + this.getNumAlert().getAlertTypeId());
		sb.append("<br />\n\t OSM Name :: " + this.getNumAlert().getOsmName());
		sb.append("<br />\n\t DateTime :: " + this.getNumAlert().getLastTrigger().getTime());
		sb.append("<br />\n\t ScanGroup :: " + this.getScanGroup());
		return sb.toString();
	}
}
