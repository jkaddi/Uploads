package com.ge.oo.kpi;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;
import static org.apache.spark.sql.functions.*;

import com.ge.oo.kpi.config.HasConfig;
import com.typesafe.config.Config;

/**
 * Simple analytic that gets TS data for all tags for and checks whether value is exceeding range.
 * If yes/no, then sets a flag and writes as a TS data with new tag name. 
 * 
 * @author 212393561
 *
 */
public class AvailabilityAnalytic extends HasConfig implements IAnalytics<SQLContext, DataFrame> 
{
	@Override
	public Map<String, DataFrame> runAnalysis(Map<String, IRuntimeDataset<SQLContext>> inputDatasets) 
	{
		IRuntimeDataset<SQLContext> assetDS = inputDatasets.get("assetDS");
		IRuntimeDataset<SQLContext> streamTS = inputDatasets.get("streamTS");
		
		if(assetDS==null) {
			System.err.println("Asset Datasource is null, won't be able to run the analytic");
			return Collections.emptyMap();
		}
		if(streamTS==null) {
			System.err.println("Timeseries Stream Datasource is null, won't be able to run the analytic");
			return Collections.emptyMap();
		}
		
		DataFrame assetInput = assetDS.getContext().sql("select * from `"+assetDS.getName()+"`");
		DataFrame streamInput = assetDS.getContext().sql("select * from `"+streamTS.getName()+"`");
		
		assetInput.show(false);
		assetInput.printSchema();
		
		streamInput.show(false);
		streamInput.printSchema();
		
		String analyticSql = "select a.sourceKey, s.tag, s.timestamp, "
				+ "s.value as availability "
				+ "from `" + assetDS.getName() 
				+ "` a join `" + streamTS.getName() 
				+ "` s on a.tagSourceKey = s.tag "
				+ "where s.tag like 'OO_Tag_Temperature_ID%'";
		
		DataFrame dataDf = assetDS.getContext().sql(analyticSql).cache();
//		dataDf = dataDf
//					.groupBy(dataDf.col("sourceKey"))
//					.agg(
//						sum(dataDf.col("availability")).as("sum"), 
//						count(dataDf.col("availability")).as("count"));

		dataDf.show(false);
		streamInput.printSchema();
		
		dataDf.registerTempTable("temp1");
		
		String resultSQL = "select 'OO_Tag_Temperature_ID_Demo' as tag, timestamp as timestamp, "
				+ "availability as value, 3 as quality "
				+ "from temp1";
		
		DataFrame resultDf = assetDS.getContext().sql(resultSQL);
		
		resultDf.show(false);
		resultDf.printSchema();
		
		Map<String, DataFrame> outputs = new HashMap<>();
		outputs.put("timeseriesWriteDS", resultDf);
		
		return outputs; 
	}
	
}
