package com.ge.oo.kpi;

import org.apache.spark.sql.Column;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.api.java.UDF2;
import org.apache.spark.sql.types.DataTypes;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * 
 * KPI Analytic Template to run in the OO KPI Framework
 *
 */
public class AttributeAnalytic implements IAnalytics<SQLContext, DataFrame> {

    @SuppressWarnings("serial")
    static transient UDF2<String, String, Map<String, String>> attributeUDF =
                    new UDF2<String, String, Map<String, String>>() {
                        @Override
                        public Map<String, String> call(String key, String value) throws Exception {
                            HashMap<String, String> hm = new HashMap<String, String>();
                            hm.put(key, value);
                            return hm;
                        }
                    };

    @Override
    public Map<String, DataFrame> runAnalysis(Map<String, IRuntimeDataset<SQLContext>> inputDatasets) {
        IRuntimeDataset streamTS = inputDatasets.get("streamTS");

        if (streamTS == null) {
            System.err.println("Timeseries Stream Datasource is null, won't be able to run the analytic");
            return Collections.emptyMap();
        }

        DataFrame streamInput = ((SQLContext) streamTS.getContext()).sql("select * from `" + streamTS.getName() + "`");

        streamInput.show(false);
        streamInput.printSchema();

        DataFrame streamFlattened = null;
        DataFrame temperatureDF = null;

        if (Arrays.asList(streamInput.columns()).contains("attributes")) {

            String analyticSQL = "select 'OO_Tag_Attributes_Test' as tag, attributes.*, timestamp, value from `"
                            + streamTS.getName() + "` where tag like 'OO_Tag_Temperature_ID%'";

            streamFlattened = ((SQLContext) streamTS.getContext()).sql(analyticSQL).cache();

            if ((Arrays.asList(streamFlattened.columns()).contains("Key1"))
                            && (Arrays.asList(streamFlattened.columns()).contains("Key2"))) {
                temperatureDF = streamFlattened.filter(
                                streamFlattened.col("Key1").isNotNull().and(streamFlattened.col("Key2").isNotNull()));
            } else {
                temperatureDF = streamFlattened.select("tag", "timestamp", "value").filter("timestamp < 0");
            }

        } else {
            String analyticSQL = "select 'OO_Tag_Attributes_Test' as tag, timestamp, value from `" + streamTS.getName()
                            + "` where tag like 'OO_Tag_Temperature_ID%'";

            temperatureDF = ((SQLContext) streamTS.getContext()).sql(analyticSQL).cache();
        }

        System.out.println("******************temperatureDF***********************");
        temperatureDF.show(false);
        temperatureDF.printSchema();

        DataFrame outputDf = temperatureDF.groupBy("tag")
                        .agg(functions.max("timestamp").alias("timestamp"), functions.sum("value").alias("value"))
                        .withColumn("quality", functions.lit(3));

        System.out.println("******************outputDf START***********************");
        outputDf.show(false);
        outputDf.printSchema();

        ((SQLContext) streamTS.getContext()).udf().register("ToAttributes", attributeUDF,
                        DataTypes.createMapType(DataTypes.StringType, DataTypes.StringType));
        outputDf = outputDf.withColumn("attributes", functions.callUDF("ToAttributes",
                        new Column[] {functions.lit("CalculatedKPI"), functions.lit("true")}));

        outputDf.show(false);
        outputDf.printSchema();
        System.out.println("******************outputDf END***********************");

        Map<String, DataFrame> outputs = new HashMap<>();
        outputs.put("timeseriesWriteDS", outputDf);

        return outputs;
    }
}
