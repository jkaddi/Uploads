package com.ge.oo.kpi;

import static org.apache.spark.sql.functions.avg;
import static org.apache.spark.sql.functions.current_timestamp;
import static org.apache.spark.sql.functions.lit;
import static org.apache.spark.sql.functions.sum;

import com.ge.oo.kpi.config.HasConfig;

import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ConfigdsAnalytic extends HasConfig implements IAnalytics<SQLContext, DataFrame>
{
	private static final Logger LOGGER = Logger.getLogger("oologger");

	@Override
	public Map<String, DataFrame> runAnalysis(Map<String, IRuntimeDataset<SQLContext>> inputDatasets)
	{
		LOGGER.info("I am in the Analytic @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		IRuntimeDataset<SQLContext> assetDS = inputDatasets.get("assetReadDS");
		IRuntimeDataset<SQLContext> timeseriesDS = inputDatasets.get("timeseriesReadDS");
		IRuntimeDataset<SQLContext> configDS = inputDatasets.get("configDS");

		if(assetDS==null) {
			System.err.println("Asset Datasource is null, won't be able to run the analytic");
			return Collections.emptyMap();
		}
		if(timeseriesDS==null) {
			System.err.println("APM Timeseries Datasource is null, won't be able to run the analytic");
			return Collections.emptyMap();
		}

		DataFrame assetInputDf = assetDS.getContext().sql("select * from `"+assetDS.getName()+"`");
		DataFrame tsInputDf = assetDS.getContext().sql("select * from `"+timeseriesDS.getName()+"`");
		DataFrame configInputDf = configDS.getContext().sql("select * from `"+configDS.getName()+"`");

		LOGGER.info("    ASSET DF @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		LOGGER.info(assetInputDf.schema().treeString());
		LOGGER.info(assetInputDf.showString(100, false));

		LOGGER.info("    TS DF @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		LOGGER.info(tsInputDf.schema().treeString());
		LOGGER.info(tsInputDf.showString(100, false));

		LOGGER.info("    CONFIG DF @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		LOGGER.info(configInputDf.schema().treeString());
		LOGGER.info(configInputDf.showString(100, false));

		String analyticSql = "select a.sourceKey, s.tag, s.timestamp, "
				+ "s.value as tagvalues "
				+ "from `" + assetDS.getName()
				+ "` a join `" + timeseriesDS.getName()
				+ "` s on a.tagSourceKey=s.tag";

		DataFrame joinedDf = timeseriesDS.getContext().sql(analyticSql).cache();

		LOGGER.info("JOINED TABLE DATAFRAME @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		LOGGER.info(joinedDf.schema().treeString());
		Arrays.asList(joinedDf.collect()).forEach(c->LOGGER.info(c));
		LOGGER.info(joinedDf.showString(100, false));

		DataFrame heatRateDf = joinedDf
				.select(joinedDf.col("sourceKey"), joinedDf.col("tagvalues"))
				.groupBy(joinedDf.col("sourceKey"))
				.agg(sum(joinedDf.col("tagvalues")).as("value")).withColumn("output", lit("heatrate"));

		LOGGER.info("     HEATRATE DATAFRAME @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		LOGGER.info(heatRateDf.schema().treeString());
		LOGGER.info(heatRateDf.showString(100, false));

		DataFrame powerDf = joinedDf
				.select(joinedDf.col("sourceKey"), joinedDf.col("tagvalues"))
				.groupBy(joinedDf.col("sourceKey"))
				.agg(avg(joinedDf.col("tagvalues")).as("value")).withColumn("output", lit("power"));

		LOGGER.info("     POWER DATAFRAME @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		LOGGER.info(powerDf.schema().treeString());
		LOGGER.info(powerDf.showString(100, false));

		heatRateDf.registerTempTable("heatrateTable");
		powerDf.registerTempTable("powerTable");

		DataFrame outputJoinDf = heatRateDf.unionAll(powerDf);

		LOGGER.info("    OUTPUTJOIN DATAFRAME @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		LOGGER.info(outputJoinDf.schema().treeString());
		LOGGER.info(outputJoinDf.showString(100, false));
		outputJoinDf.registerTempTable("outputJoinDf");

		String joinSql = "select * "
				+ "from `" + "outputJoinDf"
				+ "` oj join `" + configDS.getName()
				+ "` co on oj.sourceKey=co.assetSourceKey and oj.output=co.tagMapping";

		DataFrame interDF = timeseriesDS.getContext().sql(joinSql);

		LOGGER.info("    INTERMEDIATE DATAFRAME @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		LOGGER.info(interDF.schema().treeString());
		LOGGER.info(interDF.showString(100, false));

		DataFrame resultDf = interDF
				.select(interDF.col("tagSourceKey").as("tag"), interDF.col("value"))
				.withColumn("quality", lit(3))
				.withColumn("timestamp", lit(System.currentTimeMillis()));

		LOGGER.info("     RESULT DATAFRAME @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		LOGGER.info(resultDf.schema().treeString());
		LOGGER.info(resultDf.showString(100, false));

		Map<String, DataFrame> outputs = new HashMap<>();
		outputs.put("timeseriesWriteDS", resultDf);

		return outputs;
	}

}
