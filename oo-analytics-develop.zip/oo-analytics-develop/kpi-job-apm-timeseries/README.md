### Sample Analytics that utilizes Asset, StreamTS & TS Datasource Providers.

#### Inputs
* Asset Data (Dataframe Using Rest call to invoke APM Asset Service)
```
root
 |-- sourceKey: string (nullable = true)
 |-- name: string (nullable = true)
 |-- type: string (nullable = true)
 |-- tagSourceKey: string (nullable = true)
 |-- tagName: string (nullable = true)
 |-- tagDescription: string (nullable = true)
 |-- tagUnit: string (nullable = true)
```

* Timeseries Data (Dataframe Using Streaming call to listen to Kafka Topic which will be ingested with Timeseries Data)
```
root
 |-- tag: string (nullable = true)
 |-- timestamp: long (nullable = true)
 |-- value: double (nullable = true)
 |-- isDouble: boolean (nullable = true)
 |-- isInt: boolean (nullable = true)
```
#### Computation 
Does a simple calculation by setting a flag (0/1) if the received values falls within min/max threshold range

#### Output
Timeseries Data (Dataframe with calculated tag value as Timeseries data)
```
root
 |-- tag: string (nullable = false)
 |-- timestamp: timestamp (nullable = false)
 |-- value: integer (nullable = false)
 |-- quality: integer (nullable = false)
```

### Usage
Utilized in oo-jobruntime/jobexec/com.ge.oo.jobexec.KPIJobRunnerTest integration test. 
