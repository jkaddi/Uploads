package com.ge.oo.kpi;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import com.ge.oo.kpi.IAnalytics;
import com.ge.oo.kpi.IRuntimeDataset;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;

/**
 * 
 * KPI Analytic Template to run in the OO KPI Framework
 *
 */
public class DowntimeCalculation implements IAnalytics<SQLContext, DataFrame> 
{
	@Override
	public Map<String, DataFrame> runAnalysis(Map<String, IRuntimeDataset<SQLContext>> inputDatasets) 
	{
		IRuntimeDataset<SQLContext> rawevents = inputDatasets.get("fileInputDS");
		
		if(rawevents==null) {
			System.err.println("Events data not available.");
			return Collections.emptyMap();
		}
		
		DataFrame eventsDF = rawevents.getContext().sql("select * from `"+rawevents.getName()+"`");
		System.err.println("######################   Events Schema ######################");
		eventsDF.printSchema();
		System.err.println("######################   Events DATA ######################");
		eventsDF.show(false);
		
		String downtimeSQL = "select C0, C1, C2, C3, C4, C5, C9,count(*), "
                + "sum(C7-C6)/1000 "
                + " from `" +rawevents.getName()+"`" 
                + " group by C0, C1, C2, C3, C4, C5, C9";
		
		DataFrame downtimeDF = rawevents.getContext().sql(downtimeSQL).cache();
		
		
		System.err.println("######################   ANALYTICS RESULT ######################");
		downtimeDF.show(false);
		downtimeDF.printSchema();
		System.err.println("######################   ANALYTICS RESULT ######################");
		
		Map<String, DataFrame> outputs = new HashMap<>();
		outputs.put("fileOutputDS", downtimeDF);
		
		return outputs; 
		
		
		//return Collections.emptyMap();
	}
}
