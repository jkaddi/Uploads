package com.ge.oo.kpi;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ge.oo.kpi.config.HasConfig;


/**
 * 
 * KPI Analytic Template to run in the OO KPI Framework
 *
 */
public class DowntimeCalculation extends HasConfig implements IAnalytics<SQLContext, DataFrame> 
{
	private static Logger logger = LoggerFactory.getLogger(DowntimeCalculation.class);
	
	@Override
	public Map<String, DataFrame> runAnalysis(Map<String, IRuntimeDataset<SQLContext>> inputDatasets) 
	{	
		IRuntimeDataset<SQLContext> rawevents = inputDatasets.get("cassInputDS");
		
		if(rawevents==null) {
			logger.error("Events data not available.");
			return Collections.emptyMap();
		}
		
		DataFrame eventsDF = rawevents.getContext().sql("select * from `"+rawevents.getName()+"`");
		logger.info("######################   Events Schema ######################");
		logger.info(eventsDF.schema().treeString());
		logger.info(eventsDF.count()+" rows found.");
		logger.info(eventsDF.showString(10, false));
		logger.info("######################   Events DATA ######################");
		
		String downtimeSQL = "select company, enterprise, site_id, line, area, unit, start_time_yyyymmdd,count(*) as num_events, "
                + "sum(end_time_long-start_time_long)/1000 durationsecs"
                + " from `" +rawevents.getName()+"`" 
                + " group by company, enterprise, site_id, line, area, unit, start_time_yyyymmdd";
		
		DataFrame downtimeDF = rawevents.getContext().sql(downtimeSQL).cache();
		
		
		logger.info("######################   ANALYTICS RESULT ######################");
		logger.info(downtimeDF.schema().treeString());
		logger.info("Downtime duration results "+downtimeDF.showString(10, false));
		logger.info("######################   ANALYTICS RESULT ######################");
		
		
		Map<String, DataFrame> outputs = new HashMap<>();
		outputs.put("cassOutputDS", downtimeDF);
		
		return outputs; 
	}
}
