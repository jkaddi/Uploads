package com.ge.oo.kpi;

import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * 
 * KPI Analytic Template to run in the OO KPI Framework
 *
 */
public class MultiplyAnalytic implements IAnalytics<SQLContext, DataFrame> {
    @Override
    public Map<String, DataFrame> runAnalysis(Map<String, IRuntimeDataset<SQLContext>> inputDatasets) {
        IRuntimeDataset<SQLContext> ooTS = inputDatasets.get("ooTs");
        IRuntimeDataset<SQLContext> streamTS = inputDatasets.get("streamTS");

        if (ooTS == null) {
            System.err.println("OO TS FIle Datasource is null, won't be able to run the analytic");
            return Collections.emptyMap();
        }
        if (streamTS == null) {
            System.err.println("Timeseries Stream Datasource is null, won't be able to run the analytic");
            return Collections.emptyMap();
        }

        System.out.println("*********** printing data from TS file ***********");

        // DataFrame ooInput = ooTS.getContext().sql("select * from `" + ooTS.getName() + "`");
        // ooInput.show(false);
        // ooInput.printSchema();
        //
        //
        // DataFrame streamInput = ooTS.getContext().sql("select * from `"+streamTS.getName()+"`");
        // streamInput.show(false); streamInput.printSchema();

        String analyticSql = "select tag, timestamp, value as availability from `" + ooTS.getName()
                        + "` where tag = 'Inverter1-ASSET-TYPE1.Tag_Length'";
        System.out.println("*********** printing analytic sql output ***********");
        DataFrame dataDf = ooTS.getContext().sql(analyticSql).cache();

        dataDf.show(false);
        dataDf.printSchema();
        dataDf.registerTempTable("temp1");

        System.out.println("Call to multiply by 20");
        String resultSQL =
                        "select 'kpioutput_int' as tag, timestamp as timestamp, availability*20 as value, 3 as quality from temp1 order by timestamp asc";

        DataFrame resultDf = ooTS.getContext().sql(resultSQL);
        System.out.println("resultSQL---------->" + resultSQL);

        resultDf.show(false);
        resultDf.printSchema();

        Map<String, DataFrame> outputs = new HashMap<>();
        outputs.put("timeseriesWriteDS", resultDf);

        return outputs;
    }
}
