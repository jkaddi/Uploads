package com.ge.oo.kpi;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.types.StructType;

import com.ge.oo.kpi.IAnalytics;
import com.ge.oo.kpi.IRuntimeDataset;

/**
 * Scala - Commands
 * val df1 = sqlContext.read.json("/Users/212061719/Documents/tools/spark-1.6.1-bin-hadoop2.6/examples/src/main/resources/oo/timeseries-data.json")
 * df1.registerTempTable("dfts")
 * val dfts1 = sqlContext.sql("select quality, tag, timestamp, value from dfts where value > 75 and tag == 'f' " )
 * 
 */

/**
 * 
 * Timeseries - Single Computed Tag Analytic
 * 
 * Simple Analytic to read the data for a calculated Tag and determine the down time based on the value 
 * 
 * KPI Analytic Template to run in the OO KPI Framework
 *
 */
public class KPIAnalytic implements IAnalytics<SQLContext, DataFrame> 
{
	@Override
	public Map<String, DataFrame> runAnalysis(Map<String, IRuntimeDataset<SQLContext>> inputDatasets) 
	{
		//TODO - Get the asset dataset and filter for the tags require for determining the KPI and dynamically read the tags value
		
		IRuntimeDataset<SQLContext> timeseriesDS = inputDatasets.get("streamTS");
     
		String timeseriesSql = "select tag, timestamp, value from `" + timeseriesDS.getName() + "` where value > 75 and tag = 'OO_Tag_Speed_ID229' ";
		
		DataFrame plDf = timeseriesDS.getContext().sql(timeseriesSql).cache();
		
		Row [] rowsList =  plDf.collect();
		
		for(int i=0 ; i< rowsList.length ; i ++)
		{
			Row row = rowsList[i];
			
			System.out.println(row.schema());
			
			Map<String, Object> values = getRowMap(row, row.schema());
			
			String tagName  = (String) values.get("tag");
			
			System.out.println("TagName : " + tagName);
			
			Long timestamp = (Long) values.get("timestamp");
			
			System.out.println("Timestamp : " + timestamp);
			
			Double value = (Double) values.get("value");
			
			System.out.println("Datapoint Value : " + value);
			
			//Example - if Datapoint Value greater than 75 it is up and less than 75 it is down		
			
		}
		Map<String, DataFrame> outputs = new HashMap<String, DataFrame>();
		outputs.put("apmTS", timeseriesDS.getContext().emptyDataFrame());
		return outputs;
	}		
	
	/**
	 * 
	 * Utility to convert a Dataframe row into a Map by passing the row and schema
	 * 
	 * @param row
	 * @param schema
	 * @return
	 */
	private Map<String, Object> getRowMap(Row row, StructType schema) 
	{
		 String[] cols = schema.fieldNames();
		 
		 Map<String, Object> result = new HashMap<>();
		 
		 for (int i = 0; i < row.length(); i++) 
		 {
			 result.put(cols[i], row.get(i));
		 }
		 
		 return result;
	}
}

