### Sample Analytics that utilizes StreamTS Datasource Provider.

#### Input
Timeseries Data (Dataframe Using Streaming call to listen to Kafka Topic which will be ingested with Timeseries Data)

### Queries
1. Queries for specific tag with a certain value range
2. Prints it out

### Usage
Utilized in oo-jobruntime/jobexec/com.ge.oo.jobexec.KPIJobRunnerTest integration test. 
