package com.ge.oo.kpi;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import com.ge.oo.kpi.IAnalytics;
import com.ge.oo.kpi.IRuntimeDataset;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * KPI Analytic Template to run in the OO KPI Framework
 *
 */
public class DowntimeCalculation implements IAnalytics<SQLContext, DataFrame> {
	private static Logger logger = LoggerFactory.getLogger(DowntimeCalculation.class);

	@Override
	public Map<String, DataFrame> runAnalysis(Map<String, IRuntimeDataset<SQLContext>> inputDatasets) {
		
		long startTime = System.currentTimeMillis();
		
		IRuntimeDataset<SQLContext> rawevents = inputDatasets.get("cassInputDS");

		if (rawevents == null) {
			logger.error("Events data not available.");
			return Collections.emptyMap();
		}

		DataFrame eventsDF = rawevents.getContext().sql("select * from `" + rawevents.getName() + "`");
		logger.debug("######################   Events Schema ######################");
		logger.debug(eventsDF.schema().treeString());
		logger.debug(eventsDF.count() + " rows found.");
		logger.debug(eventsDF.showString(10, false));
		logger.debug("######################   Events DATA ######################");
		
		long eventReadTime = System.currentTimeMillis();
		
		logger.info ("######################   Events Read elapsed time ######################");
		logger.info (eventReadTime-startTime+"");
		logger.info ("######################   Events Read elapsed time ######################");
		String downtimeSQL = "select company, enterprise, site_id, line, area, unit, start_time_yyyymmdd,count(*) as num_events, "
				+ "sum(end_time_long-start_time_long)/1000 durationsecs" + " from `" + rawevents.getName() + "`"
				+ " group by company, enterprise, site_id, line, area, unit, start_time_yyyymmdd";

		DataFrame downtimeDF = rawevents.getContext().sql(downtimeSQL).cache();
		long analyticComputationTime = System.currentTimeMillis();
		
		logger.info ("######################   Analytics Computation elapsed time ######################");
		logger.info (analyticComputationTime-eventReadTime+"");
		logger.info ("######################   Analytics Computation elapsed time ######################");

		logger.debug("######################   ANALYTICS RESULT ######################");
		logger.debug(downtimeDF.schema().treeString());
		logger.debug("Downtime duration results " + downtimeDF.showString(10, false));
		logger.debug("######################   ANALYTICS RESULT ######################");

		Map<String, DataFrame> outputs = new HashMap<>();
		outputs.put("postgresOutputDS", downtimeDF);

		return outputs;
	}
}
