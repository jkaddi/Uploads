package com.ge.oo.kpi;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.functions;


/**
 * 
 * KPI Analytic Template to run in the OO KPI Framework
 *
 */
public class WindTurbinePowerAnalytic implements IAnalytics<SQLContext, DataFrame>
{
	private static Logger log = Logger.getLogger(WindTurbinePowerAnalytic.class);
	
	@Override
	public Map<String, DataFrame> runAnalysis(Map<String, IRuntimeDataset<SQLContext>> inputDatasets) 
	{
		IRuntimeDataset<SQLContext> streamTS = inputDatasets.get("streamTS");

		if (streamTS == null) {
			log.info("Timeseries Stream Datasource is null, won't be able to run the analytic");
			return Collections.emptyMap();
		}
		
		DataFrame streamInput = streamTS.getContext().sql("select * from `" + streamTS.getName() + "`");

		//split the first column to two columns with the second column to denote asset ID
		String nonNumPattern = "([^\\d]+)";
		String numPattern = "(\\d+)";	
		DataFrame stDF = streamInput.select(functions.regexp_extract(streamInput.col("tag"), nonNumPattern, 1).as("sensor_tag"),
				functions.regexp_extract(streamInput.col("tag"), numPattern, 1).as("asset_id"),
				streamInput.col("timestamp").as("timestamp"),
				streamInput.col("value").as("value"));

		
		stDF.registerTempTable("STTABLE");
		
		String joinSql = "SELECT wstable.timestamp, sum(pow(wstable.value,3)*adtable.value*cptable.value*0.3096905) as value, 'OO_Tag_Wind_Turbine' as tag, 3 as quality "
			+ " FROM STTABLE wstable, STTABLE adtable, STTABLE cptable"
			+ " WHERE wstable.sensor_tag='OO_Tag_WINDSPEED_' AND adtable.sensor_tag='OO_Tag_AIRDENSITY_' AND cptable.sensor_tag='OO_Tag_Cp_' "
			+ " AND wstable.asset_id = adtable.asset_id AND wstable.timestamp = adtable.timestamp"
			+ " AND cptable.asset_id = adtable.asset_id AND cptable.timestamp = adtable.timestamp"
			+ " group by wstable.timestamp";
			
		DataFrame outputDf = streamTS.getContext().sql(joinSql).sort("timestamp");

		Map<String, DataFrame> outputs = new HashMap<>();
		outputs.put("timeseriesWriteDS", outputDf);
		
		return outputs;
	}
}
