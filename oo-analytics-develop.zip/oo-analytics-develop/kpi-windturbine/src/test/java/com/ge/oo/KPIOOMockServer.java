package com.ge.oo;

import static javax.servlet.http.HttpServletResponse.SC_NOT_FOUND;
import static javax.servlet.http.HttpServletResponse.SC_OK;
import static javax.servlet.http.HttpServletResponse.SC_UNAUTHORIZED;
import static org.apache.commons.io.IOUtils.write;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.mortbay.jetty.Handler;
import org.mortbay.jetty.HttpConnection;
import org.mortbay.jetty.Request;
import org.mortbay.jetty.Response;
import org.mortbay.jetty.handler.AbstractHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.oo.mock.rest.server.MockRestServer;

public class KPIOOMockServer extends MockRestServer {
	private static final Logger LOGGER = LoggerFactory.getLogger(KPIOOMockServer.class);
	
	@Override
	public Handler getMockHandler() {
		Handler handler = new AbstractHandler() {

			public void handle(String target, HttpServletRequest request,
					HttpServletResponse response, int dispatch) throws IOException,
					ServletException {

				LOGGER.debug("=====Mock server gets request=====");
				Request baseRequest = request instanceof Request ? (Request) request
						: HttpConnection.getCurrentConnection().getRequest();
				Response baseResponse = response instanceof Response ? (Response) response
						: HttpConnection.getCurrentConnection().getResponse();
				byte[] bytes = new byte[1024];
				InputStream is = baseRequest.getInputStream();
				while (is.read(bytes) > 0) {
					String value = new String(bytes, "UTF-8");
					setRequestBody(value);
				}
				String resp = getResponse(baseRequest, response);
				if(resp!=null) {
					response.setContentLength(resp.length());
					write(resp, baseResponse.getOutputStream());
				}
				((Request) request).setHandled(true);
			}
		};
		return handler;
	}
	
	private String getResponse(Request request, HttpServletResponse response) throws IOException {
		if(request.getPathInfo().contains("assets")) {
			ok(response);
			LOGGER.debug("=====Returning asset.json content for request===== :: "+request.getUri().toString());
			return FileUtils.readFileToString(new File("src/test/resources/data/asset.json"));	
		} else if(request.getPathInfo().contains("/job/id")) {
			String mockJob = FileUtils.readFileToString(new File("src/test/resources/data/job.json"));
			String jobId = request.getPathInfo().substring(request.getPathInfo().lastIndexOf("/"));
			if(mockJob.contains(jobId)) {
				ok(response);
				LOGGER.debug("=====Returning job.json content for request===== :: "+request.getUri().toString());
				return FileUtils.readFileToString(new File("src/test/resources/data/job.json"));
			} else {
				notfound(response);
				return "Not found message";
			}
		} else if(request.getPathInfo().endsWith("/oauth/token")) {
			
			if(request.getParameter("password").equalsIgnoreCase("wrongpassword")) {
				unauthorized(response);
				LOGGER.debug("=====Returning Unauthorized for request===== :: "+request.getUri().toString());
				return "User is unauthorized";
			}
			ok(response);
			LOGGER.debug("=====Returning token.json content for request===== :: "+request.getUri().toString());
			return FileUtils.readFileToString(new File("src/test/resources/data/token.json"));
		}
		return getResponseBody();
	}
	
	private void ok(HttpServletResponse response) {
		response.setStatus(SC_OK);
		response.setContentType("application/json;charset=utf-8");
	}
	
	private void notfound(HttpServletResponse response) {
		response.setStatus(SC_NOT_FOUND);
	}
	
	private void unauthorized(HttpServletResponse response) {
		response.setStatus(SC_UNAUTHORIZED);
	}
}
