package com.ge.oo;

import java.io.IOException;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.io.IOUtils;
import org.apache.spark.SparkConf;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.ge.oo.commons.datasources.DSSpecification;
import com.ge.oo.commons.datasources.DSSpecificationBuilder;
import com.ge.oo.commons.types.job.Job;
import com.ge.oo.jobexec.Configuration;
import com.ge.oo.jobexec.KPIJobRunner;
import com.ge.oo.mock.rest.server.MockRestServer;
import com.ge.oo.test.utils.dataenv.EnvUtil;
import com.ge.oo.KPIOOMockServer;

@Test(singleThreaded = true)
public class WindTurbinePowerAnalyticTest {
	
	private EnvUtil envUtil = new EnvUtil();
	private SparkConf sparkConf = new SparkConf().set("spark.driver.allowMultipleContexts", "true");
	private static final String TENANT_ID = "264544A66798403C8E1AD01357723E8A";
	private static final String TOPICSUFFIX_ANALYTICS_OUTPUT = ".ANALYTICSOUTPUT";
	private static final String assetId = "assetDS-"+UUID.randomUUID().toString();
	private static final String assetName = "assetDS";
	private static final String provider = "tenantaware.asset";
	private MockRestServer mockAssetServer = new KPIOOMockServer();
	
	@BeforeTest
	public void beforeEverything() throws Exception {
		envUtil.prepare();
		sparkConf.setMaster("local[4]").setAppName("TestTSJob" + UUID.randomUUID().toString());
		envUtil.getKafkaUtil().createTopic(envUtil.getZookeeperClient(), TENANT_ID, 1);
		envUtil.getKafkaUtil().createTopic(envUtil.getZookeeperClient(), TENANT_ID+TOPICSUFFIX_ANALYTICS_OUTPUT, 1);
		mockAssetServer.start();
	}
	
	@AfterTest
	public void afterEverything() throws Exception {
		envUtil.getKafkaUtil().deleteTopic(envUtil.getZookeeperClient(), TENANT_ID);
		if (envUtil != null) {
			envUtil.tearDown();
		}
		try {
			mockAssetServer.stop();
		} catch (InterruptedException e) {
		}
	}
	
	
	
	/**
	 * This test will take in two inputs
	 *  - Asset DS Spec
	 *  - Timeseries via Kafka Topic 
	 *  
	 *  It will run simple analytic and write the output 
	 *  via the tenantaware stream DS Spec
	 *  
	 *  The write to kafka topic is verified by running a simple
	 *  client to pull the message off the topic
	 *  
	 * @throws Exception
	 */
	@Test
	public void testToVerifyKafkaWrite_US4728() throws Exception {
		String jobId = "TestAssetTSJob1";
		
		Set<DSSpecification<String>> inputs = new HashSet<DSSpecification<String>>();
		//inputs.add(getAssetInputDSSpec());
		inputs.add(getTimeseriesInputDSSpec());

		
		Set<DSSpecification<String>> outputs = new HashSet<DSSpecification<String>>();
		outputs.add(getStreamingOutputDSSpec());
		
		Job assetTSWriteToStreamJob = getSampleJob(jobId, inputs, outputs);
		
		//loadAndsendTsToKafka("data/ts.json", TENANT_ID);
	    Map<String, String> variables = loadRuntimeVariables(TENANT_ID);
		
		Thread runner = new Thread(){
			 public void run() {
				 try {
					 KPIJobRunner.bootstrapJob(new KPIJobRunner(), assetTSWriteToStreamJob, sparkConf, variables);
				} catch (Exception e) {
					e.printStackTrace();
					Assert.fail(e.getMessage());
				}
			 }
		};
		
		int totalMessages = 0;
//		KafkaConsumer consumer = new KafkaConsumer(envUtil.getZkUrl(), "group2", TENANT_ID+TOPICSUFFIX_ANALYTICS_OUTPUT);
		ExecutorService executor = Executors.newSingleThreadExecutor();
		try {
//			List<Future<Integer>> consumerFutureCallableList = consumer.run(1);
			runner.start();
			//int totalMessages = 0;
//			for(Future<Integer> futureConsumer : consumerFutureCallableList){
//				totalMessages += futureConsumer.get();
//			}
			//Assert.assertTrue(totalMessages >= 1, "Total messages received " + totalMessages);
		} 
		finally {
			Thread.sleep(600000);
//			consumer.shutdown();
			executor.shutdown();
		}
	}
	
	private Job getSampleJob(String jobId, Set<DSSpecification<String>> inputs, Set<DSSpecification<String>> outputs) {
		Job kpiSampleJob = new Job();
//		kpiSampleJob.setId(jobId);
//		kpiSampleJob.setArtifactPath("/tmp/samplekpi1.jar"); // Not used for now
		kpiSampleJob.setInputs(inputs);
		kpiSampleJob.setOutputs(outputs);
		return kpiSampleJob;
	}	
	

	private void loadAndsendTsToKafka(String tsFileName, String topic) throws IOException {
		String tsdata = IOUtils.toString(Thread.currentThread().getContextClassLoader().getResourceAsStream(tsFileName), "UTF-8");
	    envUtil.getKafkaUtil().sendMessages(topic, new String[]{tsdata});
	}
	
	private Map<String, String> loadRuntimeVariables(String tenant)
			throws IOException, ConfigurationException {
		Map<String, String> variables = loadPropsToMap("oo.properties,F*.properties");
		variables.put("apm.assetUrl", "http://localhost:"+MockRestServer.HTTP_PORT + "/assets/") ;
		variables.put(Configuration.APM_UAA_URL, "http://localhost:"+MockRestServer.HTTP_PORT + "/oauth/token") ;
		variables.put("metadata.broker.list", envUtil.getKafkaServerUrl());
		variables.put("auto.offset.reset", "smallest");
		variables.put("tenant", tenant); //Topic here is the tenant
		return variables;
	}
	
	private Map<String, String> loadPropsToMap(String testResourceName) throws IOException, ConfigurationException {
		return Configuration.loadMultipleConfigs("./src/test/resources/config", testResourceName.split(","));
	}	
	

	private DSSpecification<String> getTimeseriesInputDSSpec() {
		DSSpecificationBuilder builder =  DSSpecificationBuilder.getInstance();
		return builder.setName("streamTS")
		.setProvider("streaming.ts")	// Datasource Provider Alasi name
		.setId("streamTS-"+UUID.randomUUID().toString())
		.setIsStreaming(true)
		.addParameter(com.ge.oo.datasources.stream.DSParameters.Tenant(), "${tenant}")
		.addParameter(com.ge.oo.datasources.stream.DSParameters.Interval(), 10000)
		.addParameter(com.ge.oo.datasources.stream.DSParameters.ContentType(), "application/json")
		.build();
	}
	
	
	private DSSpecification<String> getAssetInputDSSpec() {
		DSSpecificationBuilder builder = DSSpecificationBuilder.getInstance();
		return builder.setId(assetId)
		.setName(assetName)
		.setProvider(provider)
		.addParameter(com.ge.oo.datasources.rest.DSParameters.RequestUrl(), "${apm.timeseriesUrl}")
		.addParameter(com.ge.oo.datasources.rest.DSParameters.Tenant(), "${tenant}")
		.addParameter(com.ge.oo.datasources.rest.DSParameters.Filter(), "operation=raw&tagList=Tag_Temperature&startTime=2016-4-01T00:28:03.000&endTime=2016-5-25T22:28:03.000&sampleCount=200")
		.addParameter(com.ge.oo.datasources.rest.DSParameters.ContentType(), "application/json")
		.addParameter(com.ge.oo.datasources.rest.DSParameters.Auth(), "Bearer ${token}")
		.build();
	}
	
	protected DSSpecification<String> getStreamingOutputDSSpec() {
		DSSpecificationBuilder builder = DSSpecificationBuilder.getInstance();
		return builder.setName("timeseriesWriteDS")
		.setProvider("tenantaware.stream")
		.setId("timeseriesWriteDS-"+UUID.randomUUID().toString())
		.addParameter(com.ge.oo.datasources.stream.DSParameters.Tenant(), "${tenant}")
		.addParameter(com.ge.oo.datasources.stream.DSParameters.Brokers(), "${metadata.broker.list}")
		.addParameter(com.ge.oo.datasources.stream.DSParameters.Topics(), "${tenant}"+TOPICSUFFIX_ANALYTICS_OUTPUT)
		.build();
	}	
}
