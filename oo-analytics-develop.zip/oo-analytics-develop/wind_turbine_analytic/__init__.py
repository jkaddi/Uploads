from sparkjobserver.api import SparkJob, build_problems
from pyspark import SparkContext
from pyspark.sql import *
from pyspark.sql import functions
from pyspark.sql.types import *
from pyspark.sql.dataframe import *
import sys

class WindTurbineJob(SparkJob):

	def validate(self, context, runtime, config):
		print("config passed--->"+str(config))
		return config
		#if config.get('input.strings', None):
		#	return config.get('input.strings')
		#else:
		#	return build_problems(['config input.strings not found'])

	def run_job(self, context, runtime, data):
		print("context type injected ---> "+str(type(context)))
		print("job data injected ----> "+str(type(context._gateway.entry_point.getJobData())))

		windturbineinput = context._gateway.entry_point.getJobData().get("windturbineinput");
		sql_sc = windturbineinput.getContext()

		df = windturbineinput.getContext().sql("select * from `" + windturbineinput.getName() + "`");

		print("*********************************   Data frame from OO *********************************")
		df.show()
		df.printSchema()
		df.registerTempTable("TRANSPOSEDTABLE1")

		print("*********************************   Data frame from local temp table *********************************")

		df1= sql_sc.sql("""
				select * from TRANSPOSEDTABLE1
			""")

		df1.show()
		try:
			transposedAssetDF = sql_sc.sql("select regexp_extract(C0, '([^\\d]+)', 1) as sensor_tag,regexp_extract(C0, '(\\d+)', 1) as asset_id,C1 as timestamp,C2 as value from TRANSPOSEDTABLE1")

			print("*********************************   Asset transposed Data frame ************************")

			transposedAssetDF.show()
		 
			transposedAssetDF.registerTempTable("TRANSPOSEDTABLE")
		
			# wtPowerOutput = "SELECT wstable.timestamp, sum(pow(wstable.value,3)*adtable.value*cptable.value*0.3096905) as value, 'OO_TAG_WINDTURBINE_POWEROUTPUT' as tag, 3 as quality"\
			# 	+ " FROM TRANSPOSEDTABLE wstable, TRANSPOSEDTABLE adtable, TRANSPOSEDTABLE cptable"\
			# 	+ " WHERE wstable.sensor_tag='OO_Tag_WINDSPEED_' AND adtable.sensor_tag='OO_Tag_AIRDENSITY_' AND cptable.sensor_tag='OO_Tag_Cp_'"\
			# 	+ " AND wstable.asset_id = adtable.asset_id AND wstable.timestamp = adtable.timestamp"\
			# 	+ " AND cptable.asset_id = adtable.asset_id AND cptable.timestamp = adtable.timestamp"\
			# 	+ " group by wstable.timestamp"


			#result_df = sql_sc.sql(wtPowerOutput)
			result_df = sql_sc.sql("""
				SELECT wstable.timestamp, sum(pow(wstable.value,3)*adtable.value*cptable.value*0.3096905) as value, 'OO_TAG_WINDTURBINE_POWEROUTPUT' as tag, 3 as quality
				FROM TRANSPOSEDTABLE wstable, TRANSPOSEDTABLE adtable, TRANSPOSEDTABLE cptable
				WHERE wstable.sensor_tag='OO_Tag_WINDSPEED_' AND adtable.sensor_tag='OO_Tag_AIRDENSITY_' AND cptable.sensor_tag='OO_Tag_Cp_'
				AND wstable.asset_id = adtable.asset_id AND wstable.timestamp = adtable.timestamp
				AND cptable.asset_id = adtable.asset_id AND cptable.timestamp = adtable.timestamp
				group by wstable.timestamp
				""")
		#.sort("timestamp")

			print("*********************************   Analytic Output ***********************************")
			result_df.show()
		except Exception as inst:
			print("Exception in WindTurbine Analytic",inst)	

		result_dict = {"timeseriesWriteDS":result_df}
		
		return result_dict