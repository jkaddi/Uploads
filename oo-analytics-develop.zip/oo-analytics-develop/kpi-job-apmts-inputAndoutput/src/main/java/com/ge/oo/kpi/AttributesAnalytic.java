package com.ge.oo.kpi;

import com.ge.oo.kpi.config.HasConfig;
import com.typesafe.config.Config;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import org.apache.log4j.Logger;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;

public class AttributesAnalytic extends HasConfig
  implements IAnalytics<SQLContext, DataFrame>
{
  private static Logger log = Logger.getLogger(AttributesAnalytic.class);

  public Map<String, DataFrame> runAnalysis(Map<String, IRuntimeDataset<SQLContext>> inputDatasets)
  {
    log.info("################# KPIUsingConfig ######################");
    Config jobConfig = getConfig();
    String datasinkTarget = jobConfig.getConfig("ooTsApmWrite").getString("tag");
    log.info("KPIUsingConfig: analytic resulting will be written to " + datasinkTarget);

    Map outputs = new HashMap();
    IRuntimeDataset streamTS = (IRuntimeDataset)inputDatasets.get("ooTsApmRead");
    if (streamTS == null) {
      log.warn("Timeseries Stream Datasource is null, won't be able to run the analytic");
      return Collections.emptyMap();
    }

    DataFrame streamInput = ((SQLContext)streamTS.getContext()).sql("select * from `" + streamTS.getName() + "`");

    streamInput.show(false);
    streamInput.printSchema();
    DataFrame outputDf = null;
    String analyticSQL = null;

    analyticSQL = "select '" + datasinkTarget + "' as tag, timestamp, value*10 as value, quality from `" + streamTS
      .getName() + "` where tag like 'TEST-ASSET-TYPE_KT.Tag_Length_Automation%'";
    outputDf = ((SQLContext)streamTS.getContext()).sql(analyticSQL).cache();
    outputs.put("ooTsApmWrite", outputDf);
    log.info("################# KPIUsingConfig ######################");
    return outputs;
  }
}
