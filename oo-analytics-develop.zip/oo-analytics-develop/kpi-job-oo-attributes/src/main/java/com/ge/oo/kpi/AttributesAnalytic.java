package com.ge.oo.kpi;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.spark.sql.Column;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.api.java.UDF2;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import com.ge.oo.kpi.config.HasConfig;
import com.typesafe.config.Config;

/**
 *
 * KPI Analytic Template to run in the OO KPI Framework
 *
 */
public class AttributesAnalytic extends HasConfig implements IAnalytics<SQLContext, DataFrame> {

	private static Logger log = Logger.getLogger(AttributesAnalytic.class);
	
    @SuppressWarnings("serial")
    static transient UDF2<String, String, Map<String, String>> attributeUDF =
                    new UDF2<String, String, Map<String, String>>() {
                        @Override
                        public Map<String, String> call(String key, String value) throws Exception {
                            if ((key != null) && (value != null)) {
                                HashMap<String, String> hm = new HashMap<String, String>();
                                hm.put(key, value);
                                return hm;
                            } else {
                                return null;
                            }
                        }
                    };

    @Override
    public Map<String, DataFrame> runAnalysis(Map<String, IRuntimeDataset<SQLContext>> inputDatasets) {
    	 log.info("******************AttributesAnalytic BEGIN***********************");
    	 Config config = getConfig();
    	 log.info("Configurations are ---> "+config);
        Map<String, DataFrame> outputs = new HashMap<>();
        try {
            IRuntimeDataset streamTS = inputDatasets.get("streamTS");


            if (streamTS == null) {
                System.out.println("Timeseries Stream Datasource is null, won't be able to run the analytic");
                return Collections.emptyMap();
            }

            DataFrame streamInput =
                            ((SQLContext) streamTS.getContext()).sql("select * from `" + streamTS.getName() + "`");

            streamInput.show(false);
            streamInput.printSchema();
            DataFrame outputDf = null;
            String analyticSQL = null;

            if (Arrays.asList(streamInput.columns()).contains("attributes")) {

                analyticSQL =
                                "select 'OO_Tag_Attributes_Speed_Test' as tag, attributes as attr, timestamp, value*10 as value, quality from `"
                                                + streamTS.getName() + "` where tag like 'OO_Tag_Speed_ID%'";

            } else {
                analyticSQL =
                                "select 'OO_Tag_Attributes_Speed_Test' as tag, timestamp, value*10 as value, quality from `"
                                                + streamTS.getName() + "` where tag like 'OO_Tag_Speed_ID%'";

            }

            outputDf = ((SQLContext) streamTS.getContext()).sql(analyticSQL).cache();


            // / orig
            ((SQLContext) streamTS.getContext()).udf().register("ToAttributes", attributeUDF,
                            DataTypes.createMapType(DataTypes.StringType, DataTypes.StringType));

            // get name of first key to use as
            // output. long way to get key name,
            // but left here as an example
            String aKey = null;
            StructType a = outputDf.schema();
            if (a.fields()[a.fieldIndex("attr")] != null) {
                StructType b = (StructType) a.fields()[a.fieldIndex("attr")].dataType();

                // Get first key ...
                for (StructField fields : b.fields()) {
                    aKey = fields.name();
                    break;
                }
            }

            // Just put map of first key for testing, others will be null
            DataFrame mapDfKey =
                            outputDf.withColumn(
                                            "attributes",
                                            functions.callUDF("ToAttributes", new Column[] {functions.lit(aKey),
                                                    outputDf.col("attr").apply(aKey)})); // works!!


            logit(mapDfKey);

            outputs.put("timeseriesWriteDS", mapDfKey);
            log.info("******************AttributesAnalytic END***********************");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return outputs;

    }

    private void logit(DataFrame df) {

        System.out.println("******************dataframe END***********************");

        df.show(false);
        df.printSchema();
        System.out.println("******************dataframe END***********************");
    }

}
